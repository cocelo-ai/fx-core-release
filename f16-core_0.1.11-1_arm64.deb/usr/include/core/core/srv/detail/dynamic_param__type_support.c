// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from core:srv/DynamicParam.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "core/srv/detail/dynamic_param__rosidl_typesupport_introspection_c.h"
#include "core/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "core/srv/detail/dynamic_param__functions.h"
#include "core/srv/detail/dynamic_param__struct.h"


// Include directives for member types
// Member `robot_motor_ids`
// Member `robot_motor_kp`
// Member `robot_motor_kd`
// Member `robot_max_torque_nm`
// Member `wma_weights`
#include "rosidl_runtime_c/primitives_sequence_functions.h"
// Member `safety_motor_rules`
#include "core/msg/motor_safety_rule.h"
// Member `safety_motor_rules`
#include "core/msg/detail/motor_safety_rule__rosidl_typesupport_introspection_c.h"
// Member `safety_imu_rules`
#include "core/msg/imu_safety_rule.h"
// Member `safety_imu_rules`
#include "core/msg/detail/imu_safety_rule__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__DynamicParam_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  core__srv__DynamicParam_Request__init(message_memory);
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__DynamicParam_Request_fini_function(void * message_memory)
{
  core__srv__DynamicParam_Request__fini(message_memory);
}

size_t core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__robot_motor_ids(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__robot_motor_ids(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__robot_motor_ids(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__robot_motor_ids(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__robot_motor_ids(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__robot_motor_ids(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__robot_motor_ids(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__resize_function__DynamicParam_Request__robot_motor_ids(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__robot_motor_kp(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__robot_motor_kp(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__robot_motor_kp(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__robot_motor_kp(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__robot_motor_kp(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__robot_motor_kp(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__robot_motor_kp(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__resize_function__DynamicParam_Request__robot_motor_kp(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__robot_motor_kd(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__robot_motor_kd(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__robot_motor_kd(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__robot_motor_kd(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__robot_motor_kd(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__robot_motor_kd(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__robot_motor_kd(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__resize_function__DynamicParam_Request__robot_motor_kd(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__robot_max_torque_nm(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__robot_max_torque_nm(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__robot_max_torque_nm(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__robot_max_torque_nm(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__robot_max_torque_nm(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__robot_max_torque_nm(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__robot_max_torque_nm(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__resize_function__DynamicParam_Request__robot_max_torque_nm(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__joystick_min_motion_command(
  const void * untyped_member)
{
  (void)untyped_member;
  return 8;
}

const void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__joystick_min_motion_command(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__joystick_min_motion_command(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__joystick_min_motion_command(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__joystick_min_motion_command(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__joystick_min_motion_command(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__joystick_min_motion_command(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__joystick_max_motion_command(
  const void * untyped_member)
{
  (void)untyped_member;
  return 8;
}

const void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__joystick_max_motion_command(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__joystick_max_motion_command(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__joystick_max_motion_command(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__joystick_max_motion_command(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__joystick_max_motion_command(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__joystick_max_motion_command(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__command_iface_min_motion_command(
  const void * untyped_member)
{
  (void)untyped_member;
  return 8;
}

const void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__command_iface_min_motion_command(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__command_iface_min_motion_command(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__command_iface_min_motion_command(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__command_iface_min_motion_command(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__command_iface_min_motion_command(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__command_iface_min_motion_command(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__command_iface_max_motion_command(
  const void * untyped_member)
{
  (void)untyped_member;
  return 8;
}

const void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__command_iface_max_motion_command(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__command_iface_max_motion_command(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__command_iface_max_motion_command(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__command_iface_max_motion_command(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__command_iface_max_motion_command(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__command_iface_max_motion_command(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__wma_weights(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__wma_weights(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__wma_weights(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__wma_weights(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__wma_weights(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__wma_weights(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__wma_weights(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__resize_function__DynamicParam_Request__wma_weights(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__safety_motor_rules(
  const void * untyped_member)
{
  const core__msg__MotorSafetyRule__Sequence * member =
    (const core__msg__MotorSafetyRule__Sequence *)(untyped_member);
  return member->size;
}

const void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__safety_motor_rules(
  const void * untyped_member, size_t index)
{
  const core__msg__MotorSafetyRule__Sequence * member =
    (const core__msg__MotorSafetyRule__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__safety_motor_rules(
  void * untyped_member, size_t index)
{
  core__msg__MotorSafetyRule__Sequence * member =
    (core__msg__MotorSafetyRule__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__safety_motor_rules(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const core__msg__MotorSafetyRule * item =
    ((const core__msg__MotorSafetyRule *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__safety_motor_rules(untyped_member, index));
  core__msg__MotorSafetyRule * value =
    (core__msg__MotorSafetyRule *)(untyped_value);
  *value = *item;
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__safety_motor_rules(
  void * untyped_member, size_t index, const void * untyped_value)
{
  core__msg__MotorSafetyRule * item =
    ((core__msg__MotorSafetyRule *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__safety_motor_rules(untyped_member, index));
  const core__msg__MotorSafetyRule * value =
    (const core__msg__MotorSafetyRule *)(untyped_value);
  *item = *value;
}

bool core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__resize_function__DynamicParam_Request__safety_motor_rules(
  void * untyped_member, size_t size)
{
  core__msg__MotorSafetyRule__Sequence * member =
    (core__msg__MotorSafetyRule__Sequence *)(untyped_member);
  core__msg__MotorSafetyRule__Sequence__fini(member);
  return core__msg__MotorSafetyRule__Sequence__init(member, size);
}

size_t core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__safety_imu_rules(
  const void * untyped_member)
{
  const core__msg__ImuSafetyRule__Sequence * member =
    (const core__msg__ImuSafetyRule__Sequence *)(untyped_member);
  return member->size;
}

const void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__safety_imu_rules(
  const void * untyped_member, size_t index)
{
  const core__msg__ImuSafetyRule__Sequence * member =
    (const core__msg__ImuSafetyRule__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__safety_imu_rules(
  void * untyped_member, size_t index)
{
  core__msg__ImuSafetyRule__Sequence * member =
    (core__msg__ImuSafetyRule__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__safety_imu_rules(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const core__msg__ImuSafetyRule * item =
    ((const core__msg__ImuSafetyRule *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__safety_imu_rules(untyped_member, index));
  core__msg__ImuSafetyRule * value =
    (core__msg__ImuSafetyRule *)(untyped_value);
  *value = *item;
}

void core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__safety_imu_rules(
  void * untyped_member, size_t index, const void * untyped_value)
{
  core__msg__ImuSafetyRule * item =
    ((core__msg__ImuSafetyRule *)
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__safety_imu_rules(untyped_member, index));
  const core__msg__ImuSafetyRule * value =
    (const core__msg__ImuSafetyRule *)(untyped_value);
  *item = *value;
}

bool core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__resize_function__DynamicParam_Request__safety_imu_rules(
  void * untyped_member, size_t size)
{
  core__msg__ImuSafetyRule__Sequence * member =
    (core__msg__ImuSafetyRule__Sequence *)(untyped_member);
  core__msg__ImuSafetyRule__Sequence__fini(member);
  return core__msg__ImuSafetyRule__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__DynamicParam_Request_message_member_array[35] = {
  {
    "robot_motor_ids",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, robot_motor_ids),  // bytes offset in struct
    NULL,  // default value
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__robot_motor_ids,  // size() function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__robot_motor_ids,  // get_const(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__robot_motor_ids,  // get(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__robot_motor_ids,  // fetch(index, &value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__robot_motor_ids,  // assign(index, value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__resize_function__DynamicParam_Request__robot_motor_ids  // resize(index) function pointer
  },
  {
    "robot_motor_kp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, robot_motor_kp),  // bytes offset in struct
    NULL,  // default value
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__robot_motor_kp,  // size() function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__robot_motor_kp,  // get_const(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__robot_motor_kp,  // get(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__robot_motor_kp,  // fetch(index, &value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__robot_motor_kp,  // assign(index, value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__resize_function__DynamicParam_Request__robot_motor_kp  // resize(index) function pointer
  },
  {
    "robot_motor_kd",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, robot_motor_kd),  // bytes offset in struct
    NULL,  // default value
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__robot_motor_kd,  // size() function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__robot_motor_kd,  // get_const(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__robot_motor_kd,  // get(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__robot_motor_kd,  // fetch(index, &value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__robot_motor_kd,  // assign(index, value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__resize_function__DynamicParam_Request__robot_motor_kd  // resize(index) function pointer
  },
  {
    "robot_max_torque_nm",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, robot_max_torque_nm),  // bytes offset in struct
    NULL,  // default value
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__robot_max_torque_nm,  // size() function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__robot_max_torque_nm,  // get_const(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__robot_max_torque_nm,  // get(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__robot_max_torque_nm,  // fetch(index, &value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__robot_max_torque_nm,  // assign(index, value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__resize_function__DynamicParam_Request__robot_max_torque_nm  // resize(index) function pointer
  },
  {
    "joystick_left_x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, joystick_left_x),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "joystick_left_y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, joystick_left_y),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "joystick_right_x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, joystick_right_x),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "joystick_right_y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, joystick_right_y),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "joystick_dpad_x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, joystick_dpad_x),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "joystick_dpad_y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, joystick_dpad_y),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "joystick_left_btn",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, joystick_left_btn),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "joystick_right_btn",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, joystick_right_btn),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "joystick_dpad_step_x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, joystick_dpad_step_x),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "joystick_dpad_step_y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, joystick_dpad_step_y),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "joystick_smoothness",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, joystick_smoothness),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "joystick_deadzone",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, joystick_deadzone),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "joystick_min_motion_command",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    8,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, joystick_min_motion_command),  // bytes offset in struct
    NULL,  // default value
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__joystick_min_motion_command,  // size() function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__joystick_min_motion_command,  // get_const(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__joystick_min_motion_command,  // get(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__joystick_min_motion_command,  // fetch(index, &value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__joystick_min_motion_command,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "joystick_max_motion_command",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    8,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, joystick_max_motion_command),  // bytes offset in struct
    NULL,  // default value
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__joystick_max_motion_command,  // size() function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__joystick_max_motion_command,  // get_const(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__joystick_max_motion_command,  // get(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__joystick_max_motion_command,  // fetch(index, &value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__joystick_max_motion_command,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "cmd_priority_hold_sec",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, cmd_priority_hold_sec),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "cmd_packet_timeout_sec",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, cmd_packet_timeout_sec),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "use_command_filter",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, use_command_filter),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "motion_command_index_linear_vel_x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, motion_command_index_linear_vel_x),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "motion_command_index_linear_vel_y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, motion_command_index_linear_vel_y),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "motion_command_index_angular_vel_z",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, motion_command_index_angular_vel_z),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "motion_command_index_position_z",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, motion_command_index_position_z),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "motion_command_index_orientation_roll",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, motion_command_index_orientation_roll),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "motion_command_index_orientation_pitch",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, motion_command_index_orientation_pitch),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "command_iface_min_motion_command",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    8,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, command_iface_min_motion_command),  // bytes offset in struct
    NULL,  // default value
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__command_iface_min_motion_command,  // size() function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__command_iface_min_motion_command,  // get_const(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__command_iface_min_motion_command,  // get(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__command_iface_min_motion_command,  // fetch(index, &value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__command_iface_min_motion_command,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "command_iface_max_motion_command",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    8,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, command_iface_max_motion_command),  // bytes offset in struct
    NULL,  // default value
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__command_iface_max_motion_command,  // size() function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__command_iface_max_motion_command,  // get_const(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__command_iface_max_motion_command,  // get(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__command_iface_max_motion_command,  // fetch(index, &value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__command_iface_max_motion_command,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "battery_low_soc_threshold",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, battery_low_soc_threshold),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "motor_temperature_threshold",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, motor_temperature_threshold),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "battery_temperature_threshold",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, battery_temperature_threshold),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "wma_weights",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, wma_weights),  // bytes offset in struct
    NULL,  // default value
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__wma_weights,  // size() function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__wma_weights,  // get_const(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__wma_weights,  // get(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__wma_weights,  // fetch(index, &value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__wma_weights,  // assign(index, value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__resize_function__DynamicParam_Request__wma_weights  // resize(index) function pointer
  },
  {
    "safety_motor_rules",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, safety_motor_rules),  // bytes offset in struct
    NULL,  // default value
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__safety_motor_rules,  // size() function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__safety_motor_rules,  // get_const(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__safety_motor_rules,  // get(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__safety_motor_rules,  // fetch(index, &value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__safety_motor_rules,  // assign(index, value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__resize_function__DynamicParam_Request__safety_motor_rules  // resize(index) function pointer
  },
  {
    "safety_imu_rules",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Request, safety_imu_rules),  // bytes offset in struct
    NULL,  // default value
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__size_function__DynamicParam_Request__safety_imu_rules,  // size() function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_const_function__DynamicParam_Request__safety_imu_rules,  // get_const(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__get_function__DynamicParam_Request__safety_imu_rules,  // get(index) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__fetch_function__DynamicParam_Request__safety_imu_rules,  // fetch(index, &value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__assign_function__DynamicParam_Request__safety_imu_rules,  // assign(index, value) function pointer
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__resize_function__DynamicParam_Request__safety_imu_rules  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__DynamicParam_Request_message_members = {
  "core__srv",  // message namespace
  "DynamicParam_Request",  // message name
  35,  // number of fields
  sizeof(core__srv__DynamicParam_Request),
  core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__DynamicParam_Request_message_member_array,  // message members
  core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__DynamicParam_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__DynamicParam_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__DynamicParam_Request_message_type_support_handle = {
  0,
  &core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__DynamicParam_Request_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_core
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, core, srv, DynamicParam_Request)() {
  core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__DynamicParam_Request_message_member_array[33].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, core, msg, MotorSafetyRule)();
  core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__DynamicParam_Request_message_member_array[34].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, core, msg, ImuSafetyRule)();
  if (!core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__DynamicParam_Request_message_type_support_handle.typesupport_identifier) {
    core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__DynamicParam_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &core__srv__DynamicParam_Request__rosidl_typesupport_introspection_c__DynamicParam_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "core/srv/detail/dynamic_param__rosidl_typesupport_introspection_c.h"
// already included above
// #include "core/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "core/srv/detail/dynamic_param__functions.h"
// already included above
// #include "core/srv/detail/dynamic_param__struct.h"


// Include directives for member types
// Member `reason`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void core__srv__DynamicParam_Response__rosidl_typesupport_introspection_c__DynamicParam_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  core__srv__DynamicParam_Response__init(message_memory);
}

void core__srv__DynamicParam_Response__rosidl_typesupport_introspection_c__DynamicParam_Response_fini_function(void * message_memory)
{
  core__srv__DynamicParam_Response__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember core__srv__DynamicParam_Response__rosidl_typesupport_introspection_c__DynamicParam_Response_message_member_array[2] = {
  {
    "success",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Response, success),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reason",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__srv__DynamicParam_Response, reason),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers core__srv__DynamicParam_Response__rosidl_typesupport_introspection_c__DynamicParam_Response_message_members = {
  "core__srv",  // message namespace
  "DynamicParam_Response",  // message name
  2,  // number of fields
  sizeof(core__srv__DynamicParam_Response),
  core__srv__DynamicParam_Response__rosidl_typesupport_introspection_c__DynamicParam_Response_message_member_array,  // message members
  core__srv__DynamicParam_Response__rosidl_typesupport_introspection_c__DynamicParam_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  core__srv__DynamicParam_Response__rosidl_typesupport_introspection_c__DynamicParam_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t core__srv__DynamicParam_Response__rosidl_typesupport_introspection_c__DynamicParam_Response_message_type_support_handle = {
  0,
  &core__srv__DynamicParam_Response__rosidl_typesupport_introspection_c__DynamicParam_Response_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_core
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, core, srv, DynamicParam_Response)() {
  if (!core__srv__DynamicParam_Response__rosidl_typesupport_introspection_c__DynamicParam_Response_message_type_support_handle.typesupport_identifier) {
    core__srv__DynamicParam_Response__rosidl_typesupport_introspection_c__DynamicParam_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &core__srv__DynamicParam_Response__rosidl_typesupport_introspection_c__DynamicParam_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "core/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "core/srv/detail/dynamic_param__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers core__srv__detail__dynamic_param__rosidl_typesupport_introspection_c__DynamicParam_service_members = {
  "core__srv",  // service namespace
  "DynamicParam",  // service name
  // these two fields are initialized below on the first access
  NULL,  // request message
  // core__srv__detail__dynamic_param__rosidl_typesupport_introspection_c__DynamicParam_Request_message_type_support_handle,
  NULL  // response message
  // core__srv__detail__dynamic_param__rosidl_typesupport_introspection_c__DynamicParam_Response_message_type_support_handle
};

static rosidl_service_type_support_t core__srv__detail__dynamic_param__rosidl_typesupport_introspection_c__DynamicParam_service_type_support_handle = {
  0,
  &core__srv__detail__dynamic_param__rosidl_typesupport_introspection_c__DynamicParam_service_members,
  get_service_typesupport_handle_function,
};

// Forward declaration of request/response type support functions
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, core, srv, DynamicParam_Request)();

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, core, srv, DynamicParam_Response)();

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_core
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, core, srv, DynamicParam)() {
  if (!core__srv__detail__dynamic_param__rosidl_typesupport_introspection_c__DynamicParam_service_type_support_handle.typesupport_identifier) {
    core__srv__detail__dynamic_param__rosidl_typesupport_introspection_c__DynamicParam_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)core__srv__detail__dynamic_param__rosidl_typesupport_introspection_c__DynamicParam_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, core, srv, DynamicParam_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, core, srv, DynamicParam_Response)()->data;
  }

  return &core__srv__detail__dynamic_param__rosidl_typesupport_introspection_c__DynamicParam_service_type_support_handle;
}
