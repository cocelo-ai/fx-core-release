// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from core:msg/CommandCore.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "core/msg/detail/command_core__rosidl_typesupport_introspection_c.h"
#include "core/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "core/msg/detail/command_core__functions.h"
#include "core/msg/detail/command_core__struct.h"


// Include directives for member types
// Member `event`
#include "core/msg/event_core.h"
// Member `event`
#include "core/msg/detail/event_core__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void core__msg__CommandCore__rosidl_typesupport_introspection_c__CommandCore_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  core__msg__CommandCore__init(message_memory);
}

void core__msg__CommandCore__rosidl_typesupport_introspection_c__CommandCore_fini_function(void * message_memory)
{
  core__msg__CommandCore__fini(message_memory);
}

size_t core__msg__CommandCore__rosidl_typesupport_introspection_c__size_function__CommandCore__motion_command(
  const void * untyped_member)
{
  (void)untyped_member;
  return 8;
}

const void * core__msg__CommandCore__rosidl_typesupport_introspection_c__get_const_function__CommandCore__motion_command(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * core__msg__CommandCore__rosidl_typesupport_introspection_c__get_function__CommandCore__motion_command(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void core__msg__CommandCore__rosidl_typesupport_introspection_c__fetch_function__CommandCore__motion_command(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__msg__CommandCore__rosidl_typesupport_introspection_c__get_const_function__CommandCore__motion_command(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__msg__CommandCore__rosidl_typesupport_introspection_c__assign_function__CommandCore__motion_command(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__msg__CommandCore__rosidl_typesupport_introspection_c__get_function__CommandCore__motion_command(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

static rosidl_typesupport_introspection_c__MessageMember core__msg__CommandCore__rosidl_typesupport_introspection_c__CommandCore_message_member_array[3] = {
  {
    "motion_command",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    8,  // array size
    false,  // is upper bound
    offsetof(core__msg__CommandCore, motion_command),  // bytes offset in struct
    NULL,  // default value
    core__msg__CommandCore__rosidl_typesupport_introspection_c__size_function__CommandCore__motion_command,  // size() function pointer
    core__msg__CommandCore__rosidl_typesupport_introspection_c__get_const_function__CommandCore__motion_command,  // get_const(index) function pointer
    core__msg__CommandCore__rosidl_typesupport_introspection_c__get_function__CommandCore__motion_command,  // get(index) function pointer
    core__msg__CommandCore__rosidl_typesupport_introspection_c__fetch_function__CommandCore__motion_command,  // fetch(index, &value) function pointer
    core__msg__CommandCore__rosidl_typesupport_introspection_c__assign_function__CommandCore__motion_command,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "event",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__CommandCore, event),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "custom_drive_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__CommandCore, custom_drive_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers core__msg__CommandCore__rosidl_typesupport_introspection_c__CommandCore_message_members = {
  "core__msg",  // message namespace
  "CommandCore",  // message name
  3,  // number of fields
  sizeof(core__msg__CommandCore),
  core__msg__CommandCore__rosidl_typesupport_introspection_c__CommandCore_message_member_array,  // message members
  core__msg__CommandCore__rosidl_typesupport_introspection_c__CommandCore_init_function,  // function to initialize message memory (memory has to be allocated)
  core__msg__CommandCore__rosidl_typesupport_introspection_c__CommandCore_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t core__msg__CommandCore__rosidl_typesupport_introspection_c__CommandCore_message_type_support_handle = {
  0,
  &core__msg__CommandCore__rosidl_typesupport_introspection_c__CommandCore_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_core
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, core, msg, CommandCore)() {
  core__msg__CommandCore__rosidl_typesupport_introspection_c__CommandCore_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, core, msg, EventCore)();
  if (!core__msg__CommandCore__rosidl_typesupport_introspection_c__CommandCore_message_type_support_handle.typesupport_identifier) {
    core__msg__CommandCore__rosidl_typesupport_introspection_c__CommandCore_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &core__msg__CommandCore__rosidl_typesupport_introspection_c__CommandCore_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
