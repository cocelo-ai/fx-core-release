// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from core:msg/RobotReport.idl
// generated code does not contain a copyright notice
#include "core/msg/detail/robot_report__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `robot_state_name`
// Member `active_command_source_name`
// Member `error_reason`
// Member `motor_pattern`
// Member `motor_err`
// Member `battery_voltage`
// Member `battery_soc`
// Member `battery_current`
// Member `battery_temperature`
// Member `battery_power`
#include "rosidl_runtime_c/string_functions.h"
// Member `motor_pattern_ok`
// Member `dof_pos`
// Member `dof_vel`
// Member `dof_tau`
// Member `ang_vel`
// Member `proj_grav`
// Member `lin_vel`
// Member `height_map`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
core__msg__RobotReport__init(core__msg__RobotReport * msg)
{
  if (!msg) {
    return false;
  }
  // robot_state
  // robot_state_name
  if (!rosidl_runtime_c__String__init(&msg->robot_state_name)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // robot_initialized
  // custom_drive_id
  // active_command_source
  // active_command_source_name
  if (!rosidl_runtime_c__String__init(&msg->active_command_source_name)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // active_command_fresh
  // sdk_mode_enabled
  // data_collection_mode_enabled
  // motion_command
  // physical_estop
  // physical_fault
  // comm_estop
  // comm_fault
  // command_estop
  // safety_estop
  // safety_fault
  // controller_failure
  // error_reason
  if (!rosidl_runtime_c__String__init(&msg->error_reason)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // motor_pattern
  if (!rosidl_runtime_c__String__Sequence__init(&msg->motor_pattern, 0)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // motor_pattern_ok
  if (!rosidl_runtime_c__boolean__Sequence__init(&msg->motor_pattern_ok, 0)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // motor_err
  if (!rosidl_runtime_c__String__Sequence__init(&msg->motor_err, 0)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // battery_voltage
  if (!rosidl_runtime_c__String__init(&msg->battery_voltage)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // battery_soc
  if (!rosidl_runtime_c__String__init(&msg->battery_soc)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // battery_current
  if (!rosidl_runtime_c__String__init(&msg->battery_current)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // battery_temperature
  if (!rosidl_runtime_c__String__init(&msg->battery_temperature)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // battery_power
  if (!rosidl_runtime_c__String__init(&msg->battery_power)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // dof_pos
  if (!rosidl_runtime_c__float__Sequence__init(&msg->dof_pos, 0)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // dof_vel
  if (!rosidl_runtime_c__float__Sequence__init(&msg->dof_vel, 0)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // dof_tau
  if (!rosidl_runtime_c__float__Sequence__init(&msg->dof_tau, 0)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // ang_vel
  if (!rosidl_runtime_c__float__Sequence__init(&msg->ang_vel, 0)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // proj_grav
  if (!rosidl_runtime_c__float__Sequence__init(&msg->proj_grav, 0)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // lin_vel
  if (!rosidl_runtime_c__float__Sequence__init(&msg->lin_vel, 0)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  // height_map
  if (!rosidl_runtime_c__float__Sequence__init(&msg->height_map, 0)) {
    core__msg__RobotReport__fini(msg);
    return false;
  }
  return true;
}

void
core__msg__RobotReport__fini(core__msg__RobotReport * msg)
{
  if (!msg) {
    return;
  }
  // robot_state
  // robot_state_name
  rosidl_runtime_c__String__fini(&msg->robot_state_name);
  // robot_initialized
  // custom_drive_id
  // active_command_source
  // active_command_source_name
  rosidl_runtime_c__String__fini(&msg->active_command_source_name);
  // active_command_fresh
  // sdk_mode_enabled
  // data_collection_mode_enabled
  // motion_command
  // physical_estop
  // physical_fault
  // comm_estop
  // comm_fault
  // command_estop
  // safety_estop
  // safety_fault
  // controller_failure
  // error_reason
  rosidl_runtime_c__String__fini(&msg->error_reason);
  // motor_pattern
  rosidl_runtime_c__String__Sequence__fini(&msg->motor_pattern);
  // motor_pattern_ok
  rosidl_runtime_c__boolean__Sequence__fini(&msg->motor_pattern_ok);
  // motor_err
  rosidl_runtime_c__String__Sequence__fini(&msg->motor_err);
  // battery_voltage
  rosidl_runtime_c__String__fini(&msg->battery_voltage);
  // battery_soc
  rosidl_runtime_c__String__fini(&msg->battery_soc);
  // battery_current
  rosidl_runtime_c__String__fini(&msg->battery_current);
  // battery_temperature
  rosidl_runtime_c__String__fini(&msg->battery_temperature);
  // battery_power
  rosidl_runtime_c__String__fini(&msg->battery_power);
  // dof_pos
  rosidl_runtime_c__float__Sequence__fini(&msg->dof_pos);
  // dof_vel
  rosidl_runtime_c__float__Sequence__fini(&msg->dof_vel);
  // dof_tau
  rosidl_runtime_c__float__Sequence__fini(&msg->dof_tau);
  // ang_vel
  rosidl_runtime_c__float__Sequence__fini(&msg->ang_vel);
  // proj_grav
  rosidl_runtime_c__float__Sequence__fini(&msg->proj_grav);
  // lin_vel
  rosidl_runtime_c__float__Sequence__fini(&msg->lin_vel);
  // height_map
  rosidl_runtime_c__float__Sequence__fini(&msg->height_map);
}

bool
core__msg__RobotReport__are_equal(const core__msg__RobotReport * lhs, const core__msg__RobotReport * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // robot_state
  if (lhs->robot_state != rhs->robot_state) {
    return false;
  }
  // robot_state_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->robot_state_name), &(rhs->robot_state_name)))
  {
    return false;
  }
  // robot_initialized
  if (lhs->robot_initialized != rhs->robot_initialized) {
    return false;
  }
  // custom_drive_id
  if (lhs->custom_drive_id != rhs->custom_drive_id) {
    return false;
  }
  // active_command_source
  if (lhs->active_command_source != rhs->active_command_source) {
    return false;
  }
  // active_command_source_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->active_command_source_name), &(rhs->active_command_source_name)))
  {
    return false;
  }
  // active_command_fresh
  if (lhs->active_command_fresh != rhs->active_command_fresh) {
    return false;
  }
  // sdk_mode_enabled
  if (lhs->sdk_mode_enabled != rhs->sdk_mode_enabled) {
    return false;
  }
  // data_collection_mode_enabled
  if (lhs->data_collection_mode_enabled != rhs->data_collection_mode_enabled) {
    return false;
  }
  // motion_command
  for (size_t i = 0; i < 8; ++i) {
    if (lhs->motion_command[i] != rhs->motion_command[i]) {
      return false;
    }
  }
  // physical_estop
  if (lhs->physical_estop != rhs->physical_estop) {
    return false;
  }
  // physical_fault
  if (lhs->physical_fault != rhs->physical_fault) {
    return false;
  }
  // comm_estop
  if (lhs->comm_estop != rhs->comm_estop) {
    return false;
  }
  // comm_fault
  if (lhs->comm_fault != rhs->comm_fault) {
    return false;
  }
  // command_estop
  if (lhs->command_estop != rhs->command_estop) {
    return false;
  }
  // safety_estop
  if (lhs->safety_estop != rhs->safety_estop) {
    return false;
  }
  // safety_fault
  if (lhs->safety_fault != rhs->safety_fault) {
    return false;
  }
  // controller_failure
  if (lhs->controller_failure != rhs->controller_failure) {
    return false;
  }
  // error_reason
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->error_reason), &(rhs->error_reason)))
  {
    return false;
  }
  // motor_pattern
  if (!rosidl_runtime_c__String__Sequence__are_equal(
      &(lhs->motor_pattern), &(rhs->motor_pattern)))
  {
    return false;
  }
  // motor_pattern_ok
  if (!rosidl_runtime_c__boolean__Sequence__are_equal(
      &(lhs->motor_pattern_ok), &(rhs->motor_pattern_ok)))
  {
    return false;
  }
  // motor_err
  if (!rosidl_runtime_c__String__Sequence__are_equal(
      &(lhs->motor_err), &(rhs->motor_err)))
  {
    return false;
  }
  // battery_voltage
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->battery_voltage), &(rhs->battery_voltage)))
  {
    return false;
  }
  // battery_soc
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->battery_soc), &(rhs->battery_soc)))
  {
    return false;
  }
  // battery_current
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->battery_current), &(rhs->battery_current)))
  {
    return false;
  }
  // battery_temperature
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->battery_temperature), &(rhs->battery_temperature)))
  {
    return false;
  }
  // battery_power
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->battery_power), &(rhs->battery_power)))
  {
    return false;
  }
  // dof_pos
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->dof_pos), &(rhs->dof_pos)))
  {
    return false;
  }
  // dof_vel
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->dof_vel), &(rhs->dof_vel)))
  {
    return false;
  }
  // dof_tau
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->dof_tau), &(rhs->dof_tau)))
  {
    return false;
  }
  // ang_vel
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->ang_vel), &(rhs->ang_vel)))
  {
    return false;
  }
  // proj_grav
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->proj_grav), &(rhs->proj_grav)))
  {
    return false;
  }
  // lin_vel
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->lin_vel), &(rhs->lin_vel)))
  {
    return false;
  }
  // height_map
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->height_map), &(rhs->height_map)))
  {
    return false;
  }
  return true;
}

bool
core__msg__RobotReport__copy(
  const core__msg__RobotReport * input,
  core__msg__RobotReport * output)
{
  if (!input || !output) {
    return false;
  }
  // robot_state
  output->robot_state = input->robot_state;
  // robot_state_name
  if (!rosidl_runtime_c__String__copy(
      &(input->robot_state_name), &(output->robot_state_name)))
  {
    return false;
  }
  // robot_initialized
  output->robot_initialized = input->robot_initialized;
  // custom_drive_id
  output->custom_drive_id = input->custom_drive_id;
  // active_command_source
  output->active_command_source = input->active_command_source;
  // active_command_source_name
  if (!rosidl_runtime_c__String__copy(
      &(input->active_command_source_name), &(output->active_command_source_name)))
  {
    return false;
  }
  // active_command_fresh
  output->active_command_fresh = input->active_command_fresh;
  // sdk_mode_enabled
  output->sdk_mode_enabled = input->sdk_mode_enabled;
  // data_collection_mode_enabled
  output->data_collection_mode_enabled = input->data_collection_mode_enabled;
  // motion_command
  for (size_t i = 0; i < 8; ++i) {
    output->motion_command[i] = input->motion_command[i];
  }
  // physical_estop
  output->physical_estop = input->physical_estop;
  // physical_fault
  output->physical_fault = input->physical_fault;
  // comm_estop
  output->comm_estop = input->comm_estop;
  // comm_fault
  output->comm_fault = input->comm_fault;
  // command_estop
  output->command_estop = input->command_estop;
  // safety_estop
  output->safety_estop = input->safety_estop;
  // safety_fault
  output->safety_fault = input->safety_fault;
  // controller_failure
  output->controller_failure = input->controller_failure;
  // error_reason
  if (!rosidl_runtime_c__String__copy(
      &(input->error_reason), &(output->error_reason)))
  {
    return false;
  }
  // motor_pattern
  if (!rosidl_runtime_c__String__Sequence__copy(
      &(input->motor_pattern), &(output->motor_pattern)))
  {
    return false;
  }
  // motor_pattern_ok
  if (!rosidl_runtime_c__boolean__Sequence__copy(
      &(input->motor_pattern_ok), &(output->motor_pattern_ok)))
  {
    return false;
  }
  // motor_err
  if (!rosidl_runtime_c__String__Sequence__copy(
      &(input->motor_err), &(output->motor_err)))
  {
    return false;
  }
  // battery_voltage
  if (!rosidl_runtime_c__String__copy(
      &(input->battery_voltage), &(output->battery_voltage)))
  {
    return false;
  }
  // battery_soc
  if (!rosidl_runtime_c__String__copy(
      &(input->battery_soc), &(output->battery_soc)))
  {
    return false;
  }
  // battery_current
  if (!rosidl_runtime_c__String__copy(
      &(input->battery_current), &(output->battery_current)))
  {
    return false;
  }
  // battery_temperature
  if (!rosidl_runtime_c__String__copy(
      &(input->battery_temperature), &(output->battery_temperature)))
  {
    return false;
  }
  // battery_power
  if (!rosidl_runtime_c__String__copy(
      &(input->battery_power), &(output->battery_power)))
  {
    return false;
  }
  // dof_pos
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->dof_pos), &(output->dof_pos)))
  {
    return false;
  }
  // dof_vel
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->dof_vel), &(output->dof_vel)))
  {
    return false;
  }
  // dof_tau
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->dof_tau), &(output->dof_tau)))
  {
    return false;
  }
  // ang_vel
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->ang_vel), &(output->ang_vel)))
  {
    return false;
  }
  // proj_grav
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->proj_grav), &(output->proj_grav)))
  {
    return false;
  }
  // lin_vel
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->lin_vel), &(output->lin_vel)))
  {
    return false;
  }
  // height_map
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->height_map), &(output->height_map)))
  {
    return false;
  }
  return true;
}

core__msg__RobotReport *
core__msg__RobotReport__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__msg__RobotReport * msg = (core__msg__RobotReport *)allocator.allocate(sizeof(core__msg__RobotReport), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(core__msg__RobotReport));
  bool success = core__msg__RobotReport__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
core__msg__RobotReport__destroy(core__msg__RobotReport * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    core__msg__RobotReport__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
core__msg__RobotReport__Sequence__init(core__msg__RobotReport__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__msg__RobotReport * data = NULL;

  if (size) {
    data = (core__msg__RobotReport *)allocator.zero_allocate(size, sizeof(core__msg__RobotReport), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = core__msg__RobotReport__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        core__msg__RobotReport__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
core__msg__RobotReport__Sequence__fini(core__msg__RobotReport__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      core__msg__RobotReport__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

core__msg__RobotReport__Sequence *
core__msg__RobotReport__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__msg__RobotReport__Sequence * array = (core__msg__RobotReport__Sequence *)allocator.allocate(sizeof(core__msg__RobotReport__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = core__msg__RobotReport__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
core__msg__RobotReport__Sequence__destroy(core__msg__RobotReport__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    core__msg__RobotReport__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
core__msg__RobotReport__Sequence__are_equal(const core__msg__RobotReport__Sequence * lhs, const core__msg__RobotReport__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!core__msg__RobotReport__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
core__msg__RobotReport__Sequence__copy(
  const core__msg__RobotReport__Sequence * input,
  core__msg__RobotReport__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(core__msg__RobotReport);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    core__msg__RobotReport * data =
      (core__msg__RobotReport *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!core__msg__RobotReport__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          core__msg__RobotReport__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!core__msg__RobotReport__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
