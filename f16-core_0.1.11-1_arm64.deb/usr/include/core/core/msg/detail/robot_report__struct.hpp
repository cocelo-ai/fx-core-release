// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from core:msg/RobotReport.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__ROBOT_REPORT__STRUCT_HPP_
#define CORE__MSG__DETAIL__ROBOT_REPORT__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__core__msg__RobotReport __attribute__((deprecated))
#else
# define DEPRECATED__core__msg__RobotReport __declspec(deprecated)
#endif

namespace core
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct RobotReport_
{
  using Type = RobotReport_<ContainerAllocator>;

  explicit RobotReport_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->robot_state = 0;
      this->robot_state_name = "";
      this->robot_initialized = false;
      this->custom_drive_id = 0;
      this->active_command_source = 0;
      this->active_command_source_name = "";
      this->active_command_fresh = false;
      this->sdk_mode_enabled = false;
      this->data_collection_mode_enabled = false;
      std::fill<typename std::array<float, 8>::iterator, float>(this->motion_command.begin(), this->motion_command.end(), 0.0f);
      this->physical_estop = false;
      this->physical_fault = false;
      this->comm_estop = false;
      this->comm_fault = false;
      this->command_estop = false;
      this->safety_estop = false;
      this->safety_fault = false;
      this->controller_failure = false;
      this->error_reason = "";
      this->battery_voltage = "";
      this->battery_soc = "";
      this->battery_current = "";
      this->battery_temperature = "";
      this->battery_power = "";
    }
  }

  explicit RobotReport_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : robot_state_name(_alloc),
    active_command_source_name(_alloc),
    motion_command(_alloc),
    error_reason(_alloc),
    battery_voltage(_alloc),
    battery_soc(_alloc),
    battery_current(_alloc),
    battery_temperature(_alloc),
    battery_power(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->robot_state = 0;
      this->robot_state_name = "";
      this->robot_initialized = false;
      this->custom_drive_id = 0;
      this->active_command_source = 0;
      this->active_command_source_name = "";
      this->active_command_fresh = false;
      this->sdk_mode_enabled = false;
      this->data_collection_mode_enabled = false;
      std::fill<typename std::array<float, 8>::iterator, float>(this->motion_command.begin(), this->motion_command.end(), 0.0f);
      this->physical_estop = false;
      this->physical_fault = false;
      this->comm_estop = false;
      this->comm_fault = false;
      this->command_estop = false;
      this->safety_estop = false;
      this->safety_fault = false;
      this->controller_failure = false;
      this->error_reason = "";
      this->battery_voltage = "";
      this->battery_soc = "";
      this->battery_current = "";
      this->battery_temperature = "";
      this->battery_power = "";
    }
  }

  // field types and members
  using _robot_state_type =
    uint8_t;
  _robot_state_type robot_state;
  using _robot_state_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _robot_state_name_type robot_state_name;
  using _robot_initialized_type =
    bool;
  _robot_initialized_type robot_initialized;
  using _custom_drive_id_type =
    uint8_t;
  _custom_drive_id_type custom_drive_id;
  using _active_command_source_type =
    uint8_t;
  _active_command_source_type active_command_source;
  using _active_command_source_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _active_command_source_name_type active_command_source_name;
  using _active_command_fresh_type =
    bool;
  _active_command_fresh_type active_command_fresh;
  using _sdk_mode_enabled_type =
    bool;
  _sdk_mode_enabled_type sdk_mode_enabled;
  using _data_collection_mode_enabled_type =
    bool;
  _data_collection_mode_enabled_type data_collection_mode_enabled;
  using _motion_command_type =
    std::array<float, 8>;
  _motion_command_type motion_command;
  using _physical_estop_type =
    bool;
  _physical_estop_type physical_estop;
  using _physical_fault_type =
    bool;
  _physical_fault_type physical_fault;
  using _comm_estop_type =
    bool;
  _comm_estop_type comm_estop;
  using _comm_fault_type =
    bool;
  _comm_fault_type comm_fault;
  using _command_estop_type =
    bool;
  _command_estop_type command_estop;
  using _safety_estop_type =
    bool;
  _safety_estop_type safety_estop;
  using _safety_fault_type =
    bool;
  _safety_fault_type safety_fault;
  using _controller_failure_type =
    bool;
  _controller_failure_type controller_failure;
  using _error_reason_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _error_reason_type error_reason;
  using _motor_pattern_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _motor_pattern_type motor_pattern;
  using _motor_pattern_ok_type =
    std::vector<bool, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<bool>>;
  _motor_pattern_ok_type motor_pattern_ok;
  using _motor_err_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _motor_err_type motor_err;
  using _battery_voltage_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _battery_voltage_type battery_voltage;
  using _battery_soc_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _battery_soc_type battery_soc;
  using _battery_current_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _battery_current_type battery_current;
  using _battery_temperature_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _battery_temperature_type battery_temperature;
  using _battery_power_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _battery_power_type battery_power;
  using _dof_pos_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _dof_pos_type dof_pos;
  using _dof_vel_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _dof_vel_type dof_vel;
  using _dof_tau_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _dof_tau_type dof_tau;
  using _ang_vel_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _ang_vel_type ang_vel;
  using _proj_grav_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _proj_grav_type proj_grav;
  using _lin_vel_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _lin_vel_type lin_vel;
  using _height_map_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _height_map_type height_map;

  // setters for named parameter idiom
  Type & set__robot_state(
    const uint8_t & _arg)
  {
    this->robot_state = _arg;
    return *this;
  }
  Type & set__robot_state_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->robot_state_name = _arg;
    return *this;
  }
  Type & set__robot_initialized(
    const bool & _arg)
  {
    this->robot_initialized = _arg;
    return *this;
  }
  Type & set__custom_drive_id(
    const uint8_t & _arg)
  {
    this->custom_drive_id = _arg;
    return *this;
  }
  Type & set__active_command_source(
    const uint8_t & _arg)
  {
    this->active_command_source = _arg;
    return *this;
  }
  Type & set__active_command_source_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->active_command_source_name = _arg;
    return *this;
  }
  Type & set__active_command_fresh(
    const bool & _arg)
  {
    this->active_command_fresh = _arg;
    return *this;
  }
  Type & set__sdk_mode_enabled(
    const bool & _arg)
  {
    this->sdk_mode_enabled = _arg;
    return *this;
  }
  Type & set__data_collection_mode_enabled(
    const bool & _arg)
  {
    this->data_collection_mode_enabled = _arg;
    return *this;
  }
  Type & set__motion_command(
    const std::array<float, 8> & _arg)
  {
    this->motion_command = _arg;
    return *this;
  }
  Type & set__physical_estop(
    const bool & _arg)
  {
    this->physical_estop = _arg;
    return *this;
  }
  Type & set__physical_fault(
    const bool & _arg)
  {
    this->physical_fault = _arg;
    return *this;
  }
  Type & set__comm_estop(
    const bool & _arg)
  {
    this->comm_estop = _arg;
    return *this;
  }
  Type & set__comm_fault(
    const bool & _arg)
  {
    this->comm_fault = _arg;
    return *this;
  }
  Type & set__command_estop(
    const bool & _arg)
  {
    this->command_estop = _arg;
    return *this;
  }
  Type & set__safety_estop(
    const bool & _arg)
  {
    this->safety_estop = _arg;
    return *this;
  }
  Type & set__safety_fault(
    const bool & _arg)
  {
    this->safety_fault = _arg;
    return *this;
  }
  Type & set__controller_failure(
    const bool & _arg)
  {
    this->controller_failure = _arg;
    return *this;
  }
  Type & set__error_reason(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->error_reason = _arg;
    return *this;
  }
  Type & set__motor_pattern(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->motor_pattern = _arg;
    return *this;
  }
  Type & set__motor_pattern_ok(
    const std::vector<bool, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<bool>> & _arg)
  {
    this->motor_pattern_ok = _arg;
    return *this;
  }
  Type & set__motor_err(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->motor_err = _arg;
    return *this;
  }
  Type & set__battery_voltage(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->battery_voltage = _arg;
    return *this;
  }
  Type & set__battery_soc(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->battery_soc = _arg;
    return *this;
  }
  Type & set__battery_current(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->battery_current = _arg;
    return *this;
  }
  Type & set__battery_temperature(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->battery_temperature = _arg;
    return *this;
  }
  Type & set__battery_power(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->battery_power = _arg;
    return *this;
  }
  Type & set__dof_pos(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->dof_pos = _arg;
    return *this;
  }
  Type & set__dof_vel(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->dof_vel = _arg;
    return *this;
  }
  Type & set__dof_tau(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->dof_tau = _arg;
    return *this;
  }
  Type & set__ang_vel(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->ang_vel = _arg;
    return *this;
  }
  Type & set__proj_grav(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->proj_grav = _arg;
    return *this;
  }
  Type & set__lin_vel(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->lin_vel = _arg;
    return *this;
  }
  Type & set__height_map(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->height_map = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    core::msg::RobotReport_<ContainerAllocator> *;
  using ConstRawPtr =
    const core::msg::RobotReport_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<core::msg::RobotReport_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<core::msg::RobotReport_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      core::msg::RobotReport_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<core::msg::RobotReport_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      core::msg::RobotReport_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<core::msg::RobotReport_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<core::msg::RobotReport_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<core::msg::RobotReport_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__core__msg__RobotReport
    std::shared_ptr<core::msg::RobotReport_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__core__msg__RobotReport
    std::shared_ptr<core::msg::RobotReport_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RobotReport_ & other) const
  {
    if (this->robot_state != other.robot_state) {
      return false;
    }
    if (this->robot_state_name != other.robot_state_name) {
      return false;
    }
    if (this->robot_initialized != other.robot_initialized) {
      return false;
    }
    if (this->custom_drive_id != other.custom_drive_id) {
      return false;
    }
    if (this->active_command_source != other.active_command_source) {
      return false;
    }
    if (this->active_command_source_name != other.active_command_source_name) {
      return false;
    }
    if (this->active_command_fresh != other.active_command_fresh) {
      return false;
    }
    if (this->sdk_mode_enabled != other.sdk_mode_enabled) {
      return false;
    }
    if (this->data_collection_mode_enabled != other.data_collection_mode_enabled) {
      return false;
    }
    if (this->motion_command != other.motion_command) {
      return false;
    }
    if (this->physical_estop != other.physical_estop) {
      return false;
    }
    if (this->physical_fault != other.physical_fault) {
      return false;
    }
    if (this->comm_estop != other.comm_estop) {
      return false;
    }
    if (this->comm_fault != other.comm_fault) {
      return false;
    }
    if (this->command_estop != other.command_estop) {
      return false;
    }
    if (this->safety_estop != other.safety_estop) {
      return false;
    }
    if (this->safety_fault != other.safety_fault) {
      return false;
    }
    if (this->controller_failure != other.controller_failure) {
      return false;
    }
    if (this->error_reason != other.error_reason) {
      return false;
    }
    if (this->motor_pattern != other.motor_pattern) {
      return false;
    }
    if (this->motor_pattern_ok != other.motor_pattern_ok) {
      return false;
    }
    if (this->motor_err != other.motor_err) {
      return false;
    }
    if (this->battery_voltage != other.battery_voltage) {
      return false;
    }
    if (this->battery_soc != other.battery_soc) {
      return false;
    }
    if (this->battery_current != other.battery_current) {
      return false;
    }
    if (this->battery_temperature != other.battery_temperature) {
      return false;
    }
    if (this->battery_power != other.battery_power) {
      return false;
    }
    if (this->dof_pos != other.dof_pos) {
      return false;
    }
    if (this->dof_vel != other.dof_vel) {
      return false;
    }
    if (this->dof_tau != other.dof_tau) {
      return false;
    }
    if (this->ang_vel != other.ang_vel) {
      return false;
    }
    if (this->proj_grav != other.proj_grav) {
      return false;
    }
    if (this->lin_vel != other.lin_vel) {
      return false;
    }
    if (this->height_map != other.height_map) {
      return false;
    }
    return true;
  }
  bool operator!=(const RobotReport_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RobotReport_

// alias to use template instance with default allocator
using RobotReport =
  core::msg::RobotReport_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace core

#endif  // CORE__MSG__DETAIL__ROBOT_REPORT__STRUCT_HPP_
