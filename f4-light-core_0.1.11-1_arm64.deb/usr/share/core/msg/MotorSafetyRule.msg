uint8 motor_id
JointSafety safety
