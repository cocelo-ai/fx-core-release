float32[13] motion_command
EventCore event
uint8 custom_drive_id
