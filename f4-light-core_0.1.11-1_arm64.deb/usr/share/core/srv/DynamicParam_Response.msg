
bool success
string reason
