# Full snapshot of every runtime parameter that may change after startup.
# Fields not listed here remain static and continue to come only from YAML.

# Robot gains and torque limits paired by motor id.
uint8[] robot_motor_ids
float32[] robot_motor_kp
float32[] robot_motor_kd
float32[] robot_max_torque_nm

# Joystick motion-slot mapping and runtime shaping values.
int32 joystick_left_x
int32 joystick_left_y
int32 joystick_right_x
int32 joystick_right_y
int32 joystick_dpad_x
int32 joystick_dpad_y
int32 joystick_left_btn
int32 joystick_rb_left_x
int32 joystick_rb_left_y
int32 joystick_rb_right_x
int32 joystick_rb_right_y
int32 joystick_rb_dpad_x
int32 joystick_rb_dpad_y
float32 joystick_dpad_step_x
float32 joystick_dpad_step_y
float32 joystick_smoothness
float32 joystick_deadzone
float32[13] joystick_min_motion_command
float32[13] joystick_max_motion_command

# Command interface runtime arbitration and motion limits.
float64 cmd_priority_hold_sec
float64 cmd_packet_timeout_sec
bool use_command_filter
int32 motion_command_index_linear_vel_x
int32 motion_command_index_linear_vel_y
int32 motion_command_index_angular_vel_z
int32 motion_command_index_position_z
int32 motion_command_index_orientation_roll
int32 motion_command_index_orientation_pitch
float32[13] command_iface_min_motion_command
float32[13] command_iface_max_motion_command

# Safety policy. The service always carries the full rule snapshot.
float32 battery_low_soc_threshold
float32 motor_temperature_threshold
float32 battery_temperature_threshold
float32[] wma_weights
MotorSafetyRule[] safety_motor_rules
ImuSafetyRule[] safety_imu_rules
