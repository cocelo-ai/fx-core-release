# generated from
# rosidl_cmake/cmake/template/rosidl_cmake_export_typesupport_libraries.cmake.in

set(_exported_typesupport_libraries
  "__rosidl_typesupport_fastrtps_c:core__rosidl_typesupport_fastrtps_c;__rosidl_typesupport_fastrtps_cpp:core__rosidl_typesupport_fastrtps_cpp")

# populate core_LIBRARIES_<suffix>
if(NOT _exported_typesupport_libraries STREQUAL "")
  # loop over typesupport libraries
  foreach(_tuple ${_exported_typesupport_libraries})
    string(REPLACE ":" ";" _tuple "${_tuple}")
    list(GET _tuple 0 _suffix)
    list(GET _tuple 1 _library)

    if(NOT IS_ABSOLUTE "${_library}")
      # search for library target relative to this CMake file
      unset(_core_exported_typesupport_library)
      unset(_core_exported_typesupport_library CACHE)
      find_library(
        _core_exported_typesupport_library NAMES "${_library}"
        PATHS "${core_DIR}/../../../lib"
        NO_DEFAULT_PATH NO_CMAKE_FIND_ROOT_PATH
      )

      if(NOT _core_exported_typesupport_library)
        # the library wasn't found
        message(FATAL_ERROR
          "Package 'core' exports the typesupport library '${_library}' which couldn't be found")
      elseif(NOT IS_ABSOLUTE "${_core_exported_typesupport_library}")
        # the found library must be an absolute path
        message(FATAL_ERROR
          "Package 'core' found the typesupport library '${_library}' at '${_core_exported_typesupport_library}' "
          "which is not an absolute path")
      elseif(NOT EXISTS "${_core_exported_typesupport_library}")
        # the found library must exist
        message(FATAL_ERROR
          "Package 'core' found the typesupport library '${_core_exported_typesupport_library}' which doesn't exist")
      else()
        list(APPEND core_LIBRARIES${_suffix} ${_cfg} "${_core_exported_typesupport_library}")
      endif()

      unset(_core_exported_typesupport_library)
      unset(_core_exported_typesupport_library CACHE)

    else()
      if(NOT EXISTS "${_library}")
        # the found library must exist
        message(WARNING "Package 'core' exports the typesupport library '${_library}' which doesn't exist")
      else()
        list(APPEND core_LIBRARIES${_suffix} "${_library}")
      endif()
    endif()
  endforeach()
endif()
