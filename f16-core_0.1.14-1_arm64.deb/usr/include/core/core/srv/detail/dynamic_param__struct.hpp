// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from core:srv/DynamicParam.idl
// generated code does not contain a copyright notice

#ifndef CORE__SRV__DETAIL__DYNAMIC_PARAM__STRUCT_HPP_
#define CORE__SRV__DETAIL__DYNAMIC_PARAM__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'safety_motor_rules'
#include "core/msg/detail/motor_safety_rule__struct.hpp"
// Member 'safety_imu_rules'
#include "core/msg/detail/imu_safety_rule__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__core__srv__DynamicParam_Request __attribute__((deprecated))
#else
# define DEPRECATED__core__srv__DynamicParam_Request __declspec(deprecated)
#endif

namespace core
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct DynamicParam_Request_
{
  using Type = DynamicParam_Request_<ContainerAllocator>;

  explicit DynamicParam_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->joystick_left_x = 0l;
      this->joystick_left_y = 0l;
      this->joystick_right_x = 0l;
      this->joystick_right_y = 0l;
      this->joystick_dpad_x = 0l;
      this->joystick_dpad_y = 0l;
      this->joystick_left_btn = 0l;
      this->joystick_rb_left_x = 0l;
      this->joystick_rb_left_y = 0l;
      this->joystick_rb_right_x = 0l;
      this->joystick_rb_right_y = 0l;
      this->joystick_rb_dpad_x = 0l;
      this->joystick_rb_dpad_y = 0l;
      this->joystick_dpad_step_x = 0.0f;
      this->joystick_dpad_step_y = 0.0f;
      this->joystick_smoothness = 0.0f;
      this->joystick_deadzone = 0.0f;
      std::fill<typename std::array<float, 15>::iterator, float>(this->joystick_min_motion_command.begin(), this->joystick_min_motion_command.end(), 0.0f);
      std::fill<typename std::array<float, 15>::iterator, float>(this->joystick_max_motion_command.begin(), this->joystick_max_motion_command.end(), 0.0f);
      this->cmd_priority_hold_sec = 0.0;
      this->cmd_packet_timeout_sec = 0.0;
      this->use_command_filter = false;
      this->motion_command_index_linear_vel_x = 0l;
      this->motion_command_index_linear_vel_y = 0l;
      this->motion_command_index_angular_vel_z = 0l;
      this->motion_command_index_position_z = 0l;
      this->motion_command_index_orientation_roll = 0l;
      this->motion_command_index_orientation_pitch = 0l;
      std::fill<typename std::array<float, 15>::iterator, float>(this->command_iface_min_motion_command.begin(), this->command_iface_min_motion_command.end(), 0.0f);
      std::fill<typename std::array<float, 15>::iterator, float>(this->command_iface_max_motion_command.begin(), this->command_iface_max_motion_command.end(), 0.0f);
      this->battery_low_soc_threshold = 0.0f;
      this->motor_temperature_threshold = 0.0f;
      this->battery_temperature_threshold = 0.0f;
    }
  }

  explicit DynamicParam_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : joystick_min_motion_command(_alloc),
    joystick_max_motion_command(_alloc),
    command_iface_min_motion_command(_alloc),
    command_iface_max_motion_command(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->joystick_left_x = 0l;
      this->joystick_left_y = 0l;
      this->joystick_right_x = 0l;
      this->joystick_right_y = 0l;
      this->joystick_dpad_x = 0l;
      this->joystick_dpad_y = 0l;
      this->joystick_left_btn = 0l;
      this->joystick_rb_left_x = 0l;
      this->joystick_rb_left_y = 0l;
      this->joystick_rb_right_x = 0l;
      this->joystick_rb_right_y = 0l;
      this->joystick_rb_dpad_x = 0l;
      this->joystick_rb_dpad_y = 0l;
      this->joystick_dpad_step_x = 0.0f;
      this->joystick_dpad_step_y = 0.0f;
      this->joystick_smoothness = 0.0f;
      this->joystick_deadzone = 0.0f;
      std::fill<typename std::array<float, 15>::iterator, float>(this->joystick_min_motion_command.begin(), this->joystick_min_motion_command.end(), 0.0f);
      std::fill<typename std::array<float, 15>::iterator, float>(this->joystick_max_motion_command.begin(), this->joystick_max_motion_command.end(), 0.0f);
      this->cmd_priority_hold_sec = 0.0;
      this->cmd_packet_timeout_sec = 0.0;
      this->use_command_filter = false;
      this->motion_command_index_linear_vel_x = 0l;
      this->motion_command_index_linear_vel_y = 0l;
      this->motion_command_index_angular_vel_z = 0l;
      this->motion_command_index_position_z = 0l;
      this->motion_command_index_orientation_roll = 0l;
      this->motion_command_index_orientation_pitch = 0l;
      std::fill<typename std::array<float, 15>::iterator, float>(this->command_iface_min_motion_command.begin(), this->command_iface_min_motion_command.end(), 0.0f);
      std::fill<typename std::array<float, 15>::iterator, float>(this->command_iface_max_motion_command.begin(), this->command_iface_max_motion_command.end(), 0.0f);
      this->battery_low_soc_threshold = 0.0f;
      this->motor_temperature_threshold = 0.0f;
      this->battery_temperature_threshold = 0.0f;
    }
  }

  // field types and members
  using _robot_motor_ids_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _robot_motor_ids_type robot_motor_ids;
  using _robot_motor_kp_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _robot_motor_kp_type robot_motor_kp;
  using _robot_motor_kd_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _robot_motor_kd_type robot_motor_kd;
  using _robot_max_torque_nm_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _robot_max_torque_nm_type robot_max_torque_nm;
  using _joystick_left_x_type =
    int32_t;
  _joystick_left_x_type joystick_left_x;
  using _joystick_left_y_type =
    int32_t;
  _joystick_left_y_type joystick_left_y;
  using _joystick_right_x_type =
    int32_t;
  _joystick_right_x_type joystick_right_x;
  using _joystick_right_y_type =
    int32_t;
  _joystick_right_y_type joystick_right_y;
  using _joystick_dpad_x_type =
    int32_t;
  _joystick_dpad_x_type joystick_dpad_x;
  using _joystick_dpad_y_type =
    int32_t;
  _joystick_dpad_y_type joystick_dpad_y;
  using _joystick_left_btn_type =
    int32_t;
  _joystick_left_btn_type joystick_left_btn;
  using _joystick_rb_left_x_type =
    int32_t;
  _joystick_rb_left_x_type joystick_rb_left_x;
  using _joystick_rb_left_y_type =
    int32_t;
  _joystick_rb_left_y_type joystick_rb_left_y;
  using _joystick_rb_right_x_type =
    int32_t;
  _joystick_rb_right_x_type joystick_rb_right_x;
  using _joystick_rb_right_y_type =
    int32_t;
  _joystick_rb_right_y_type joystick_rb_right_y;
  using _joystick_rb_dpad_x_type =
    int32_t;
  _joystick_rb_dpad_x_type joystick_rb_dpad_x;
  using _joystick_rb_dpad_y_type =
    int32_t;
  _joystick_rb_dpad_y_type joystick_rb_dpad_y;
  using _joystick_dpad_step_x_type =
    float;
  _joystick_dpad_step_x_type joystick_dpad_step_x;
  using _joystick_dpad_step_y_type =
    float;
  _joystick_dpad_step_y_type joystick_dpad_step_y;
  using _joystick_smoothness_type =
    float;
  _joystick_smoothness_type joystick_smoothness;
  using _joystick_deadzone_type =
    float;
  _joystick_deadzone_type joystick_deadzone;
  using _joystick_min_motion_command_type =
    std::array<float, 15>;
  _joystick_min_motion_command_type joystick_min_motion_command;
  using _joystick_max_motion_command_type =
    std::array<float, 15>;
  _joystick_max_motion_command_type joystick_max_motion_command;
  using _cmd_priority_hold_sec_type =
    double;
  _cmd_priority_hold_sec_type cmd_priority_hold_sec;
  using _cmd_packet_timeout_sec_type =
    double;
  _cmd_packet_timeout_sec_type cmd_packet_timeout_sec;
  using _use_command_filter_type =
    bool;
  _use_command_filter_type use_command_filter;
  using _motion_command_index_linear_vel_x_type =
    int32_t;
  _motion_command_index_linear_vel_x_type motion_command_index_linear_vel_x;
  using _motion_command_index_linear_vel_y_type =
    int32_t;
  _motion_command_index_linear_vel_y_type motion_command_index_linear_vel_y;
  using _motion_command_index_angular_vel_z_type =
    int32_t;
  _motion_command_index_angular_vel_z_type motion_command_index_angular_vel_z;
  using _motion_command_index_position_z_type =
    int32_t;
  _motion_command_index_position_z_type motion_command_index_position_z;
  using _motion_command_index_orientation_roll_type =
    int32_t;
  _motion_command_index_orientation_roll_type motion_command_index_orientation_roll;
  using _motion_command_index_orientation_pitch_type =
    int32_t;
  _motion_command_index_orientation_pitch_type motion_command_index_orientation_pitch;
  using _command_iface_min_motion_command_type =
    std::array<float, 15>;
  _command_iface_min_motion_command_type command_iface_min_motion_command;
  using _command_iface_max_motion_command_type =
    std::array<float, 15>;
  _command_iface_max_motion_command_type command_iface_max_motion_command;
  using _battery_low_soc_threshold_type =
    float;
  _battery_low_soc_threshold_type battery_low_soc_threshold;
  using _motor_temperature_threshold_type =
    float;
  _motor_temperature_threshold_type motor_temperature_threshold;
  using _battery_temperature_threshold_type =
    float;
  _battery_temperature_threshold_type battery_temperature_threshold;
  using _wma_weights_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _wma_weights_type wma_weights;
  using _safety_motor_rules_type =
    std::vector<core::msg::MotorSafetyRule_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<core::msg::MotorSafetyRule_<ContainerAllocator>>>;
  _safety_motor_rules_type safety_motor_rules;
  using _safety_imu_rules_type =
    std::vector<core::msg::ImuSafetyRule_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<core::msg::ImuSafetyRule_<ContainerAllocator>>>;
  _safety_imu_rules_type safety_imu_rules;

  // setters for named parameter idiom
  Type & set__robot_motor_ids(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->robot_motor_ids = _arg;
    return *this;
  }
  Type & set__robot_motor_kp(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->robot_motor_kp = _arg;
    return *this;
  }
  Type & set__robot_motor_kd(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->robot_motor_kd = _arg;
    return *this;
  }
  Type & set__robot_max_torque_nm(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->robot_max_torque_nm = _arg;
    return *this;
  }
  Type & set__joystick_left_x(
    const int32_t & _arg)
  {
    this->joystick_left_x = _arg;
    return *this;
  }
  Type & set__joystick_left_y(
    const int32_t & _arg)
  {
    this->joystick_left_y = _arg;
    return *this;
  }
  Type & set__joystick_right_x(
    const int32_t & _arg)
  {
    this->joystick_right_x = _arg;
    return *this;
  }
  Type & set__joystick_right_y(
    const int32_t & _arg)
  {
    this->joystick_right_y = _arg;
    return *this;
  }
  Type & set__joystick_dpad_x(
    const int32_t & _arg)
  {
    this->joystick_dpad_x = _arg;
    return *this;
  }
  Type & set__joystick_dpad_y(
    const int32_t & _arg)
  {
    this->joystick_dpad_y = _arg;
    return *this;
  }
  Type & set__joystick_left_btn(
    const int32_t & _arg)
  {
    this->joystick_left_btn = _arg;
    return *this;
  }
  Type & set__joystick_rb_left_x(
    const int32_t & _arg)
  {
    this->joystick_rb_left_x = _arg;
    return *this;
  }
  Type & set__joystick_rb_left_y(
    const int32_t & _arg)
  {
    this->joystick_rb_left_y = _arg;
    return *this;
  }
  Type & set__joystick_rb_right_x(
    const int32_t & _arg)
  {
    this->joystick_rb_right_x = _arg;
    return *this;
  }
  Type & set__joystick_rb_right_y(
    const int32_t & _arg)
  {
    this->joystick_rb_right_y = _arg;
    return *this;
  }
  Type & set__joystick_rb_dpad_x(
    const int32_t & _arg)
  {
    this->joystick_rb_dpad_x = _arg;
    return *this;
  }
  Type & set__joystick_rb_dpad_y(
    const int32_t & _arg)
  {
    this->joystick_rb_dpad_y = _arg;
    return *this;
  }
  Type & set__joystick_dpad_step_x(
    const float & _arg)
  {
    this->joystick_dpad_step_x = _arg;
    return *this;
  }
  Type & set__joystick_dpad_step_y(
    const float & _arg)
  {
    this->joystick_dpad_step_y = _arg;
    return *this;
  }
  Type & set__joystick_smoothness(
    const float & _arg)
  {
    this->joystick_smoothness = _arg;
    return *this;
  }
  Type & set__joystick_deadzone(
    const float & _arg)
  {
    this->joystick_deadzone = _arg;
    return *this;
  }
  Type & set__joystick_min_motion_command(
    const std::array<float, 15> & _arg)
  {
    this->joystick_min_motion_command = _arg;
    return *this;
  }
  Type & set__joystick_max_motion_command(
    const std::array<float, 15> & _arg)
  {
    this->joystick_max_motion_command = _arg;
    return *this;
  }
  Type & set__cmd_priority_hold_sec(
    const double & _arg)
  {
    this->cmd_priority_hold_sec = _arg;
    return *this;
  }
  Type & set__cmd_packet_timeout_sec(
    const double & _arg)
  {
    this->cmd_packet_timeout_sec = _arg;
    return *this;
  }
  Type & set__use_command_filter(
    const bool & _arg)
  {
    this->use_command_filter = _arg;
    return *this;
  }
  Type & set__motion_command_index_linear_vel_x(
    const int32_t & _arg)
  {
    this->motion_command_index_linear_vel_x = _arg;
    return *this;
  }
  Type & set__motion_command_index_linear_vel_y(
    const int32_t & _arg)
  {
    this->motion_command_index_linear_vel_y = _arg;
    return *this;
  }
  Type & set__motion_command_index_angular_vel_z(
    const int32_t & _arg)
  {
    this->motion_command_index_angular_vel_z = _arg;
    return *this;
  }
  Type & set__motion_command_index_position_z(
    const int32_t & _arg)
  {
    this->motion_command_index_position_z = _arg;
    return *this;
  }
  Type & set__motion_command_index_orientation_roll(
    const int32_t & _arg)
  {
    this->motion_command_index_orientation_roll = _arg;
    return *this;
  }
  Type & set__motion_command_index_orientation_pitch(
    const int32_t & _arg)
  {
    this->motion_command_index_orientation_pitch = _arg;
    return *this;
  }
  Type & set__command_iface_min_motion_command(
    const std::array<float, 15> & _arg)
  {
    this->command_iface_min_motion_command = _arg;
    return *this;
  }
  Type & set__command_iface_max_motion_command(
    const std::array<float, 15> & _arg)
  {
    this->command_iface_max_motion_command = _arg;
    return *this;
  }
  Type & set__battery_low_soc_threshold(
    const float & _arg)
  {
    this->battery_low_soc_threshold = _arg;
    return *this;
  }
  Type & set__motor_temperature_threshold(
    const float & _arg)
  {
    this->motor_temperature_threshold = _arg;
    return *this;
  }
  Type & set__battery_temperature_threshold(
    const float & _arg)
  {
    this->battery_temperature_threshold = _arg;
    return *this;
  }
  Type & set__wma_weights(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->wma_weights = _arg;
    return *this;
  }
  Type & set__safety_motor_rules(
    const std::vector<core::msg::MotorSafetyRule_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<core::msg::MotorSafetyRule_<ContainerAllocator>>> & _arg)
  {
    this->safety_motor_rules = _arg;
    return *this;
  }
  Type & set__safety_imu_rules(
    const std::vector<core::msg::ImuSafetyRule_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<core::msg::ImuSafetyRule_<ContainerAllocator>>> & _arg)
  {
    this->safety_imu_rules = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    core::srv::DynamicParam_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const core::srv::DynamicParam_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<core::srv::DynamicParam_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<core::srv::DynamicParam_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      core::srv::DynamicParam_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<core::srv::DynamicParam_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      core::srv::DynamicParam_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<core::srv::DynamicParam_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<core::srv::DynamicParam_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<core::srv::DynamicParam_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__core__srv__DynamicParam_Request
    std::shared_ptr<core::srv::DynamicParam_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__core__srv__DynamicParam_Request
    std::shared_ptr<core::srv::DynamicParam_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DynamicParam_Request_ & other) const
  {
    if (this->robot_motor_ids != other.robot_motor_ids) {
      return false;
    }
    if (this->robot_motor_kp != other.robot_motor_kp) {
      return false;
    }
    if (this->robot_motor_kd != other.robot_motor_kd) {
      return false;
    }
    if (this->robot_max_torque_nm != other.robot_max_torque_nm) {
      return false;
    }
    if (this->joystick_left_x != other.joystick_left_x) {
      return false;
    }
    if (this->joystick_left_y != other.joystick_left_y) {
      return false;
    }
    if (this->joystick_right_x != other.joystick_right_x) {
      return false;
    }
    if (this->joystick_right_y != other.joystick_right_y) {
      return false;
    }
    if (this->joystick_dpad_x != other.joystick_dpad_x) {
      return false;
    }
    if (this->joystick_dpad_y != other.joystick_dpad_y) {
      return false;
    }
    if (this->joystick_left_btn != other.joystick_left_btn) {
      return false;
    }
    if (this->joystick_rb_left_x != other.joystick_rb_left_x) {
      return false;
    }
    if (this->joystick_rb_left_y != other.joystick_rb_left_y) {
      return false;
    }
    if (this->joystick_rb_right_x != other.joystick_rb_right_x) {
      return false;
    }
    if (this->joystick_rb_right_y != other.joystick_rb_right_y) {
      return false;
    }
    if (this->joystick_rb_dpad_x != other.joystick_rb_dpad_x) {
      return false;
    }
    if (this->joystick_rb_dpad_y != other.joystick_rb_dpad_y) {
      return false;
    }
    if (this->joystick_dpad_step_x != other.joystick_dpad_step_x) {
      return false;
    }
    if (this->joystick_dpad_step_y != other.joystick_dpad_step_y) {
      return false;
    }
    if (this->joystick_smoothness != other.joystick_smoothness) {
      return false;
    }
    if (this->joystick_deadzone != other.joystick_deadzone) {
      return false;
    }
    if (this->joystick_min_motion_command != other.joystick_min_motion_command) {
      return false;
    }
    if (this->joystick_max_motion_command != other.joystick_max_motion_command) {
      return false;
    }
    if (this->cmd_priority_hold_sec != other.cmd_priority_hold_sec) {
      return false;
    }
    if (this->cmd_packet_timeout_sec != other.cmd_packet_timeout_sec) {
      return false;
    }
    if (this->use_command_filter != other.use_command_filter) {
      return false;
    }
    if (this->motion_command_index_linear_vel_x != other.motion_command_index_linear_vel_x) {
      return false;
    }
    if (this->motion_command_index_linear_vel_y != other.motion_command_index_linear_vel_y) {
      return false;
    }
    if (this->motion_command_index_angular_vel_z != other.motion_command_index_angular_vel_z) {
      return false;
    }
    if (this->motion_command_index_position_z != other.motion_command_index_position_z) {
      return false;
    }
    if (this->motion_command_index_orientation_roll != other.motion_command_index_orientation_roll) {
      return false;
    }
    if (this->motion_command_index_orientation_pitch != other.motion_command_index_orientation_pitch) {
      return false;
    }
    if (this->command_iface_min_motion_command != other.command_iface_min_motion_command) {
      return false;
    }
    if (this->command_iface_max_motion_command != other.command_iface_max_motion_command) {
      return false;
    }
    if (this->battery_low_soc_threshold != other.battery_low_soc_threshold) {
      return false;
    }
    if (this->motor_temperature_threshold != other.motor_temperature_threshold) {
      return false;
    }
    if (this->battery_temperature_threshold != other.battery_temperature_threshold) {
      return false;
    }
    if (this->wma_weights != other.wma_weights) {
      return false;
    }
    if (this->safety_motor_rules != other.safety_motor_rules) {
      return false;
    }
    if (this->safety_imu_rules != other.safety_imu_rules) {
      return false;
    }
    return true;
  }
  bool operator!=(const DynamicParam_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DynamicParam_Request_

// alias to use template instance with default allocator
using DynamicParam_Request =
  core::srv::DynamicParam_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace core


#ifndef _WIN32
# define DEPRECATED__core__srv__DynamicParam_Response __attribute__((deprecated))
#else
# define DEPRECATED__core__srv__DynamicParam_Response __declspec(deprecated)
#endif

namespace core
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct DynamicParam_Response_
{
  using Type = DynamicParam_Response_<ContainerAllocator>;

  explicit DynamicParam_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->reason = "";
    }
  }

  explicit DynamicParam_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : reason(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->reason = "";
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;
  using _reason_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _reason_type reason;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }
  Type & set__reason(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->reason = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    core::srv::DynamicParam_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const core::srv::DynamicParam_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<core::srv::DynamicParam_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<core::srv::DynamicParam_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      core::srv::DynamicParam_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<core::srv::DynamicParam_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      core::srv::DynamicParam_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<core::srv::DynamicParam_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<core::srv::DynamicParam_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<core::srv::DynamicParam_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__core__srv__DynamicParam_Response
    std::shared_ptr<core::srv::DynamicParam_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__core__srv__DynamicParam_Response
    std::shared_ptr<core::srv::DynamicParam_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DynamicParam_Response_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    if (this->reason != other.reason) {
      return false;
    }
    return true;
  }
  bool operator!=(const DynamicParam_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DynamicParam_Response_

// alias to use template instance with default allocator
using DynamicParam_Response =
  core::srv::DynamicParam_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace core

namespace core
{

namespace srv
{

struct DynamicParam
{
  using Request = core::srv::DynamicParam_Request;
  using Response = core::srv::DynamicParam_Response;
};

}  // namespace srv

}  // namespace core

#endif  // CORE__SRV__DETAIL__DYNAMIC_PARAM__STRUCT_HPP_
