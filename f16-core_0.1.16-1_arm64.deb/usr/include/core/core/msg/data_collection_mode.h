// generated from rosidl_generator_c/resource/idl.h.em
// with input from core:msg/DataCollectionMode.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DATA_COLLECTION_MODE_H_
#define CORE__MSG__DATA_COLLECTION_MODE_H_

#include "core/msg/detail/data_collection_mode__struct.h"
#include "core/msg/detail/data_collection_mode__functions.h"
#include "core/msg/detail/data_collection_mode__type_support.h"

#endif  // CORE__MSG__DATA_COLLECTION_MODE_H_
