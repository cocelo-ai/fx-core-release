// generated from rosidl_generator_c/resource/idl.h.em
// with input from core:msg/ImuSafetyRule.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__IMU_SAFETY_RULE_H_
#define CORE__MSG__IMU_SAFETY_RULE_H_

#include "core/msg/detail/imu_safety_rule__struct.h"
#include "core/msg/detail/imu_safety_rule__functions.h"
#include "core/msg/detail/imu_safety_rule__type_support.h"

#endif  // CORE__MSG__IMU_SAFETY_RULE_H_
