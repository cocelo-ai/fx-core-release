// generated from rosidl_generator_c/resource/idl.h.em
// with input from core:msg/EventCore.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__EVENT_CORE_H_
#define CORE__MSG__EVENT_CORE_H_

#include "core/msg/detail/event_core__struct.h"
#include "core/msg/detail/event_core__functions.h"
#include "core/msg/detail/event_core__type_support.h"

#endif  // CORE__MSG__EVENT_CORE_H_
