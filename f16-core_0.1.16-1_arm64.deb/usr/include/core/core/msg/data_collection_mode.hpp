// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DATA_COLLECTION_MODE_HPP_
#define CORE__MSG__DATA_COLLECTION_MODE_HPP_

#include "core/msg/detail/data_collection_mode__struct.hpp"
#include "core/msg/detail/data_collection_mode__builder.hpp"
#include "core/msg/detail/data_collection_mode__traits.hpp"
#include "core/msg/detail/data_collection_mode__type_support.hpp"

#endif  // CORE__MSG__DATA_COLLECTION_MODE_HPP_
