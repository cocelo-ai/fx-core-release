// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from core:msg/CommandCore.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__COMMAND_CORE__STRUCT_H_
#define CORE__MSG__DETAIL__COMMAND_CORE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'event'
#include "core/msg/detail/event_core__struct.h"

/// Struct defined in msg/CommandCore in the package core.
typedef struct core__msg__CommandCore
{
  float motion_command[13];
  core__msg__EventCore event;
  uint8_t custom_drive_id;
} core__msg__CommandCore;

// Struct for a sequence of core__msg__CommandCore.
typedef struct core__msg__CommandCore__Sequence
{
  core__msg__CommandCore * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} core__msg__CommandCore__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CORE__MSG__DETAIL__COMMAND_CORE__STRUCT_H_
