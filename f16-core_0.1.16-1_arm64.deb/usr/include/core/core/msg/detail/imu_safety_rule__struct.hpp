// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from core:msg/ImuSafetyRule.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__IMU_SAFETY_RULE__STRUCT_HPP_
#define CORE__MSG__DETAIL__IMU_SAFETY_RULE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__core__msg__ImuSafetyRule __attribute__((deprecated))
#else
# define DEPRECATED__core__msg__ImuSafetyRule __declspec(deprecated)
#endif

namespace core
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ImuSafetyRule_
{
  using Type = ImuSafetyRule_<ContainerAllocator>;

  explicit ImuSafetyRule_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->imu_order = 0l;
      this->use_proj_grav_z_safety = false;
      this->max_proj_grav_z = 0.0f;
    }
  }

  explicit ImuSafetyRule_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->imu_order = 0l;
      this->use_proj_grav_z_safety = false;
      this->max_proj_grav_z = 0.0f;
    }
  }

  // field types and members
  using _imu_order_type =
    int32_t;
  _imu_order_type imu_order;
  using _use_proj_grav_z_safety_type =
    bool;
  _use_proj_grav_z_safety_type use_proj_grav_z_safety;
  using _max_proj_grav_z_type =
    float;
  _max_proj_grav_z_type max_proj_grav_z;

  // setters for named parameter idiom
  Type & set__imu_order(
    const int32_t & _arg)
  {
    this->imu_order = _arg;
    return *this;
  }
  Type & set__use_proj_grav_z_safety(
    const bool & _arg)
  {
    this->use_proj_grav_z_safety = _arg;
    return *this;
  }
  Type & set__max_proj_grav_z(
    const float & _arg)
  {
    this->max_proj_grav_z = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    core::msg::ImuSafetyRule_<ContainerAllocator> *;
  using ConstRawPtr =
    const core::msg::ImuSafetyRule_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<core::msg::ImuSafetyRule_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<core::msg::ImuSafetyRule_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      core::msg::ImuSafetyRule_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<core::msg::ImuSafetyRule_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      core::msg::ImuSafetyRule_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<core::msg::ImuSafetyRule_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<core::msg::ImuSafetyRule_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<core::msg::ImuSafetyRule_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__core__msg__ImuSafetyRule
    std::shared_ptr<core::msg::ImuSafetyRule_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__core__msg__ImuSafetyRule
    std::shared_ptr<core::msg::ImuSafetyRule_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ImuSafetyRule_ & other) const
  {
    if (this->imu_order != other.imu_order) {
      return false;
    }
    if (this->use_proj_grav_z_safety != other.use_proj_grav_z_safety) {
      return false;
    }
    if (this->max_proj_grav_z != other.max_proj_grav_z) {
      return false;
    }
    return true;
  }
  bool operator!=(const ImuSafetyRule_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ImuSafetyRule_

// alias to use template instance with default allocator
using ImuSafetyRule =
  core::msg::ImuSafetyRule_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace core

#endif  // CORE__MSG__DETAIL__IMU_SAFETY_RULE__STRUCT_HPP_
