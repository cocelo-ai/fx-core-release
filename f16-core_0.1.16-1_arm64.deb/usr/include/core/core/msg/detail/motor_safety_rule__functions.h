// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from core:msg/MotorSafetyRule.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__MOTOR_SAFETY_RULE__FUNCTIONS_H_
#define CORE__MSG__DETAIL__MOTOR_SAFETY_RULE__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "core/msg/rosidl_generator_c__visibility_control.h"

#include "core/msg/detail/motor_safety_rule__struct.h"

/// Initialize msg/MotorSafetyRule message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * core__msg__MotorSafetyRule
 * )) before or use
 * core__msg__MotorSafetyRule__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__msg__MotorSafetyRule__init(core__msg__MotorSafetyRule * msg);

/// Finalize msg/MotorSafetyRule message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__msg__MotorSafetyRule__fini(core__msg__MotorSafetyRule * msg);

/// Create msg/MotorSafetyRule message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * core__msg__MotorSafetyRule__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_core
core__msg__MotorSafetyRule *
core__msg__MotorSafetyRule__create();

/// Destroy msg/MotorSafetyRule message.
/**
 * It calls
 * core__msg__MotorSafetyRule__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__msg__MotorSafetyRule__destroy(core__msg__MotorSafetyRule * msg);

/// Check for msg/MotorSafetyRule message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__msg__MotorSafetyRule__are_equal(const core__msg__MotorSafetyRule * lhs, const core__msg__MotorSafetyRule * rhs);

/// Copy a msg/MotorSafetyRule message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__msg__MotorSafetyRule__copy(
  const core__msg__MotorSafetyRule * input,
  core__msg__MotorSafetyRule * output);

/// Initialize array of msg/MotorSafetyRule messages.
/**
 * It allocates the memory for the number of elements and calls
 * core__msg__MotorSafetyRule__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__msg__MotorSafetyRule__Sequence__init(core__msg__MotorSafetyRule__Sequence * array, size_t size);

/// Finalize array of msg/MotorSafetyRule messages.
/**
 * It calls
 * core__msg__MotorSafetyRule__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__msg__MotorSafetyRule__Sequence__fini(core__msg__MotorSafetyRule__Sequence * array);

/// Create array of msg/MotorSafetyRule messages.
/**
 * It allocates the memory for the array and calls
 * core__msg__MotorSafetyRule__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_core
core__msg__MotorSafetyRule__Sequence *
core__msg__MotorSafetyRule__Sequence__create(size_t size);

/// Destroy array of msg/MotorSafetyRule messages.
/**
 * It calls
 * core__msg__MotorSafetyRule__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__msg__MotorSafetyRule__Sequence__destroy(core__msg__MotorSafetyRule__Sequence * array);

/// Check for msg/MotorSafetyRule message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__msg__MotorSafetyRule__Sequence__are_equal(const core__msg__MotorSafetyRule__Sequence * lhs, const core__msg__MotorSafetyRule__Sequence * rhs);

/// Copy an array of msg/MotorSafetyRule messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__msg__MotorSafetyRule__Sequence__copy(
  const core__msg__MotorSafetyRule__Sequence * input,
  core__msg__MotorSafetyRule__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // CORE__MSG__DETAIL__MOTOR_SAFETY_RULE__FUNCTIONS_H_
