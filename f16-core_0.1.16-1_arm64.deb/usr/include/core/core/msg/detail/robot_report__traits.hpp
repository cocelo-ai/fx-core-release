// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from core:msg/RobotReport.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__ROBOT_REPORT__TRAITS_HPP_
#define CORE__MSG__DETAIL__ROBOT_REPORT__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "core/msg/detail/robot_report__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace core
{

namespace msg
{

inline void to_flow_style_yaml(
  const RobotReport & msg,
  std::ostream & out)
{
  out << "{";
  // member: robot_state
  {
    out << "robot_state: ";
    rosidl_generator_traits::value_to_yaml(msg.robot_state, out);
    out << ", ";
  }

  // member: robot_state_name
  {
    out << "robot_state_name: ";
    rosidl_generator_traits::value_to_yaml(msg.robot_state_name, out);
    out << ", ";
  }

  // member: robot_initialized
  {
    out << "robot_initialized: ";
    rosidl_generator_traits::value_to_yaml(msg.robot_initialized, out);
    out << ", ";
  }

  // member: custom_drive_id
  {
    out << "custom_drive_id: ";
    rosidl_generator_traits::value_to_yaml(msg.custom_drive_id, out);
    out << ", ";
  }

  // member: active_command_source
  {
    out << "active_command_source: ";
    rosidl_generator_traits::value_to_yaml(msg.active_command_source, out);
    out << ", ";
  }

  // member: active_command_source_name
  {
    out << "active_command_source_name: ";
    rosidl_generator_traits::value_to_yaml(msg.active_command_source_name, out);
    out << ", ";
  }

  // member: active_command_fresh
  {
    out << "active_command_fresh: ";
    rosidl_generator_traits::value_to_yaml(msg.active_command_fresh, out);
    out << ", ";
  }

  // member: sdk_mode_enabled
  {
    out << "sdk_mode_enabled: ";
    rosidl_generator_traits::value_to_yaml(msg.sdk_mode_enabled, out);
    out << ", ";
  }

  // member: data_collection_mode_enabled
  {
    out << "data_collection_mode_enabled: ";
    rosidl_generator_traits::value_to_yaml(msg.data_collection_mode_enabled, out);
    out << ", ";
  }

  // member: motion_command
  {
    if (msg.motion_command.size() == 0) {
      out << "motion_command: []";
    } else {
      out << "motion_command: [";
      size_t pending_items = msg.motion_command.size();
      for (auto item : msg.motion_command) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: physical_estop
  {
    out << "physical_estop: ";
    rosidl_generator_traits::value_to_yaml(msg.physical_estop, out);
    out << ", ";
  }

  // member: physical_fault
  {
    out << "physical_fault: ";
    rosidl_generator_traits::value_to_yaml(msg.physical_fault, out);
    out << ", ";
  }

  // member: comm_estop
  {
    out << "comm_estop: ";
    rosidl_generator_traits::value_to_yaml(msg.comm_estop, out);
    out << ", ";
  }

  // member: comm_fault
  {
    out << "comm_fault: ";
    rosidl_generator_traits::value_to_yaml(msg.comm_fault, out);
    out << ", ";
  }

  // member: command_estop
  {
    out << "command_estop: ";
    rosidl_generator_traits::value_to_yaml(msg.command_estop, out);
    out << ", ";
  }

  // member: safety_estop
  {
    out << "safety_estop: ";
    rosidl_generator_traits::value_to_yaml(msg.safety_estop, out);
    out << ", ";
  }

  // member: safety_fault
  {
    out << "safety_fault: ";
    rosidl_generator_traits::value_to_yaml(msg.safety_fault, out);
    out << ", ";
  }

  // member: controller_failure
  {
    out << "controller_failure: ";
    rosidl_generator_traits::value_to_yaml(msg.controller_failure, out);
    out << ", ";
  }

  // member: error_reason
  {
    out << "error_reason: ";
    rosidl_generator_traits::value_to_yaml(msg.error_reason, out);
    out << ", ";
  }

  // member: motor_pattern
  {
    if (msg.motor_pattern.size() == 0) {
      out << "motor_pattern: []";
    } else {
      out << "motor_pattern: [";
      size_t pending_items = msg.motor_pattern.size();
      for (auto item : msg.motor_pattern) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: motor_pattern_ok
  {
    if (msg.motor_pattern_ok.size() == 0) {
      out << "motor_pattern_ok: []";
    } else {
      out << "motor_pattern_ok: [";
      size_t pending_items = msg.motor_pattern_ok.size();
      for (auto item : msg.motor_pattern_ok) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: motor_err
  {
    if (msg.motor_err.size() == 0) {
      out << "motor_err: []";
    } else {
      out << "motor_err: [";
      size_t pending_items = msg.motor_err.size();
      for (auto item : msg.motor_err) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: battery_voltage
  {
    out << "battery_voltage: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_voltage, out);
    out << ", ";
  }

  // member: battery_soc
  {
    out << "battery_soc: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_soc, out);
    out << ", ";
  }

  // member: battery_current
  {
    out << "battery_current: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_current, out);
    out << ", ";
  }

  // member: battery_temperature
  {
    out << "battery_temperature: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_temperature, out);
    out << ", ";
  }

  // member: battery_power
  {
    out << "battery_power: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_power, out);
    out << ", ";
  }

  // member: dof_pos
  {
    if (msg.dof_pos.size() == 0) {
      out << "dof_pos: []";
    } else {
      out << "dof_pos: [";
      size_t pending_items = msg.dof_pos.size();
      for (auto item : msg.dof_pos) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: dof_vel
  {
    if (msg.dof_vel.size() == 0) {
      out << "dof_vel: []";
    } else {
      out << "dof_vel: [";
      size_t pending_items = msg.dof_vel.size();
      for (auto item : msg.dof_vel) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: dof_tau
  {
    if (msg.dof_tau.size() == 0) {
      out << "dof_tau: []";
    } else {
      out << "dof_tau: [";
      size_t pending_items = msg.dof_tau.size();
      for (auto item : msg.dof_tau) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: ang_vel
  {
    if (msg.ang_vel.size() == 0) {
      out << "ang_vel: []";
    } else {
      out << "ang_vel: [";
      size_t pending_items = msg.ang_vel.size();
      for (auto item : msg.ang_vel) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: proj_grav
  {
    if (msg.proj_grav.size() == 0) {
      out << "proj_grav: []";
    } else {
      out << "proj_grav: [";
      size_t pending_items = msg.proj_grav.size();
      for (auto item : msg.proj_grav) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: lin_vel
  {
    if (msg.lin_vel.size() == 0) {
      out << "lin_vel: []";
    } else {
      out << "lin_vel: [";
      size_t pending_items = msg.lin_vel.size();
      for (auto item : msg.lin_vel) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: height_map
  {
    if (msg.height_map.size() == 0) {
      out << "height_map: []";
    } else {
      out << "height_map: [";
      size_t pending_items = msg.height_map.size();
      for (auto item : msg.height_map) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RobotReport & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: robot_state
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "robot_state: ";
    rosidl_generator_traits::value_to_yaml(msg.robot_state, out);
    out << "\n";
  }

  // member: robot_state_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "robot_state_name: ";
    rosidl_generator_traits::value_to_yaml(msg.robot_state_name, out);
    out << "\n";
  }

  // member: robot_initialized
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "robot_initialized: ";
    rosidl_generator_traits::value_to_yaml(msg.robot_initialized, out);
    out << "\n";
  }

  // member: custom_drive_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "custom_drive_id: ";
    rosidl_generator_traits::value_to_yaml(msg.custom_drive_id, out);
    out << "\n";
  }

  // member: active_command_source
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "active_command_source: ";
    rosidl_generator_traits::value_to_yaml(msg.active_command_source, out);
    out << "\n";
  }

  // member: active_command_source_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "active_command_source_name: ";
    rosidl_generator_traits::value_to_yaml(msg.active_command_source_name, out);
    out << "\n";
  }

  // member: active_command_fresh
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "active_command_fresh: ";
    rosidl_generator_traits::value_to_yaml(msg.active_command_fresh, out);
    out << "\n";
  }

  // member: sdk_mode_enabled
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sdk_mode_enabled: ";
    rosidl_generator_traits::value_to_yaml(msg.sdk_mode_enabled, out);
    out << "\n";
  }

  // member: data_collection_mode_enabled
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "data_collection_mode_enabled: ";
    rosidl_generator_traits::value_to_yaml(msg.data_collection_mode_enabled, out);
    out << "\n";
  }

  // member: motion_command
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.motion_command.size() == 0) {
      out << "motion_command: []\n";
    } else {
      out << "motion_command:\n";
      for (auto item : msg.motion_command) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: physical_estop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "physical_estop: ";
    rosidl_generator_traits::value_to_yaml(msg.physical_estop, out);
    out << "\n";
  }

  // member: physical_fault
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "physical_fault: ";
    rosidl_generator_traits::value_to_yaml(msg.physical_fault, out);
    out << "\n";
  }

  // member: comm_estop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "comm_estop: ";
    rosidl_generator_traits::value_to_yaml(msg.comm_estop, out);
    out << "\n";
  }

  // member: comm_fault
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "comm_fault: ";
    rosidl_generator_traits::value_to_yaml(msg.comm_fault, out);
    out << "\n";
  }

  // member: command_estop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "command_estop: ";
    rosidl_generator_traits::value_to_yaml(msg.command_estop, out);
    out << "\n";
  }

  // member: safety_estop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "safety_estop: ";
    rosidl_generator_traits::value_to_yaml(msg.safety_estop, out);
    out << "\n";
  }

  // member: safety_fault
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "safety_fault: ";
    rosidl_generator_traits::value_to_yaml(msg.safety_fault, out);
    out << "\n";
  }

  // member: controller_failure
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "controller_failure: ";
    rosidl_generator_traits::value_to_yaml(msg.controller_failure, out);
    out << "\n";
  }

  // member: error_reason
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "error_reason: ";
    rosidl_generator_traits::value_to_yaml(msg.error_reason, out);
    out << "\n";
  }

  // member: motor_pattern
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.motor_pattern.size() == 0) {
      out << "motor_pattern: []\n";
    } else {
      out << "motor_pattern:\n";
      for (auto item : msg.motor_pattern) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: motor_pattern_ok
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.motor_pattern_ok.size() == 0) {
      out << "motor_pattern_ok: []\n";
    } else {
      out << "motor_pattern_ok:\n";
      for (auto item : msg.motor_pattern_ok) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: motor_err
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.motor_err.size() == 0) {
      out << "motor_err: []\n";
    } else {
      out << "motor_err:\n";
      for (auto item : msg.motor_err) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: battery_voltage
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_voltage: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_voltage, out);
    out << "\n";
  }

  // member: battery_soc
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_soc: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_soc, out);
    out << "\n";
  }

  // member: battery_current
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_current: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_current, out);
    out << "\n";
  }

  // member: battery_temperature
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_temperature: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_temperature, out);
    out << "\n";
  }

  // member: battery_power
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_power: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_power, out);
    out << "\n";
  }

  // member: dof_pos
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.dof_pos.size() == 0) {
      out << "dof_pos: []\n";
    } else {
      out << "dof_pos:\n";
      for (auto item : msg.dof_pos) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: dof_vel
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.dof_vel.size() == 0) {
      out << "dof_vel: []\n";
    } else {
      out << "dof_vel:\n";
      for (auto item : msg.dof_vel) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: dof_tau
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.dof_tau.size() == 0) {
      out << "dof_tau: []\n";
    } else {
      out << "dof_tau:\n";
      for (auto item : msg.dof_tau) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: ang_vel
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.ang_vel.size() == 0) {
      out << "ang_vel: []\n";
    } else {
      out << "ang_vel:\n";
      for (auto item : msg.ang_vel) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: proj_grav
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.proj_grav.size() == 0) {
      out << "proj_grav: []\n";
    } else {
      out << "proj_grav:\n";
      for (auto item : msg.proj_grav) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: lin_vel
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.lin_vel.size() == 0) {
      out << "lin_vel: []\n";
    } else {
      out << "lin_vel:\n";
      for (auto item : msg.lin_vel) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: height_map
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.height_map.size() == 0) {
      out << "height_map: []\n";
    } else {
      out << "height_map:\n";
      for (auto item : msg.height_map) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RobotReport & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace core

namespace rosidl_generator_traits
{

[[deprecated("use core::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const core::msg::RobotReport & msg,
  std::ostream & out, size_t indentation = 0)
{
  core::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use core::msg::to_yaml() instead")]]
inline std::string to_yaml(const core::msg::RobotReport & msg)
{
  return core::msg::to_yaml(msg);
}

template<>
inline const char * data_type<core::msg::RobotReport>()
{
  return "core::msg::RobotReport";
}

template<>
inline const char * name<core::msg::RobotReport>()
{
  return "core/msg/RobotReport";
}

template<>
struct has_fixed_size<core::msg::RobotReport>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<core::msg::RobotReport>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<core::msg::RobotReport>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CORE__MSG__DETAIL__ROBOT_REPORT__TRAITS_HPP_
