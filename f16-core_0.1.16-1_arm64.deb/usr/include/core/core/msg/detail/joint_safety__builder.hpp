// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from core:msg/JointSafety.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__JOINT_SAFETY__BUILDER_HPP_
#define CORE__MSG__DETAIL__JOINT_SAFETY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "core/msg/detail/joint_safety__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace core
{

namespace msg
{

namespace builder
{

class Init_JointSafety_vel_hard_limit_rad_s
{
public:
  explicit Init_JointSafety_vel_hard_limit_rad_s(::core::msg::JointSafety & msg)
  : msg_(msg)
  {}
  ::core::msg::JointSafety vel_hard_limit_rad_s(::core::msg::JointSafety::_vel_hard_limit_rad_s_type arg)
  {
    msg_.vel_hard_limit_rad_s = std::move(arg);
    return std::move(msg_);
  }

private:
  ::core::msg::JointSafety msg_;
};

class Init_JointSafety_vel_threshold_near_limit_rad_s
{
public:
  explicit Init_JointSafety_vel_threshold_near_limit_rad_s(::core::msg::JointSafety & msg)
  : msg_(msg)
  {}
  Init_JointSafety_vel_hard_limit_rad_s vel_threshold_near_limit_rad_s(::core::msg::JointSafety::_vel_threshold_near_limit_rad_s_type arg)
  {
    msg_.vel_threshold_near_limit_rad_s = std::move(arg);
    return Init_JointSafety_vel_hard_limit_rad_s(msg_);
  }

private:
  ::core::msg::JointSafety msg_;
};

class Init_JointSafety_pos_margin_near_limit_rad
{
public:
  explicit Init_JointSafety_pos_margin_near_limit_rad(::core::msg::JointSafety & msg)
  : msg_(msg)
  {}
  Init_JointSafety_vel_threshold_near_limit_rad_s pos_margin_near_limit_rad(::core::msg::JointSafety::_pos_margin_near_limit_rad_type arg)
  {
    msg_.pos_margin_near_limit_rad = std::move(arg);
    return Init_JointSafety_vel_threshold_near_limit_rad_s(msg_);
  }

private:
  ::core::msg::JointSafety msg_;
};

class Init_JointSafety_pos_safety_margin_rad
{
public:
  Init_JointSafety_pos_safety_margin_rad()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_JointSafety_pos_margin_near_limit_rad pos_safety_margin_rad(::core::msg::JointSafety::_pos_safety_margin_rad_type arg)
  {
    msg_.pos_safety_margin_rad = std::move(arg);
    return Init_JointSafety_pos_margin_near_limit_rad(msg_);
  }

private:
  ::core::msg::JointSafety msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::core::msg::JointSafety>()
{
  return core::msg::builder::Init_JointSafety_pos_safety_margin_rad();
}

}  // namespace core

#endif  // CORE__MSG__DETAIL__JOINT_SAFETY__BUILDER_HPP_
