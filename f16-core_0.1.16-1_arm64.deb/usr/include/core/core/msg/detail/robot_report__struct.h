// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from core:msg/RobotReport.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__ROBOT_REPORT__STRUCT_H_
#define CORE__MSG__DETAIL__ROBOT_REPORT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'robot_state_name'
// Member 'active_command_source_name'
// Member 'error_reason'
// Member 'motor_pattern'
// Member 'motor_err'
// Member 'battery_voltage'
// Member 'battery_soc'
// Member 'battery_current'
// Member 'battery_temperature'
// Member 'battery_power'
#include "rosidl_runtime_c/string.h"
// Member 'motor_pattern_ok'
// Member 'dof_pos'
// Member 'dof_vel'
// Member 'dof_tau'
// Member 'ang_vel'
// Member 'proj_grav'
// Member 'lin_vel'
// Member 'height_map'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/RobotReport in the package core.
typedef struct core__msg__RobotReport
{
  uint8_t robot_state;
  rosidl_runtime_c__String robot_state_name;
  bool robot_initialized;
  uint8_t custom_drive_id;
  uint8_t active_command_source;
  rosidl_runtime_c__String active_command_source_name;
  bool active_command_fresh;
  bool sdk_mode_enabled;
  bool data_collection_mode_enabled;
  float motion_command[13];
  bool physical_estop;
  bool physical_fault;
  bool comm_estop;
  bool comm_fault;
  bool command_estop;
  bool safety_estop;
  bool safety_fault;
  bool controller_failure;
  rosidl_runtime_c__String error_reason;
  rosidl_runtime_c__String__Sequence motor_pattern;
  rosidl_runtime_c__boolean__Sequence motor_pattern_ok;
  rosidl_runtime_c__String__Sequence motor_err;
  rosidl_runtime_c__String battery_voltage;
  rosidl_runtime_c__String battery_soc;
  rosidl_runtime_c__String battery_current;
  rosidl_runtime_c__String battery_temperature;
  rosidl_runtime_c__String battery_power;
  rosidl_runtime_c__float__Sequence dof_pos;
  rosidl_runtime_c__float__Sequence dof_vel;
  rosidl_runtime_c__float__Sequence dof_tau;
  rosidl_runtime_c__float__Sequence ang_vel;
  rosidl_runtime_c__float__Sequence proj_grav;
  rosidl_runtime_c__float__Sequence lin_vel;
  rosidl_runtime_c__float__Sequence height_map;
} core__msg__RobotReport;

// Struct for a sequence of core__msg__RobotReport.
typedef struct core__msg__RobotReport__Sequence
{
  core__msg__RobotReport * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} core__msg__RobotReport__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CORE__MSG__DETAIL__ROBOT_REPORT__STRUCT_H_
