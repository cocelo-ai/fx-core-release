// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from core:msg/DataCollectionMode.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__DATA_COLLECTION_MODE__STRUCT_HPP_
#define CORE__MSG__DETAIL__DATA_COLLECTION_MODE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__core__msg__DataCollectionMode __attribute__((deprecated))
#else
# define DEPRECATED__core__msg__DataCollectionMode __declspec(deprecated)
#endif

namespace core
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct DataCollectionMode_
{
  using Type = DataCollectionMode_<ContainerAllocator>;

  explicit DataCollectionMode_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->enabled = false;
    }
  }

  explicit DataCollectionMode_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->enabled = false;
    }
  }

  // field types and members
  using _enabled_type =
    bool;
  _enabled_type enabled;

  // setters for named parameter idiom
  Type & set__enabled(
    const bool & _arg)
  {
    this->enabled = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    core::msg::DataCollectionMode_<ContainerAllocator> *;
  using ConstRawPtr =
    const core::msg::DataCollectionMode_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<core::msg::DataCollectionMode_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<core::msg::DataCollectionMode_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      core::msg::DataCollectionMode_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<core::msg::DataCollectionMode_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      core::msg::DataCollectionMode_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<core::msg::DataCollectionMode_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<core::msg::DataCollectionMode_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<core::msg::DataCollectionMode_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__core__msg__DataCollectionMode
    std::shared_ptr<core::msg::DataCollectionMode_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__core__msg__DataCollectionMode
    std::shared_ptr<core::msg::DataCollectionMode_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DataCollectionMode_ & other) const
  {
    if (this->enabled != other.enabled) {
      return false;
    }
    return true;
  }
  bool operator!=(const DataCollectionMode_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DataCollectionMode_

// alias to use template instance with default allocator
using DataCollectionMode =
  core::msg::DataCollectionMode_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace core

#endif  // CORE__MSG__DETAIL__DATA_COLLECTION_MODE__STRUCT_HPP_
