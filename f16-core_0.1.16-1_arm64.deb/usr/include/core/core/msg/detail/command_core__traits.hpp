// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from core:msg/CommandCore.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__COMMAND_CORE__TRAITS_HPP_
#define CORE__MSG__DETAIL__COMMAND_CORE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "core/msg/detail/command_core__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'event'
#include "core/msg/detail/event_core__traits.hpp"

namespace core
{

namespace msg
{

inline void to_flow_style_yaml(
  const CommandCore & msg,
  std::ostream & out)
{
  out << "{";
  // member: motion_command
  {
    if (msg.motion_command.size() == 0) {
      out << "motion_command: []";
    } else {
      out << "motion_command: [";
      size_t pending_items = msg.motion_command.size();
      for (auto item : msg.motion_command) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: event
  {
    out << "event: ";
    to_flow_style_yaml(msg.event, out);
    out << ", ";
  }

  // member: custom_drive_id
  {
    out << "custom_drive_id: ";
    rosidl_generator_traits::value_to_yaml(msg.custom_drive_id, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const CommandCore & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: motion_command
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.motion_command.size() == 0) {
      out << "motion_command: []\n";
    } else {
      out << "motion_command:\n";
      for (auto item : msg.motion_command) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: event
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "event:\n";
    to_block_style_yaml(msg.event, out, indentation + 2);
  }

  // member: custom_drive_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "custom_drive_id: ";
    rosidl_generator_traits::value_to_yaml(msg.custom_drive_id, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const CommandCore & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace core

namespace rosidl_generator_traits
{

[[deprecated("use core::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const core::msg::CommandCore & msg,
  std::ostream & out, size_t indentation = 0)
{
  core::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use core::msg::to_yaml() instead")]]
inline std::string to_yaml(const core::msg::CommandCore & msg)
{
  return core::msg::to_yaml(msg);
}

template<>
inline const char * data_type<core::msg::CommandCore>()
{
  return "core::msg::CommandCore";
}

template<>
inline const char * name<core::msg::CommandCore>()
{
  return "core/msg/CommandCore";
}

template<>
struct has_fixed_size<core::msg::CommandCore>
  : std::integral_constant<bool, has_fixed_size<core::msg::EventCore>::value> {};

template<>
struct has_bounded_size<core::msg::CommandCore>
  : std::integral_constant<bool, has_bounded_size<core::msg::EventCore>::value> {};

template<>
struct is_message<core::msg::CommandCore>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CORE__MSG__DETAIL__COMMAND_CORE__TRAITS_HPP_
