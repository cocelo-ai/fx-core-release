// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from core:msg/ImuSafetyRule.idl
// generated code does not contain a copyright notice
#include "core/msg/detail/imu_safety_rule__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
core__msg__ImuSafetyRule__init(core__msg__ImuSafetyRule * msg)
{
  if (!msg) {
    return false;
  }
  // imu_order
  // use_proj_grav_z_safety
  // max_proj_grav_z
  return true;
}

void
core__msg__ImuSafetyRule__fini(core__msg__ImuSafetyRule * msg)
{
  if (!msg) {
    return;
  }
  // imu_order
  // use_proj_grav_z_safety
  // max_proj_grav_z
}

bool
core__msg__ImuSafetyRule__are_equal(const core__msg__ImuSafetyRule * lhs, const core__msg__ImuSafetyRule * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // imu_order
  if (lhs->imu_order != rhs->imu_order) {
    return false;
  }
  // use_proj_grav_z_safety
  if (lhs->use_proj_grav_z_safety != rhs->use_proj_grav_z_safety) {
    return false;
  }
  // max_proj_grav_z
  if (lhs->max_proj_grav_z != rhs->max_proj_grav_z) {
    return false;
  }
  return true;
}

bool
core__msg__ImuSafetyRule__copy(
  const core__msg__ImuSafetyRule * input,
  core__msg__ImuSafetyRule * output)
{
  if (!input || !output) {
    return false;
  }
  // imu_order
  output->imu_order = input->imu_order;
  // use_proj_grav_z_safety
  output->use_proj_grav_z_safety = input->use_proj_grav_z_safety;
  // max_proj_grav_z
  output->max_proj_grav_z = input->max_proj_grav_z;
  return true;
}

core__msg__ImuSafetyRule *
core__msg__ImuSafetyRule__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__msg__ImuSafetyRule * msg = (core__msg__ImuSafetyRule *)allocator.allocate(sizeof(core__msg__ImuSafetyRule), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(core__msg__ImuSafetyRule));
  bool success = core__msg__ImuSafetyRule__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
core__msg__ImuSafetyRule__destroy(core__msg__ImuSafetyRule * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    core__msg__ImuSafetyRule__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
core__msg__ImuSafetyRule__Sequence__init(core__msg__ImuSafetyRule__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__msg__ImuSafetyRule * data = NULL;

  if (size) {
    data = (core__msg__ImuSafetyRule *)allocator.zero_allocate(size, sizeof(core__msg__ImuSafetyRule), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = core__msg__ImuSafetyRule__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        core__msg__ImuSafetyRule__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
core__msg__ImuSafetyRule__Sequence__fini(core__msg__ImuSafetyRule__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      core__msg__ImuSafetyRule__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

core__msg__ImuSafetyRule__Sequence *
core__msg__ImuSafetyRule__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__msg__ImuSafetyRule__Sequence * array = (core__msg__ImuSafetyRule__Sequence *)allocator.allocate(sizeof(core__msg__ImuSafetyRule__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = core__msg__ImuSafetyRule__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
core__msg__ImuSafetyRule__Sequence__destroy(core__msg__ImuSafetyRule__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    core__msg__ImuSafetyRule__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
core__msg__ImuSafetyRule__Sequence__are_equal(const core__msg__ImuSafetyRule__Sequence * lhs, const core__msg__ImuSafetyRule__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!core__msg__ImuSafetyRule__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
core__msg__ImuSafetyRule__Sequence__copy(
  const core__msg__ImuSafetyRule__Sequence * input,
  core__msg__ImuSafetyRule__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(core__msg__ImuSafetyRule);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    core__msg__ImuSafetyRule * data =
      (core__msg__ImuSafetyRule *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!core__msg__ImuSafetyRule__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          core__msg__ImuSafetyRule__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!core__msg__ImuSafetyRule__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
