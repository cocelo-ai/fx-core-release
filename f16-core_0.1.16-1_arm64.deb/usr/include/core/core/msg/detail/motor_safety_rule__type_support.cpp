// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from core:msg/MotorSafetyRule.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "core/msg/detail/motor_safety_rule__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace core
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void MotorSafetyRule_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) core::msg::MotorSafetyRule(_init);
}

void MotorSafetyRule_fini_function(void * message_memory)
{
  auto typed_message = static_cast<core::msg::MotorSafetyRule *>(message_memory);
  typed_message->~MotorSafetyRule();
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember MotorSafetyRule_message_member_array[2] = {
  {
    "motor_id",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core::msg::MotorSafetyRule, motor_id),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "safety",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<core::msg::JointSafety>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core::msg::MotorSafetyRule, safety),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers MotorSafetyRule_message_members = {
  "core::msg",  // message namespace
  "MotorSafetyRule",  // message name
  2,  // number of fields
  sizeof(core::msg::MotorSafetyRule),
  MotorSafetyRule_message_member_array,  // message members
  MotorSafetyRule_init_function,  // function to initialize message memory (memory has to be allocated)
  MotorSafetyRule_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t MotorSafetyRule_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &MotorSafetyRule_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace core


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<core::msg::MotorSafetyRule>()
{
  return &::core::msg::rosidl_typesupport_introspection_cpp::MotorSafetyRule_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, core, msg, MotorSafetyRule)() {
  return &::core::msg::rosidl_typesupport_introspection_cpp::MotorSafetyRule_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
