// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from core:msg/JointSafety.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__JOINT_SAFETY__FUNCTIONS_H_
#define CORE__MSG__DETAIL__JOINT_SAFETY__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "core/msg/rosidl_generator_c__visibility_control.h"

#include "core/msg/detail/joint_safety__struct.h"

/// Initialize msg/JointSafety message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * core__msg__JointSafety
 * )) before or use
 * core__msg__JointSafety__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__msg__JointSafety__init(core__msg__JointSafety * msg);

/// Finalize msg/JointSafety message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__msg__JointSafety__fini(core__msg__JointSafety * msg);

/// Create msg/JointSafety message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * core__msg__JointSafety__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_core
core__msg__JointSafety *
core__msg__JointSafety__create();

/// Destroy msg/JointSafety message.
/**
 * It calls
 * core__msg__JointSafety__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__msg__JointSafety__destroy(core__msg__JointSafety * msg);

/// Check for msg/JointSafety message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__msg__JointSafety__are_equal(const core__msg__JointSafety * lhs, const core__msg__JointSafety * rhs);

/// Copy a msg/JointSafety message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__msg__JointSafety__copy(
  const core__msg__JointSafety * input,
  core__msg__JointSafety * output);

/// Initialize array of msg/JointSafety messages.
/**
 * It allocates the memory for the number of elements and calls
 * core__msg__JointSafety__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__msg__JointSafety__Sequence__init(core__msg__JointSafety__Sequence * array, size_t size);

/// Finalize array of msg/JointSafety messages.
/**
 * It calls
 * core__msg__JointSafety__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__msg__JointSafety__Sequence__fini(core__msg__JointSafety__Sequence * array);

/// Create array of msg/JointSafety messages.
/**
 * It allocates the memory for the array and calls
 * core__msg__JointSafety__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_core
core__msg__JointSafety__Sequence *
core__msg__JointSafety__Sequence__create(size_t size);

/// Destroy array of msg/JointSafety messages.
/**
 * It calls
 * core__msg__JointSafety__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__msg__JointSafety__Sequence__destroy(core__msg__JointSafety__Sequence * array);

/// Check for msg/JointSafety message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__msg__JointSafety__Sequence__are_equal(const core__msg__JointSafety__Sequence * lhs, const core__msg__JointSafety__Sequence * rhs);

/// Copy an array of msg/JointSafety messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__msg__JointSafety__Sequence__copy(
  const core__msg__JointSafety__Sequence * input,
  core__msg__JointSafety__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // CORE__MSG__DETAIL__JOINT_SAFETY__FUNCTIONS_H_
