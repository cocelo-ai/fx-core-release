// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from core:msg/MotorSafetyRule.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__MOTOR_SAFETY_RULE__TRAITS_HPP_
#define CORE__MSG__DETAIL__MOTOR_SAFETY_RULE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "core/msg/detail/motor_safety_rule__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'safety'
#include "core/msg/detail/joint_safety__traits.hpp"

namespace core
{

namespace msg
{

inline void to_flow_style_yaml(
  const MotorSafetyRule & msg,
  std::ostream & out)
{
  out << "{";
  // member: motor_id
  {
    out << "motor_id: ";
    rosidl_generator_traits::value_to_yaml(msg.motor_id, out);
    out << ", ";
  }

  // member: safety
  {
    out << "safety: ";
    to_flow_style_yaml(msg.safety, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MotorSafetyRule & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: motor_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motor_id: ";
    rosidl_generator_traits::value_to_yaml(msg.motor_id, out);
    out << "\n";
  }

  // member: safety
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "safety:\n";
    to_block_style_yaml(msg.safety, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MotorSafetyRule & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace core

namespace rosidl_generator_traits
{

[[deprecated("use core::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const core::msg::MotorSafetyRule & msg,
  std::ostream & out, size_t indentation = 0)
{
  core::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use core::msg::to_yaml() instead")]]
inline std::string to_yaml(const core::msg::MotorSafetyRule & msg)
{
  return core::msg::to_yaml(msg);
}

template<>
inline const char * data_type<core::msg::MotorSafetyRule>()
{
  return "core::msg::MotorSafetyRule";
}

template<>
inline const char * name<core::msg::MotorSafetyRule>()
{
  return "core/msg/MotorSafetyRule";
}

template<>
struct has_fixed_size<core::msg::MotorSafetyRule>
  : std::integral_constant<bool, has_fixed_size<core::msg::JointSafety>::value> {};

template<>
struct has_bounded_size<core::msg::MotorSafetyRule>
  : std::integral_constant<bool, has_bounded_size<core::msg::JointSafety>::value> {};

template<>
struct is_message<core::msg::MotorSafetyRule>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CORE__MSG__DETAIL__MOTOR_SAFETY_RULE__TRAITS_HPP_
