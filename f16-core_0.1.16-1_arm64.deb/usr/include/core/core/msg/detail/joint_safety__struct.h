// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from core:msg/JointSafety.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__JOINT_SAFETY__STRUCT_H_
#define CORE__MSG__DETAIL__JOINT_SAFETY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/JointSafety in the package core.
typedef struct core__msg__JointSafety
{
  float pos_safety_margin_rad;
  float pos_margin_near_limit_rad;
  float vel_threshold_near_limit_rad_s;
  float vel_hard_limit_rad_s;
} core__msg__JointSafety;

// Struct for a sequence of core__msg__JointSafety.
typedef struct core__msg__JointSafety__Sequence
{
  core__msg__JointSafety * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} core__msg__JointSafety__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CORE__MSG__DETAIL__JOINT_SAFETY__STRUCT_H_
