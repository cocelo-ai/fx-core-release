// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from core:msg/EventCore.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__EVENT_CORE__STRUCT_H_
#define CORE__MSG__DETAIL__EVENT_CORE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/EventCore in the package core.
typedef struct core__msg__EventCore
{
  bool estop;
  bool wake;
  bool sleep;
  bool rough_drive_toggle;
  bool custom_drive_toggle;
} core__msg__EventCore;

// Struct for a sequence of core__msg__EventCore.
typedef struct core__msg__EventCore__Sequence
{
  core__msg__EventCore * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} core__msg__EventCore__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CORE__MSG__DETAIL__EVENT_CORE__STRUCT_H_
