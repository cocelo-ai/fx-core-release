// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from core:msg/CommandFilter.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__COMMAND_FILTER__STRUCT_HPP_
#define CORE__MSG__DETAIL__COMMAND_FILTER__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__core__msg__CommandFilter __attribute__((deprecated))
#else
# define DEPRECATED__core__msg__CommandFilter __declspec(deprecated)
#endif

namespace core
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct CommandFilter_
{
  using Type = CommandFilter_<ContainerAllocator>;

  explicit CommandFilter_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->allow_linear_vel_forward_x = false;
      this->allow_linear_vel_backward_x = false;
      this->allow_linear_vel_forward_y = false;
      this->allow_linear_vel_backward_y = false;
    }
  }

  explicit CommandFilter_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->allow_linear_vel_forward_x = false;
      this->allow_linear_vel_backward_x = false;
      this->allow_linear_vel_forward_y = false;
      this->allow_linear_vel_backward_y = false;
    }
  }

  // field types and members
  using _allow_linear_vel_forward_x_type =
    bool;
  _allow_linear_vel_forward_x_type allow_linear_vel_forward_x;
  using _allow_linear_vel_backward_x_type =
    bool;
  _allow_linear_vel_backward_x_type allow_linear_vel_backward_x;
  using _allow_linear_vel_forward_y_type =
    bool;
  _allow_linear_vel_forward_y_type allow_linear_vel_forward_y;
  using _allow_linear_vel_backward_y_type =
    bool;
  _allow_linear_vel_backward_y_type allow_linear_vel_backward_y;

  // setters for named parameter idiom
  Type & set__allow_linear_vel_forward_x(
    const bool & _arg)
  {
    this->allow_linear_vel_forward_x = _arg;
    return *this;
  }
  Type & set__allow_linear_vel_backward_x(
    const bool & _arg)
  {
    this->allow_linear_vel_backward_x = _arg;
    return *this;
  }
  Type & set__allow_linear_vel_forward_y(
    const bool & _arg)
  {
    this->allow_linear_vel_forward_y = _arg;
    return *this;
  }
  Type & set__allow_linear_vel_backward_y(
    const bool & _arg)
  {
    this->allow_linear_vel_backward_y = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    core::msg::CommandFilter_<ContainerAllocator> *;
  using ConstRawPtr =
    const core::msg::CommandFilter_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<core::msg::CommandFilter_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<core::msg::CommandFilter_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      core::msg::CommandFilter_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<core::msg::CommandFilter_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      core::msg::CommandFilter_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<core::msg::CommandFilter_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<core::msg::CommandFilter_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<core::msg::CommandFilter_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__core__msg__CommandFilter
    std::shared_ptr<core::msg::CommandFilter_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__core__msg__CommandFilter
    std::shared_ptr<core::msg::CommandFilter_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const CommandFilter_ & other) const
  {
    if (this->allow_linear_vel_forward_x != other.allow_linear_vel_forward_x) {
      return false;
    }
    if (this->allow_linear_vel_backward_x != other.allow_linear_vel_backward_x) {
      return false;
    }
    if (this->allow_linear_vel_forward_y != other.allow_linear_vel_forward_y) {
      return false;
    }
    if (this->allow_linear_vel_backward_y != other.allow_linear_vel_backward_y) {
      return false;
    }
    return true;
  }
  bool operator!=(const CommandFilter_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct CommandFilter_

// alias to use template instance with default allocator
using CommandFilter =
  core::msg::CommandFilter_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace core

#endif  // CORE__MSG__DETAIL__COMMAND_FILTER__STRUCT_HPP_
