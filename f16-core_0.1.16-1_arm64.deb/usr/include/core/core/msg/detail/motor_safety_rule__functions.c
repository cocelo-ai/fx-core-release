// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from core:msg/MotorSafetyRule.idl
// generated code does not contain a copyright notice
#include "core/msg/detail/motor_safety_rule__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `safety`
#include "core/msg/detail/joint_safety__functions.h"

bool
core__msg__MotorSafetyRule__init(core__msg__MotorSafetyRule * msg)
{
  if (!msg) {
    return false;
  }
  // motor_id
  // safety
  if (!core__msg__JointSafety__init(&msg->safety)) {
    core__msg__MotorSafetyRule__fini(msg);
    return false;
  }
  return true;
}

void
core__msg__MotorSafetyRule__fini(core__msg__MotorSafetyRule * msg)
{
  if (!msg) {
    return;
  }
  // motor_id
  // safety
  core__msg__JointSafety__fini(&msg->safety);
}

bool
core__msg__MotorSafetyRule__are_equal(const core__msg__MotorSafetyRule * lhs, const core__msg__MotorSafetyRule * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // motor_id
  if (lhs->motor_id != rhs->motor_id) {
    return false;
  }
  // safety
  if (!core__msg__JointSafety__are_equal(
      &(lhs->safety), &(rhs->safety)))
  {
    return false;
  }
  return true;
}

bool
core__msg__MotorSafetyRule__copy(
  const core__msg__MotorSafetyRule * input,
  core__msg__MotorSafetyRule * output)
{
  if (!input || !output) {
    return false;
  }
  // motor_id
  output->motor_id = input->motor_id;
  // safety
  if (!core__msg__JointSafety__copy(
      &(input->safety), &(output->safety)))
  {
    return false;
  }
  return true;
}

core__msg__MotorSafetyRule *
core__msg__MotorSafetyRule__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__msg__MotorSafetyRule * msg = (core__msg__MotorSafetyRule *)allocator.allocate(sizeof(core__msg__MotorSafetyRule), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(core__msg__MotorSafetyRule));
  bool success = core__msg__MotorSafetyRule__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
core__msg__MotorSafetyRule__destroy(core__msg__MotorSafetyRule * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    core__msg__MotorSafetyRule__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
core__msg__MotorSafetyRule__Sequence__init(core__msg__MotorSafetyRule__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__msg__MotorSafetyRule * data = NULL;

  if (size) {
    data = (core__msg__MotorSafetyRule *)allocator.zero_allocate(size, sizeof(core__msg__MotorSafetyRule), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = core__msg__MotorSafetyRule__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        core__msg__MotorSafetyRule__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
core__msg__MotorSafetyRule__Sequence__fini(core__msg__MotorSafetyRule__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      core__msg__MotorSafetyRule__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

core__msg__MotorSafetyRule__Sequence *
core__msg__MotorSafetyRule__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__msg__MotorSafetyRule__Sequence * array = (core__msg__MotorSafetyRule__Sequence *)allocator.allocate(sizeof(core__msg__MotorSafetyRule__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = core__msg__MotorSafetyRule__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
core__msg__MotorSafetyRule__Sequence__destroy(core__msg__MotorSafetyRule__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    core__msg__MotorSafetyRule__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
core__msg__MotorSafetyRule__Sequence__are_equal(const core__msg__MotorSafetyRule__Sequence * lhs, const core__msg__MotorSafetyRule__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!core__msg__MotorSafetyRule__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
core__msg__MotorSafetyRule__Sequence__copy(
  const core__msg__MotorSafetyRule__Sequence * input,
  core__msg__MotorSafetyRule__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(core__msg__MotorSafetyRule);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    core__msg__MotorSafetyRule * data =
      (core__msg__MotorSafetyRule *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!core__msg__MotorSafetyRule__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          core__msg__MotorSafetyRule__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!core__msg__MotorSafetyRule__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
