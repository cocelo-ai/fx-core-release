// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from core:msg/CommandCore.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "core/msg/detail/command_core__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace core
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void CommandCore_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) core::msg::CommandCore(_init);
}

void CommandCore_fini_function(void * message_memory)
{
  auto typed_message = static_cast<core::msg::CommandCore *>(message_memory);
  typed_message->~CommandCore();
}

size_t size_function__CommandCore__motion_command(const void * untyped_member)
{
  (void)untyped_member;
  return 13;
}

const void * get_const_function__CommandCore__motion_command(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<float, 13> *>(untyped_member);
  return &member[index];
}

void * get_function__CommandCore__motion_command(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<float, 13> *>(untyped_member);
  return &member[index];
}

void fetch_function__CommandCore__motion_command(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__CommandCore__motion_command(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__CommandCore__motion_command(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__CommandCore__motion_command(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember CommandCore_message_member_array[3] = {
  {
    "motion_command",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    13,  // array size
    false,  // is upper bound
    offsetof(core::msg::CommandCore, motion_command),  // bytes offset in struct
    nullptr,  // default value
    size_function__CommandCore__motion_command,  // size() function pointer
    get_const_function__CommandCore__motion_command,  // get_const(index) function pointer
    get_function__CommandCore__motion_command,  // get(index) function pointer
    fetch_function__CommandCore__motion_command,  // fetch(index, &value) function pointer
    assign_function__CommandCore__motion_command,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "event",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<core::msg::EventCore>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core::msg::CommandCore, event),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "custom_drive_id",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core::msg::CommandCore, custom_drive_id),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers CommandCore_message_members = {
  "core::msg",  // message namespace
  "CommandCore",  // message name
  3,  // number of fields
  sizeof(core::msg::CommandCore),
  CommandCore_message_member_array,  // message members
  CommandCore_init_function,  // function to initialize message memory (memory has to be allocated)
  CommandCore_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t CommandCore_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &CommandCore_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace core


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<core::msg::CommandCore>()
{
  return &::core::msg::rosidl_typesupport_introspection_cpp::CommandCore_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, core, msg, CommandCore)() {
  return &::core::msg::rosidl_typesupport_introspection_cpp::CommandCore_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
