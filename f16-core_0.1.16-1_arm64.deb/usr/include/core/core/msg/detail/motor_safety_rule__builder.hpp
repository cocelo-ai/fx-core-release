// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from core:msg/MotorSafetyRule.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__MOTOR_SAFETY_RULE__BUILDER_HPP_
#define CORE__MSG__DETAIL__MOTOR_SAFETY_RULE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "core/msg/detail/motor_safety_rule__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace core
{

namespace msg
{

namespace builder
{

class Init_MotorSafetyRule_safety
{
public:
  explicit Init_MotorSafetyRule_safety(::core::msg::MotorSafetyRule & msg)
  : msg_(msg)
  {}
  ::core::msg::MotorSafetyRule safety(::core::msg::MotorSafetyRule::_safety_type arg)
  {
    msg_.safety = std::move(arg);
    return std::move(msg_);
  }

private:
  ::core::msg::MotorSafetyRule msg_;
};

class Init_MotorSafetyRule_motor_id
{
public:
  Init_MotorSafetyRule_motor_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotorSafetyRule_safety motor_id(::core::msg::MotorSafetyRule::_motor_id_type arg)
  {
    msg_.motor_id = std::move(arg);
    return Init_MotorSafetyRule_safety(msg_);
  }

private:
  ::core::msg::MotorSafetyRule msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::core::msg::MotorSafetyRule>()
{
  return core::msg::builder::Init_MotorSafetyRule_motor_id();
}

}  // namespace core

#endif  // CORE__MSG__DETAIL__MOTOR_SAFETY_RULE__BUILDER_HPP_
