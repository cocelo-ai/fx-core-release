// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from core:msg/MotorSafetyRule.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__MOTOR_SAFETY_RULE__STRUCT_H_
#define CORE__MSG__DETAIL__MOTOR_SAFETY_RULE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'safety'
#include "core/msg/detail/joint_safety__struct.h"

/// Struct defined in msg/MotorSafetyRule in the package core.
typedef struct core__msg__MotorSafetyRule
{
  uint8_t motor_id;
  core__msg__JointSafety safety;
} core__msg__MotorSafetyRule;

// Struct for a sequence of core__msg__MotorSafetyRule.
typedef struct core__msg__MotorSafetyRule__Sequence
{
  core__msg__MotorSafetyRule * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} core__msg__MotorSafetyRule__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CORE__MSG__DETAIL__MOTOR_SAFETY_RULE__STRUCT_H_
