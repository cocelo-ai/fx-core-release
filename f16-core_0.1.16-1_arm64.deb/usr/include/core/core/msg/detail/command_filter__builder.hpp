// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from core:msg/CommandFilter.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__COMMAND_FILTER__BUILDER_HPP_
#define CORE__MSG__DETAIL__COMMAND_FILTER__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "core/msg/detail/command_filter__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace core
{

namespace msg
{

namespace builder
{

class Init_CommandFilter_allow_linear_vel_backward_y
{
public:
  explicit Init_CommandFilter_allow_linear_vel_backward_y(::core::msg::CommandFilter & msg)
  : msg_(msg)
  {}
  ::core::msg::CommandFilter allow_linear_vel_backward_y(::core::msg::CommandFilter::_allow_linear_vel_backward_y_type arg)
  {
    msg_.allow_linear_vel_backward_y = std::move(arg);
    return std::move(msg_);
  }

private:
  ::core::msg::CommandFilter msg_;
};

class Init_CommandFilter_allow_linear_vel_forward_y
{
public:
  explicit Init_CommandFilter_allow_linear_vel_forward_y(::core::msg::CommandFilter & msg)
  : msg_(msg)
  {}
  Init_CommandFilter_allow_linear_vel_backward_y allow_linear_vel_forward_y(::core::msg::CommandFilter::_allow_linear_vel_forward_y_type arg)
  {
    msg_.allow_linear_vel_forward_y = std::move(arg);
    return Init_CommandFilter_allow_linear_vel_backward_y(msg_);
  }

private:
  ::core::msg::CommandFilter msg_;
};

class Init_CommandFilter_allow_linear_vel_backward_x
{
public:
  explicit Init_CommandFilter_allow_linear_vel_backward_x(::core::msg::CommandFilter & msg)
  : msg_(msg)
  {}
  Init_CommandFilter_allow_linear_vel_forward_y allow_linear_vel_backward_x(::core::msg::CommandFilter::_allow_linear_vel_backward_x_type arg)
  {
    msg_.allow_linear_vel_backward_x = std::move(arg);
    return Init_CommandFilter_allow_linear_vel_forward_y(msg_);
  }

private:
  ::core::msg::CommandFilter msg_;
};

class Init_CommandFilter_allow_linear_vel_forward_x
{
public:
  Init_CommandFilter_allow_linear_vel_forward_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CommandFilter_allow_linear_vel_backward_x allow_linear_vel_forward_x(::core::msg::CommandFilter::_allow_linear_vel_forward_x_type arg)
  {
    msg_.allow_linear_vel_forward_x = std::move(arg);
    return Init_CommandFilter_allow_linear_vel_backward_x(msg_);
  }

private:
  ::core::msg::CommandFilter msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::core::msg::CommandFilter>()
{
  return core::msg::builder::Init_CommandFilter_allow_linear_vel_forward_x();
}

}  // namespace core

#endif  // CORE__MSG__DETAIL__COMMAND_FILTER__BUILDER_HPP_
