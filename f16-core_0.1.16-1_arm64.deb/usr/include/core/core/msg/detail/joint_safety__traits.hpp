// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from core:msg/JointSafety.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__JOINT_SAFETY__TRAITS_HPP_
#define CORE__MSG__DETAIL__JOINT_SAFETY__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "core/msg/detail/joint_safety__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace core
{

namespace msg
{

inline void to_flow_style_yaml(
  const JointSafety & msg,
  std::ostream & out)
{
  out << "{";
  // member: pos_safety_margin_rad
  {
    out << "pos_safety_margin_rad: ";
    rosidl_generator_traits::value_to_yaml(msg.pos_safety_margin_rad, out);
    out << ", ";
  }

  // member: pos_margin_near_limit_rad
  {
    out << "pos_margin_near_limit_rad: ";
    rosidl_generator_traits::value_to_yaml(msg.pos_margin_near_limit_rad, out);
    out << ", ";
  }

  // member: vel_threshold_near_limit_rad_s
  {
    out << "vel_threshold_near_limit_rad_s: ";
    rosidl_generator_traits::value_to_yaml(msg.vel_threshold_near_limit_rad_s, out);
    out << ", ";
  }

  // member: vel_hard_limit_rad_s
  {
    out << "vel_hard_limit_rad_s: ";
    rosidl_generator_traits::value_to_yaml(msg.vel_hard_limit_rad_s, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const JointSafety & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: pos_safety_margin_rad
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pos_safety_margin_rad: ";
    rosidl_generator_traits::value_to_yaml(msg.pos_safety_margin_rad, out);
    out << "\n";
  }

  // member: pos_margin_near_limit_rad
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pos_margin_near_limit_rad: ";
    rosidl_generator_traits::value_to_yaml(msg.pos_margin_near_limit_rad, out);
    out << "\n";
  }

  // member: vel_threshold_near_limit_rad_s
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vel_threshold_near_limit_rad_s: ";
    rosidl_generator_traits::value_to_yaml(msg.vel_threshold_near_limit_rad_s, out);
    out << "\n";
  }

  // member: vel_hard_limit_rad_s
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vel_hard_limit_rad_s: ";
    rosidl_generator_traits::value_to_yaml(msg.vel_hard_limit_rad_s, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const JointSafety & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace core

namespace rosidl_generator_traits
{

[[deprecated("use core::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const core::msg::JointSafety & msg,
  std::ostream & out, size_t indentation = 0)
{
  core::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use core::msg::to_yaml() instead")]]
inline std::string to_yaml(const core::msg::JointSafety & msg)
{
  return core::msg::to_yaml(msg);
}

template<>
inline const char * data_type<core::msg::JointSafety>()
{
  return "core::msg::JointSafety";
}

template<>
inline const char * name<core::msg::JointSafety>()
{
  return "core/msg/JointSafety";
}

template<>
struct has_fixed_size<core::msg::JointSafety>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<core::msg::JointSafety>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<core::msg::JointSafety>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CORE__MSG__DETAIL__JOINT_SAFETY__TRAITS_HPP_
