// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from core:msg/CommandCore.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__COMMAND_CORE__BUILDER_HPP_
#define CORE__MSG__DETAIL__COMMAND_CORE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "core/msg/detail/command_core__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace core
{

namespace msg
{

namespace builder
{

class Init_CommandCore_custom_drive_id
{
public:
  explicit Init_CommandCore_custom_drive_id(::core::msg::CommandCore & msg)
  : msg_(msg)
  {}
  ::core::msg::CommandCore custom_drive_id(::core::msg::CommandCore::_custom_drive_id_type arg)
  {
    msg_.custom_drive_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::core::msg::CommandCore msg_;
};

class Init_CommandCore_event
{
public:
  explicit Init_CommandCore_event(::core::msg::CommandCore & msg)
  : msg_(msg)
  {}
  Init_CommandCore_custom_drive_id event(::core::msg::CommandCore::_event_type arg)
  {
    msg_.event = std::move(arg);
    return Init_CommandCore_custom_drive_id(msg_);
  }

private:
  ::core::msg::CommandCore msg_;
};

class Init_CommandCore_motion_command
{
public:
  Init_CommandCore_motion_command()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CommandCore_event motion_command(::core::msg::CommandCore::_motion_command_type arg)
  {
    msg_.motion_command = std::move(arg);
    return Init_CommandCore_event(msg_);
  }

private:
  ::core::msg::CommandCore msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::core::msg::CommandCore>()
{
  return core::msg::builder::Init_CommandCore_motion_command();
}

}  // namespace core

#endif  // CORE__MSG__DETAIL__COMMAND_CORE__BUILDER_HPP_
