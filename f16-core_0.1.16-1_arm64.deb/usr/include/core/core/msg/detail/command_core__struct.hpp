// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from core:msg/CommandCore.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__COMMAND_CORE__STRUCT_HPP_
#define CORE__MSG__DETAIL__COMMAND_CORE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'event'
#include "core/msg/detail/event_core__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__core__msg__CommandCore __attribute__((deprecated))
#else
# define DEPRECATED__core__msg__CommandCore __declspec(deprecated)
#endif

namespace core
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct CommandCore_
{
  using Type = CommandCore_<ContainerAllocator>;

  explicit CommandCore_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : event(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<float, 13>::iterator, float>(this->motion_command.begin(), this->motion_command.end(), 0.0f);
      this->custom_drive_id = 0;
    }
  }

  explicit CommandCore_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : motion_command(_alloc),
    event(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<float, 13>::iterator, float>(this->motion_command.begin(), this->motion_command.end(), 0.0f);
      this->custom_drive_id = 0;
    }
  }

  // field types and members
  using _motion_command_type =
    std::array<float, 13>;
  _motion_command_type motion_command;
  using _event_type =
    core::msg::EventCore_<ContainerAllocator>;
  _event_type event;
  using _custom_drive_id_type =
    uint8_t;
  _custom_drive_id_type custom_drive_id;

  // setters for named parameter idiom
  Type & set__motion_command(
    const std::array<float, 13> & _arg)
  {
    this->motion_command = _arg;
    return *this;
  }
  Type & set__event(
    const core::msg::EventCore_<ContainerAllocator> & _arg)
  {
    this->event = _arg;
    return *this;
  }
  Type & set__custom_drive_id(
    const uint8_t & _arg)
  {
    this->custom_drive_id = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    core::msg::CommandCore_<ContainerAllocator> *;
  using ConstRawPtr =
    const core::msg::CommandCore_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<core::msg::CommandCore_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<core::msg::CommandCore_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      core::msg::CommandCore_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<core::msg::CommandCore_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      core::msg::CommandCore_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<core::msg::CommandCore_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<core::msg::CommandCore_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<core::msg::CommandCore_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__core__msg__CommandCore
    std::shared_ptr<core::msg::CommandCore_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__core__msg__CommandCore
    std::shared_ptr<core::msg::CommandCore_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const CommandCore_ & other) const
  {
    if (this->motion_command != other.motion_command) {
      return false;
    }
    if (this->event != other.event) {
      return false;
    }
    if (this->custom_drive_id != other.custom_drive_id) {
      return false;
    }
    return true;
  }
  bool operator!=(const CommandCore_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct CommandCore_

// alias to use template instance with default allocator
using CommandCore =
  core::msg::CommandCore_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace core

#endif  // CORE__MSG__DETAIL__COMMAND_CORE__STRUCT_HPP_
