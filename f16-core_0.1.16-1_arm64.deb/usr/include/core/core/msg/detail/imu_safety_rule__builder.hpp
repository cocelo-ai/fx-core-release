// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from core:msg/ImuSafetyRule.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__IMU_SAFETY_RULE__BUILDER_HPP_
#define CORE__MSG__DETAIL__IMU_SAFETY_RULE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "core/msg/detail/imu_safety_rule__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace core
{

namespace msg
{

namespace builder
{

class Init_ImuSafetyRule_max_proj_grav_z
{
public:
  explicit Init_ImuSafetyRule_max_proj_grav_z(::core::msg::ImuSafetyRule & msg)
  : msg_(msg)
  {}
  ::core::msg::ImuSafetyRule max_proj_grav_z(::core::msg::ImuSafetyRule::_max_proj_grav_z_type arg)
  {
    msg_.max_proj_grav_z = std::move(arg);
    return std::move(msg_);
  }

private:
  ::core::msg::ImuSafetyRule msg_;
};

class Init_ImuSafetyRule_use_proj_grav_z_safety
{
public:
  explicit Init_ImuSafetyRule_use_proj_grav_z_safety(::core::msg::ImuSafetyRule & msg)
  : msg_(msg)
  {}
  Init_ImuSafetyRule_max_proj_grav_z use_proj_grav_z_safety(::core::msg::ImuSafetyRule::_use_proj_grav_z_safety_type arg)
  {
    msg_.use_proj_grav_z_safety = std::move(arg);
    return Init_ImuSafetyRule_max_proj_grav_z(msg_);
  }

private:
  ::core::msg::ImuSafetyRule msg_;
};

class Init_ImuSafetyRule_imu_order
{
public:
  Init_ImuSafetyRule_imu_order()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ImuSafetyRule_use_proj_grav_z_safety imu_order(::core::msg::ImuSafetyRule::_imu_order_type arg)
  {
    msg_.imu_order = std::move(arg);
    return Init_ImuSafetyRule_use_proj_grav_z_safety(msg_);
  }

private:
  ::core::msg::ImuSafetyRule msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::core::msg::ImuSafetyRule>()
{
  return core::msg::builder::Init_ImuSafetyRule_imu_order();
}

}  // namespace core

#endif  // CORE__MSG__DETAIL__IMU_SAFETY_RULE__BUILDER_HPP_
