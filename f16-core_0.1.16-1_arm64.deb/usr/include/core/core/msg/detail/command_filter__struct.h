// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from core:msg/CommandFilter.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__COMMAND_FILTER__STRUCT_H_
#define CORE__MSG__DETAIL__COMMAND_FILTER__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/CommandFilter in the package core.
typedef struct core__msg__CommandFilter
{
  bool allow_linear_vel_forward_x;
  bool allow_linear_vel_backward_x;
  bool allow_linear_vel_forward_y;
  bool allow_linear_vel_backward_y;
} core__msg__CommandFilter;

// Struct for a sequence of core__msg__CommandFilter.
typedef struct core__msg__CommandFilter__Sequence
{
  core__msg__CommandFilter * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} core__msg__CommandFilter__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CORE__MSG__DETAIL__COMMAND_FILTER__STRUCT_H_
