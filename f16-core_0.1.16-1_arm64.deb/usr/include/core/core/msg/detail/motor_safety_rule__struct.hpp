// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from core:msg/MotorSafetyRule.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__MOTOR_SAFETY_RULE__STRUCT_HPP_
#define CORE__MSG__DETAIL__MOTOR_SAFETY_RULE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'safety'
#include "core/msg/detail/joint_safety__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__core__msg__MotorSafetyRule __attribute__((deprecated))
#else
# define DEPRECATED__core__msg__MotorSafetyRule __declspec(deprecated)
#endif

namespace core
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct MotorSafetyRule_
{
  using Type = MotorSafetyRule_<ContainerAllocator>;

  explicit MotorSafetyRule_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : safety(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->motor_id = 0;
    }
  }

  explicit MotorSafetyRule_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : safety(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->motor_id = 0;
    }
  }

  // field types and members
  using _motor_id_type =
    uint8_t;
  _motor_id_type motor_id;
  using _safety_type =
    core::msg::JointSafety_<ContainerAllocator>;
  _safety_type safety;

  // setters for named parameter idiom
  Type & set__motor_id(
    const uint8_t & _arg)
  {
    this->motor_id = _arg;
    return *this;
  }
  Type & set__safety(
    const core::msg::JointSafety_<ContainerAllocator> & _arg)
  {
    this->safety = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    core::msg::MotorSafetyRule_<ContainerAllocator> *;
  using ConstRawPtr =
    const core::msg::MotorSafetyRule_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<core::msg::MotorSafetyRule_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<core::msg::MotorSafetyRule_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      core::msg::MotorSafetyRule_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<core::msg::MotorSafetyRule_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      core::msg::MotorSafetyRule_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<core::msg::MotorSafetyRule_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<core::msg::MotorSafetyRule_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<core::msg::MotorSafetyRule_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__core__msg__MotorSafetyRule
    std::shared_ptr<core::msg::MotorSafetyRule_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__core__msg__MotorSafetyRule
    std::shared_ptr<core::msg::MotorSafetyRule_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MotorSafetyRule_ & other) const
  {
    if (this->motor_id != other.motor_id) {
      return false;
    }
    if (this->safety != other.safety) {
      return false;
    }
    return true;
  }
  bool operator!=(const MotorSafetyRule_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MotorSafetyRule_

// alias to use template instance with default allocator
using MotorSafetyRule =
  core::msg::MotorSafetyRule_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace core

#endif  // CORE__MSG__DETAIL__MOTOR_SAFETY_RULE__STRUCT_HPP_
