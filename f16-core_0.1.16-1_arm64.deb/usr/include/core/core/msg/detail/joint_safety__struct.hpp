// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from core:msg/JointSafety.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__JOINT_SAFETY__STRUCT_HPP_
#define CORE__MSG__DETAIL__JOINT_SAFETY__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__core__msg__JointSafety __attribute__((deprecated))
#else
# define DEPRECATED__core__msg__JointSafety __declspec(deprecated)
#endif

namespace core
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct JointSafety_
{
  using Type = JointSafety_<ContainerAllocator>;

  explicit JointSafety_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->pos_safety_margin_rad = 0.0f;
      this->pos_margin_near_limit_rad = 0.0f;
      this->vel_threshold_near_limit_rad_s = 0.0f;
      this->vel_hard_limit_rad_s = 0.0f;
    }
  }

  explicit JointSafety_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->pos_safety_margin_rad = 0.0f;
      this->pos_margin_near_limit_rad = 0.0f;
      this->vel_threshold_near_limit_rad_s = 0.0f;
      this->vel_hard_limit_rad_s = 0.0f;
    }
  }

  // field types and members
  using _pos_safety_margin_rad_type =
    float;
  _pos_safety_margin_rad_type pos_safety_margin_rad;
  using _pos_margin_near_limit_rad_type =
    float;
  _pos_margin_near_limit_rad_type pos_margin_near_limit_rad;
  using _vel_threshold_near_limit_rad_s_type =
    float;
  _vel_threshold_near_limit_rad_s_type vel_threshold_near_limit_rad_s;
  using _vel_hard_limit_rad_s_type =
    float;
  _vel_hard_limit_rad_s_type vel_hard_limit_rad_s;

  // setters for named parameter idiom
  Type & set__pos_safety_margin_rad(
    const float & _arg)
  {
    this->pos_safety_margin_rad = _arg;
    return *this;
  }
  Type & set__pos_margin_near_limit_rad(
    const float & _arg)
  {
    this->pos_margin_near_limit_rad = _arg;
    return *this;
  }
  Type & set__vel_threshold_near_limit_rad_s(
    const float & _arg)
  {
    this->vel_threshold_near_limit_rad_s = _arg;
    return *this;
  }
  Type & set__vel_hard_limit_rad_s(
    const float & _arg)
  {
    this->vel_hard_limit_rad_s = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    core::msg::JointSafety_<ContainerAllocator> *;
  using ConstRawPtr =
    const core::msg::JointSafety_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<core::msg::JointSafety_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<core::msg::JointSafety_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      core::msg::JointSafety_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<core::msg::JointSafety_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      core::msg::JointSafety_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<core::msg::JointSafety_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<core::msg::JointSafety_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<core::msg::JointSafety_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__core__msg__JointSafety
    std::shared_ptr<core::msg::JointSafety_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__core__msg__JointSafety
    std::shared_ptr<core::msg::JointSafety_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const JointSafety_ & other) const
  {
    if (this->pos_safety_margin_rad != other.pos_safety_margin_rad) {
      return false;
    }
    if (this->pos_margin_near_limit_rad != other.pos_margin_near_limit_rad) {
      return false;
    }
    if (this->vel_threshold_near_limit_rad_s != other.vel_threshold_near_limit_rad_s) {
      return false;
    }
    if (this->vel_hard_limit_rad_s != other.vel_hard_limit_rad_s) {
      return false;
    }
    return true;
  }
  bool operator!=(const JointSafety_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct JointSafety_

// alias to use template instance with default allocator
using JointSafety =
  core::msg::JointSafety_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace core

#endif  // CORE__MSG__DETAIL__JOINT_SAFETY__STRUCT_HPP_
