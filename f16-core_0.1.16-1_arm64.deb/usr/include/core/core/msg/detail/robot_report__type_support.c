// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from core:msg/RobotReport.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "core/msg/detail/robot_report__rosidl_typesupport_introspection_c.h"
#include "core/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "core/msg/detail/robot_report__functions.h"
#include "core/msg/detail/robot_report__struct.h"


// Include directives for member types
// Member `robot_state_name`
// Member `active_command_source_name`
// Member `error_reason`
// Member `motor_pattern`
// Member `motor_err`
// Member `battery_voltage`
// Member `battery_soc`
// Member `battery_current`
// Member `battery_temperature`
// Member `battery_power`
#include "rosidl_runtime_c/string_functions.h"
// Member `motor_pattern_ok`
// Member `dof_pos`
// Member `dof_vel`
// Member `dof_tau`
// Member `ang_vel`
// Member `proj_grav`
// Member `lin_vel`
// Member `height_map`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void core__msg__RobotReport__rosidl_typesupport_introspection_c__RobotReport_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  core__msg__RobotReport__init(message_memory);
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__RobotReport_fini_function(void * message_memory)
{
  core__msg__RobotReport__fini(message_memory);
}

size_t core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__motion_command(
  const void * untyped_member)
{
  (void)untyped_member;
  return 13;
}

const void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__motion_command(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__motion_command(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__motion_command(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__motion_command(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__motion_command(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__motion_command(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__motor_pattern(
  const void * untyped_member)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return member->size;
}

const void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__motor_pattern(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__motor_pattern(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__motor_pattern(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const rosidl_runtime_c__String * item =
    ((const rosidl_runtime_c__String *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__motor_pattern(untyped_member, index));
  rosidl_runtime_c__String * value =
    (rosidl_runtime_c__String *)(untyped_value);
  *value = *item;
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__motor_pattern(
  void * untyped_member, size_t index, const void * untyped_value)
{
  rosidl_runtime_c__String * item =
    ((rosidl_runtime_c__String *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__motor_pattern(untyped_member, index));
  const rosidl_runtime_c__String * value =
    (const rosidl_runtime_c__String *)(untyped_value);
  *item = *value;
}

bool core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__motor_pattern(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  rosidl_runtime_c__String__Sequence__fini(member);
  return rosidl_runtime_c__String__Sequence__init(member, size);
}

size_t core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__motor_pattern_ok(
  const void * untyped_member)
{
  const rosidl_runtime_c__boolean__Sequence * member =
    (const rosidl_runtime_c__boolean__Sequence *)(untyped_member);
  return member->size;
}

const void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__motor_pattern_ok(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__boolean__Sequence * member =
    (const rosidl_runtime_c__boolean__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__motor_pattern_ok(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__boolean__Sequence * member =
    (rosidl_runtime_c__boolean__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__motor_pattern_ok(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const bool * item =
    ((const bool *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__motor_pattern_ok(untyped_member, index));
  bool * value =
    (bool *)(untyped_value);
  *value = *item;
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__motor_pattern_ok(
  void * untyped_member, size_t index, const void * untyped_value)
{
  bool * item =
    ((bool *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__motor_pattern_ok(untyped_member, index));
  const bool * value =
    (const bool *)(untyped_value);
  *item = *value;
}

bool core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__motor_pattern_ok(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__boolean__Sequence * member =
    (rosidl_runtime_c__boolean__Sequence *)(untyped_member);
  rosidl_runtime_c__boolean__Sequence__fini(member);
  return rosidl_runtime_c__boolean__Sequence__init(member, size);
}

size_t core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__motor_err(
  const void * untyped_member)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return member->size;
}

const void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__motor_err(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__motor_err(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__motor_err(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const rosidl_runtime_c__String * item =
    ((const rosidl_runtime_c__String *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__motor_err(untyped_member, index));
  rosidl_runtime_c__String * value =
    (rosidl_runtime_c__String *)(untyped_value);
  *value = *item;
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__motor_err(
  void * untyped_member, size_t index, const void * untyped_value)
{
  rosidl_runtime_c__String * item =
    ((rosidl_runtime_c__String *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__motor_err(untyped_member, index));
  const rosidl_runtime_c__String * value =
    (const rosidl_runtime_c__String *)(untyped_value);
  *item = *value;
}

bool core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__motor_err(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  rosidl_runtime_c__String__Sequence__fini(member);
  return rosidl_runtime_c__String__Sequence__init(member, size);
}

size_t core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__dof_pos(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__dof_pos(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__dof_pos(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__dof_pos(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__dof_pos(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__dof_pos(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__dof_pos(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__dof_pos(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__dof_vel(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__dof_vel(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__dof_vel(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__dof_vel(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__dof_vel(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__dof_vel(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__dof_vel(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__dof_vel(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__dof_tau(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__dof_tau(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__dof_tau(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__dof_tau(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__dof_tau(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__dof_tau(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__dof_tau(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__dof_tau(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__ang_vel(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__ang_vel(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__ang_vel(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__ang_vel(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__ang_vel(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__ang_vel(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__ang_vel(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__ang_vel(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__proj_grav(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__proj_grav(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__proj_grav(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__proj_grav(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__proj_grav(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__proj_grav(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__proj_grav(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__proj_grav(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__lin_vel(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__lin_vel(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__lin_vel(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__lin_vel(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__lin_vel(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__lin_vel(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__lin_vel(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__lin_vel(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__height_map(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__height_map(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__height_map(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__height_map(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__height_map(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__height_map(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__height_map(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__height_map(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember core__msg__RobotReport__rosidl_typesupport_introspection_c__RobotReport_message_member_array[34] = {
  {
    "robot_state",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, robot_state),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "robot_state_name",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, robot_state_name),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "robot_initialized",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, robot_initialized),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "custom_drive_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, custom_drive_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "active_command_source",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, active_command_source),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "active_command_source_name",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, active_command_source_name),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "active_command_fresh",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, active_command_fresh),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "sdk_mode_enabled",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, sdk_mode_enabled),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "data_collection_mode_enabled",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, data_collection_mode_enabled),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "motion_command",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    13,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, motion_command),  // bytes offset in struct
    NULL,  // default value
    core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__motion_command,  // size() function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__motion_command,  // get_const(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__motion_command,  // get(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__motion_command,  // fetch(index, &value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__motion_command,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "physical_estop",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, physical_estop),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "physical_fault",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, physical_fault),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "comm_estop",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, comm_estop),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "comm_fault",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, comm_fault),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "command_estop",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, command_estop),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "safety_estop",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, safety_estop),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "safety_fault",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, safety_fault),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "controller_failure",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, controller_failure),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "error_reason",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, error_reason),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "motor_pattern",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, motor_pattern),  // bytes offset in struct
    NULL,  // default value
    core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__motor_pattern,  // size() function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__motor_pattern,  // get_const(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__motor_pattern,  // get(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__motor_pattern,  // fetch(index, &value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__motor_pattern,  // assign(index, value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__motor_pattern  // resize(index) function pointer
  },
  {
    "motor_pattern_ok",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, motor_pattern_ok),  // bytes offset in struct
    NULL,  // default value
    core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__motor_pattern_ok,  // size() function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__motor_pattern_ok,  // get_const(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__motor_pattern_ok,  // get(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__motor_pattern_ok,  // fetch(index, &value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__motor_pattern_ok,  // assign(index, value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__motor_pattern_ok  // resize(index) function pointer
  },
  {
    "motor_err",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, motor_err),  // bytes offset in struct
    NULL,  // default value
    core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__motor_err,  // size() function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__motor_err,  // get_const(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__motor_err,  // get(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__motor_err,  // fetch(index, &value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__motor_err,  // assign(index, value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__motor_err  // resize(index) function pointer
  },
  {
    "battery_voltage",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, battery_voltage),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "battery_soc",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, battery_soc),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "battery_current",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, battery_current),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "battery_temperature",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, battery_temperature),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "battery_power",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, battery_power),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "dof_pos",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, dof_pos),  // bytes offset in struct
    NULL,  // default value
    core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__dof_pos,  // size() function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__dof_pos,  // get_const(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__dof_pos,  // get(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__dof_pos,  // fetch(index, &value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__dof_pos,  // assign(index, value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__dof_pos  // resize(index) function pointer
  },
  {
    "dof_vel",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, dof_vel),  // bytes offset in struct
    NULL,  // default value
    core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__dof_vel,  // size() function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__dof_vel,  // get_const(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__dof_vel,  // get(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__dof_vel,  // fetch(index, &value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__dof_vel,  // assign(index, value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__dof_vel  // resize(index) function pointer
  },
  {
    "dof_tau",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, dof_tau),  // bytes offset in struct
    NULL,  // default value
    core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__dof_tau,  // size() function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__dof_tau,  // get_const(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__dof_tau,  // get(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__dof_tau,  // fetch(index, &value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__dof_tau,  // assign(index, value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__dof_tau  // resize(index) function pointer
  },
  {
    "ang_vel",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, ang_vel),  // bytes offset in struct
    NULL,  // default value
    core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__ang_vel,  // size() function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__ang_vel,  // get_const(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__ang_vel,  // get(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__ang_vel,  // fetch(index, &value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__ang_vel,  // assign(index, value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__ang_vel  // resize(index) function pointer
  },
  {
    "proj_grav",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, proj_grav),  // bytes offset in struct
    NULL,  // default value
    core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__proj_grav,  // size() function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__proj_grav,  // get_const(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__proj_grav,  // get(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__proj_grav,  // fetch(index, &value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__proj_grav,  // assign(index, value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__proj_grav  // resize(index) function pointer
  },
  {
    "lin_vel",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, lin_vel),  // bytes offset in struct
    NULL,  // default value
    core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__lin_vel,  // size() function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__lin_vel,  // get_const(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__lin_vel,  // get(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__lin_vel,  // fetch(index, &value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__lin_vel,  // assign(index, value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__lin_vel  // resize(index) function pointer
  },
  {
    "height_map",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__RobotReport, height_map),  // bytes offset in struct
    NULL,  // default value
    core__msg__RobotReport__rosidl_typesupport_introspection_c__size_function__RobotReport__height_map,  // size() function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_const_function__RobotReport__height_map,  // get_const(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__get_function__RobotReport__height_map,  // get(index) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__fetch_function__RobotReport__height_map,  // fetch(index, &value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__assign_function__RobotReport__height_map,  // assign(index, value) function pointer
    core__msg__RobotReport__rosidl_typesupport_introspection_c__resize_function__RobotReport__height_map  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers core__msg__RobotReport__rosidl_typesupport_introspection_c__RobotReport_message_members = {
  "core__msg",  // message namespace
  "RobotReport",  // message name
  34,  // number of fields
  sizeof(core__msg__RobotReport),
  core__msg__RobotReport__rosidl_typesupport_introspection_c__RobotReport_message_member_array,  // message members
  core__msg__RobotReport__rosidl_typesupport_introspection_c__RobotReport_init_function,  // function to initialize message memory (memory has to be allocated)
  core__msg__RobotReport__rosidl_typesupport_introspection_c__RobotReport_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t core__msg__RobotReport__rosidl_typesupport_introspection_c__RobotReport_message_type_support_handle = {
  0,
  &core__msg__RobotReport__rosidl_typesupport_introspection_c__RobotReport_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_core
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, core, msg, RobotReport)() {
  if (!core__msg__RobotReport__rosidl_typesupport_introspection_c__RobotReport_message_type_support_handle.typesupport_identifier) {
    core__msg__RobotReport__rosidl_typesupport_introspection_c__RobotReport_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &core__msg__RobotReport__rosidl_typesupport_introspection_c__RobotReport_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
