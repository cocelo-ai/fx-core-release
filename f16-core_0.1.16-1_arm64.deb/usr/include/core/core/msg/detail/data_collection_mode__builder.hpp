// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from core:msg/DataCollectionMode.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__DATA_COLLECTION_MODE__BUILDER_HPP_
#define CORE__MSG__DETAIL__DATA_COLLECTION_MODE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "core/msg/detail/data_collection_mode__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace core
{

namespace msg
{

namespace builder
{

class Init_DataCollectionMode_enabled
{
public:
  Init_DataCollectionMode_enabled()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::core::msg::DataCollectionMode enabled(::core::msg::DataCollectionMode::_enabled_type arg)
  {
    msg_.enabled = std::move(arg);
    return std::move(msg_);
  }

private:
  ::core::msg::DataCollectionMode msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::core::msg::DataCollectionMode>()
{
  return core::msg::builder::Init_DataCollectionMode_enabled();
}

}  // namespace core

#endif  // CORE__MSG__DETAIL__DATA_COLLECTION_MODE__BUILDER_HPP_
