// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from core:msg/RobotReport.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__ROBOT_REPORT__BUILDER_HPP_
#define CORE__MSG__DETAIL__ROBOT_REPORT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "core/msg/detail/robot_report__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace core
{

namespace msg
{

namespace builder
{

class Init_RobotReport_height_map
{
public:
  explicit Init_RobotReport_height_map(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  ::core::msg::RobotReport height_map(::core::msg::RobotReport::_height_map_type arg)
  {
    msg_.height_map = std::move(arg);
    return std::move(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_lin_vel
{
public:
  explicit Init_RobotReport_lin_vel(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_height_map lin_vel(::core::msg::RobotReport::_lin_vel_type arg)
  {
    msg_.lin_vel = std::move(arg);
    return Init_RobotReport_height_map(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_proj_grav
{
public:
  explicit Init_RobotReport_proj_grav(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_lin_vel proj_grav(::core::msg::RobotReport::_proj_grav_type arg)
  {
    msg_.proj_grav = std::move(arg);
    return Init_RobotReport_lin_vel(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_ang_vel
{
public:
  explicit Init_RobotReport_ang_vel(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_proj_grav ang_vel(::core::msg::RobotReport::_ang_vel_type arg)
  {
    msg_.ang_vel = std::move(arg);
    return Init_RobotReport_proj_grav(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_dof_tau
{
public:
  explicit Init_RobotReport_dof_tau(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_ang_vel dof_tau(::core::msg::RobotReport::_dof_tau_type arg)
  {
    msg_.dof_tau = std::move(arg);
    return Init_RobotReport_ang_vel(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_dof_vel
{
public:
  explicit Init_RobotReport_dof_vel(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_dof_tau dof_vel(::core::msg::RobotReport::_dof_vel_type arg)
  {
    msg_.dof_vel = std::move(arg);
    return Init_RobotReport_dof_tau(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_dof_pos
{
public:
  explicit Init_RobotReport_dof_pos(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_dof_vel dof_pos(::core::msg::RobotReport::_dof_pos_type arg)
  {
    msg_.dof_pos = std::move(arg);
    return Init_RobotReport_dof_vel(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_battery_power
{
public:
  explicit Init_RobotReport_battery_power(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_dof_pos battery_power(::core::msg::RobotReport::_battery_power_type arg)
  {
    msg_.battery_power = std::move(arg);
    return Init_RobotReport_dof_pos(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_battery_temperature
{
public:
  explicit Init_RobotReport_battery_temperature(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_battery_power battery_temperature(::core::msg::RobotReport::_battery_temperature_type arg)
  {
    msg_.battery_temperature = std::move(arg);
    return Init_RobotReport_battery_power(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_battery_current
{
public:
  explicit Init_RobotReport_battery_current(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_battery_temperature battery_current(::core::msg::RobotReport::_battery_current_type arg)
  {
    msg_.battery_current = std::move(arg);
    return Init_RobotReport_battery_temperature(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_battery_soc
{
public:
  explicit Init_RobotReport_battery_soc(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_battery_current battery_soc(::core::msg::RobotReport::_battery_soc_type arg)
  {
    msg_.battery_soc = std::move(arg);
    return Init_RobotReport_battery_current(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_battery_voltage
{
public:
  explicit Init_RobotReport_battery_voltage(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_battery_soc battery_voltage(::core::msg::RobotReport::_battery_voltage_type arg)
  {
    msg_.battery_voltage = std::move(arg);
    return Init_RobotReport_battery_soc(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_motor_err
{
public:
  explicit Init_RobotReport_motor_err(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_battery_voltage motor_err(::core::msg::RobotReport::_motor_err_type arg)
  {
    msg_.motor_err = std::move(arg);
    return Init_RobotReport_battery_voltage(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_motor_pattern_ok
{
public:
  explicit Init_RobotReport_motor_pattern_ok(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_motor_err motor_pattern_ok(::core::msg::RobotReport::_motor_pattern_ok_type arg)
  {
    msg_.motor_pattern_ok = std::move(arg);
    return Init_RobotReport_motor_err(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_motor_pattern
{
public:
  explicit Init_RobotReport_motor_pattern(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_motor_pattern_ok motor_pattern(::core::msg::RobotReport::_motor_pattern_type arg)
  {
    msg_.motor_pattern = std::move(arg);
    return Init_RobotReport_motor_pattern_ok(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_error_reason
{
public:
  explicit Init_RobotReport_error_reason(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_motor_pattern error_reason(::core::msg::RobotReport::_error_reason_type arg)
  {
    msg_.error_reason = std::move(arg);
    return Init_RobotReport_motor_pattern(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_controller_failure
{
public:
  explicit Init_RobotReport_controller_failure(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_error_reason controller_failure(::core::msg::RobotReport::_controller_failure_type arg)
  {
    msg_.controller_failure = std::move(arg);
    return Init_RobotReport_error_reason(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_safety_fault
{
public:
  explicit Init_RobotReport_safety_fault(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_controller_failure safety_fault(::core::msg::RobotReport::_safety_fault_type arg)
  {
    msg_.safety_fault = std::move(arg);
    return Init_RobotReport_controller_failure(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_safety_estop
{
public:
  explicit Init_RobotReport_safety_estop(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_safety_fault safety_estop(::core::msg::RobotReport::_safety_estop_type arg)
  {
    msg_.safety_estop = std::move(arg);
    return Init_RobotReport_safety_fault(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_command_estop
{
public:
  explicit Init_RobotReport_command_estop(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_safety_estop command_estop(::core::msg::RobotReport::_command_estop_type arg)
  {
    msg_.command_estop = std::move(arg);
    return Init_RobotReport_safety_estop(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_comm_fault
{
public:
  explicit Init_RobotReport_comm_fault(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_command_estop comm_fault(::core::msg::RobotReport::_comm_fault_type arg)
  {
    msg_.comm_fault = std::move(arg);
    return Init_RobotReport_command_estop(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_comm_estop
{
public:
  explicit Init_RobotReport_comm_estop(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_comm_fault comm_estop(::core::msg::RobotReport::_comm_estop_type arg)
  {
    msg_.comm_estop = std::move(arg);
    return Init_RobotReport_comm_fault(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_physical_fault
{
public:
  explicit Init_RobotReport_physical_fault(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_comm_estop physical_fault(::core::msg::RobotReport::_physical_fault_type arg)
  {
    msg_.physical_fault = std::move(arg);
    return Init_RobotReport_comm_estop(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_physical_estop
{
public:
  explicit Init_RobotReport_physical_estop(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_physical_fault physical_estop(::core::msg::RobotReport::_physical_estop_type arg)
  {
    msg_.physical_estop = std::move(arg);
    return Init_RobotReport_physical_fault(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_motion_command
{
public:
  explicit Init_RobotReport_motion_command(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_physical_estop motion_command(::core::msg::RobotReport::_motion_command_type arg)
  {
    msg_.motion_command = std::move(arg);
    return Init_RobotReport_physical_estop(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_data_collection_mode_enabled
{
public:
  explicit Init_RobotReport_data_collection_mode_enabled(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_motion_command data_collection_mode_enabled(::core::msg::RobotReport::_data_collection_mode_enabled_type arg)
  {
    msg_.data_collection_mode_enabled = std::move(arg);
    return Init_RobotReport_motion_command(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_sdk_mode_enabled
{
public:
  explicit Init_RobotReport_sdk_mode_enabled(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_data_collection_mode_enabled sdk_mode_enabled(::core::msg::RobotReport::_sdk_mode_enabled_type arg)
  {
    msg_.sdk_mode_enabled = std::move(arg);
    return Init_RobotReport_data_collection_mode_enabled(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_active_command_fresh
{
public:
  explicit Init_RobotReport_active_command_fresh(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_sdk_mode_enabled active_command_fresh(::core::msg::RobotReport::_active_command_fresh_type arg)
  {
    msg_.active_command_fresh = std::move(arg);
    return Init_RobotReport_sdk_mode_enabled(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_active_command_source_name
{
public:
  explicit Init_RobotReport_active_command_source_name(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_active_command_fresh active_command_source_name(::core::msg::RobotReport::_active_command_source_name_type arg)
  {
    msg_.active_command_source_name = std::move(arg);
    return Init_RobotReport_active_command_fresh(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_active_command_source
{
public:
  explicit Init_RobotReport_active_command_source(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_active_command_source_name active_command_source(::core::msg::RobotReport::_active_command_source_type arg)
  {
    msg_.active_command_source = std::move(arg);
    return Init_RobotReport_active_command_source_name(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_custom_drive_id
{
public:
  explicit Init_RobotReport_custom_drive_id(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_active_command_source custom_drive_id(::core::msg::RobotReport::_custom_drive_id_type arg)
  {
    msg_.custom_drive_id = std::move(arg);
    return Init_RobotReport_active_command_source(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_robot_initialized
{
public:
  explicit Init_RobotReport_robot_initialized(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_custom_drive_id robot_initialized(::core::msg::RobotReport::_robot_initialized_type arg)
  {
    msg_.robot_initialized = std::move(arg);
    return Init_RobotReport_custom_drive_id(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_robot_state_name
{
public:
  explicit Init_RobotReport_robot_state_name(::core::msg::RobotReport & msg)
  : msg_(msg)
  {}
  Init_RobotReport_robot_initialized robot_state_name(::core::msg::RobotReport::_robot_state_name_type arg)
  {
    msg_.robot_state_name = std::move(arg);
    return Init_RobotReport_robot_initialized(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

class Init_RobotReport_robot_state
{
public:
  Init_RobotReport_robot_state()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RobotReport_robot_state_name robot_state(::core::msg::RobotReport::_robot_state_type arg)
  {
    msg_.robot_state = std::move(arg);
    return Init_RobotReport_robot_state_name(msg_);
  }

private:
  ::core::msg::RobotReport msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::core::msg::RobotReport>()
{
  return core::msg::builder::Init_RobotReport_robot_state();
}

}  // namespace core

#endif  // CORE__MSG__DETAIL__ROBOT_REPORT__BUILDER_HPP_
