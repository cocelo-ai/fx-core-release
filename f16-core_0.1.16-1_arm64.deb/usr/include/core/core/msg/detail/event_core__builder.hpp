// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from core:msg/EventCore.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__EVENT_CORE__BUILDER_HPP_
#define CORE__MSG__DETAIL__EVENT_CORE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "core/msg/detail/event_core__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace core
{

namespace msg
{

namespace builder
{

class Init_EventCore_custom_drive_toggle
{
public:
  explicit Init_EventCore_custom_drive_toggle(::core::msg::EventCore & msg)
  : msg_(msg)
  {}
  ::core::msg::EventCore custom_drive_toggle(::core::msg::EventCore::_custom_drive_toggle_type arg)
  {
    msg_.custom_drive_toggle = std::move(arg);
    return std::move(msg_);
  }

private:
  ::core::msg::EventCore msg_;
};

class Init_EventCore_rough_drive_toggle
{
public:
  explicit Init_EventCore_rough_drive_toggle(::core::msg::EventCore & msg)
  : msg_(msg)
  {}
  Init_EventCore_custom_drive_toggle rough_drive_toggle(::core::msg::EventCore::_rough_drive_toggle_type arg)
  {
    msg_.rough_drive_toggle = std::move(arg);
    return Init_EventCore_custom_drive_toggle(msg_);
  }

private:
  ::core::msg::EventCore msg_;
};

class Init_EventCore_sleep
{
public:
  explicit Init_EventCore_sleep(::core::msg::EventCore & msg)
  : msg_(msg)
  {}
  Init_EventCore_rough_drive_toggle sleep(::core::msg::EventCore::_sleep_type arg)
  {
    msg_.sleep = std::move(arg);
    return Init_EventCore_rough_drive_toggle(msg_);
  }

private:
  ::core::msg::EventCore msg_;
};

class Init_EventCore_wake
{
public:
  explicit Init_EventCore_wake(::core::msg::EventCore & msg)
  : msg_(msg)
  {}
  Init_EventCore_sleep wake(::core::msg::EventCore::_wake_type arg)
  {
    msg_.wake = std::move(arg);
    return Init_EventCore_sleep(msg_);
  }

private:
  ::core::msg::EventCore msg_;
};

class Init_EventCore_estop
{
public:
  Init_EventCore_estop()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EventCore_wake estop(::core::msg::EventCore::_estop_type arg)
  {
    msg_.estop = std::move(arg);
    return Init_EventCore_wake(msg_);
  }

private:
  ::core::msg::EventCore msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::core::msg::EventCore>()
{
  return core::msg::builder::Init_EventCore_estop();
}

}  // namespace core

#endif  // CORE__MSG__DETAIL__EVENT_CORE__BUILDER_HPP_
