// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from core:msg/CommandFilter.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "core/msg/detail/command_filter__rosidl_typesupport_introspection_c.h"
#include "core/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "core/msg/detail/command_filter__functions.h"
#include "core/msg/detail/command_filter__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void core__msg__CommandFilter__rosidl_typesupport_introspection_c__CommandFilter_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  core__msg__CommandFilter__init(message_memory);
}

void core__msg__CommandFilter__rosidl_typesupport_introspection_c__CommandFilter_fini_function(void * message_memory)
{
  core__msg__CommandFilter__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember core__msg__CommandFilter__rosidl_typesupport_introspection_c__CommandFilter_message_member_array[4] = {
  {
    "allow_linear_vel_forward_x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__CommandFilter, allow_linear_vel_forward_x),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "allow_linear_vel_backward_x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__CommandFilter, allow_linear_vel_backward_x),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "allow_linear_vel_forward_y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__CommandFilter, allow_linear_vel_forward_y),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "allow_linear_vel_backward_y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(core__msg__CommandFilter, allow_linear_vel_backward_y),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers core__msg__CommandFilter__rosidl_typesupport_introspection_c__CommandFilter_message_members = {
  "core__msg",  // message namespace
  "CommandFilter",  // message name
  4,  // number of fields
  sizeof(core__msg__CommandFilter),
  core__msg__CommandFilter__rosidl_typesupport_introspection_c__CommandFilter_message_member_array,  // message members
  core__msg__CommandFilter__rosidl_typesupport_introspection_c__CommandFilter_init_function,  // function to initialize message memory (memory has to be allocated)
  core__msg__CommandFilter__rosidl_typesupport_introspection_c__CommandFilter_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t core__msg__CommandFilter__rosidl_typesupport_introspection_c__CommandFilter_message_type_support_handle = {
  0,
  &core__msg__CommandFilter__rosidl_typesupport_introspection_c__CommandFilter_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_core
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, core, msg, CommandFilter)() {
  if (!core__msg__CommandFilter__rosidl_typesupport_introspection_c__CommandFilter_message_type_support_handle.typesupport_identifier) {
    core__msg__CommandFilter__rosidl_typesupport_introspection_c__CommandFilter_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &core__msg__CommandFilter__rosidl_typesupport_introspection_c__CommandFilter_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
