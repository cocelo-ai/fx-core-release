// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from core:msg/CommandCore.idl
// generated code does not contain a copyright notice
#include "core/msg/detail/command_core__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `event`
#include "core/msg/detail/event_core__functions.h"

bool
core__msg__CommandCore__init(core__msg__CommandCore * msg)
{
  if (!msg) {
    return false;
  }
  // motion_command
  // event
  if (!core__msg__EventCore__init(&msg->event)) {
    core__msg__CommandCore__fini(msg);
    return false;
  }
  // custom_drive_id
  return true;
}

void
core__msg__CommandCore__fini(core__msg__CommandCore * msg)
{
  if (!msg) {
    return;
  }
  // motion_command
  // event
  core__msg__EventCore__fini(&msg->event);
  // custom_drive_id
}

bool
core__msg__CommandCore__are_equal(const core__msg__CommandCore * lhs, const core__msg__CommandCore * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // motion_command
  for (size_t i = 0; i < 13; ++i) {
    if (lhs->motion_command[i] != rhs->motion_command[i]) {
      return false;
    }
  }
  // event
  if (!core__msg__EventCore__are_equal(
      &(lhs->event), &(rhs->event)))
  {
    return false;
  }
  // custom_drive_id
  if (lhs->custom_drive_id != rhs->custom_drive_id) {
    return false;
  }
  return true;
}

bool
core__msg__CommandCore__copy(
  const core__msg__CommandCore * input,
  core__msg__CommandCore * output)
{
  if (!input || !output) {
    return false;
  }
  // motion_command
  for (size_t i = 0; i < 13; ++i) {
    output->motion_command[i] = input->motion_command[i];
  }
  // event
  if (!core__msg__EventCore__copy(
      &(input->event), &(output->event)))
  {
    return false;
  }
  // custom_drive_id
  output->custom_drive_id = input->custom_drive_id;
  return true;
}

core__msg__CommandCore *
core__msg__CommandCore__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__msg__CommandCore * msg = (core__msg__CommandCore *)allocator.allocate(sizeof(core__msg__CommandCore), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(core__msg__CommandCore));
  bool success = core__msg__CommandCore__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
core__msg__CommandCore__destroy(core__msg__CommandCore * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    core__msg__CommandCore__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
core__msg__CommandCore__Sequence__init(core__msg__CommandCore__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__msg__CommandCore * data = NULL;

  if (size) {
    data = (core__msg__CommandCore *)allocator.zero_allocate(size, sizeof(core__msg__CommandCore), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = core__msg__CommandCore__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        core__msg__CommandCore__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
core__msg__CommandCore__Sequence__fini(core__msg__CommandCore__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      core__msg__CommandCore__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

core__msg__CommandCore__Sequence *
core__msg__CommandCore__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__msg__CommandCore__Sequence * array = (core__msg__CommandCore__Sequence *)allocator.allocate(sizeof(core__msg__CommandCore__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = core__msg__CommandCore__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
core__msg__CommandCore__Sequence__destroy(core__msg__CommandCore__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    core__msg__CommandCore__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
core__msg__CommandCore__Sequence__are_equal(const core__msg__CommandCore__Sequence * lhs, const core__msg__CommandCore__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!core__msg__CommandCore__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
core__msg__CommandCore__Sequence__copy(
  const core__msg__CommandCore__Sequence * input,
  core__msg__CommandCore__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(core__msg__CommandCore);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    core__msg__CommandCore * data =
      (core__msg__CommandCore *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!core__msg__CommandCore__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          core__msg__CommandCore__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!core__msg__CommandCore__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
