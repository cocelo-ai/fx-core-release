// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from core:msg/ImuSafetyRule.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__IMU_SAFETY_RULE__TRAITS_HPP_
#define CORE__MSG__DETAIL__IMU_SAFETY_RULE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "core/msg/detail/imu_safety_rule__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace core
{

namespace msg
{

inline void to_flow_style_yaml(
  const ImuSafetyRule & msg,
  std::ostream & out)
{
  out << "{";
  // member: imu_order
  {
    out << "imu_order: ";
    rosidl_generator_traits::value_to_yaml(msg.imu_order, out);
    out << ", ";
  }

  // member: use_proj_grav_z_safety
  {
    out << "use_proj_grav_z_safety: ";
    rosidl_generator_traits::value_to_yaml(msg.use_proj_grav_z_safety, out);
    out << ", ";
  }

  // member: max_proj_grav_z
  {
    out << "max_proj_grav_z: ";
    rosidl_generator_traits::value_to_yaml(msg.max_proj_grav_z, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ImuSafetyRule & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: imu_order
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "imu_order: ";
    rosidl_generator_traits::value_to_yaml(msg.imu_order, out);
    out << "\n";
  }

  // member: use_proj_grav_z_safety
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "use_proj_grav_z_safety: ";
    rosidl_generator_traits::value_to_yaml(msg.use_proj_grav_z_safety, out);
    out << "\n";
  }

  // member: max_proj_grav_z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "max_proj_grav_z: ";
    rosidl_generator_traits::value_to_yaml(msg.max_proj_grav_z, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ImuSafetyRule & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace core

namespace rosidl_generator_traits
{

[[deprecated("use core::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const core::msg::ImuSafetyRule & msg,
  std::ostream & out, size_t indentation = 0)
{
  core::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use core::msg::to_yaml() instead")]]
inline std::string to_yaml(const core::msg::ImuSafetyRule & msg)
{
  return core::msg::to_yaml(msg);
}

template<>
inline const char * data_type<core::msg::ImuSafetyRule>()
{
  return "core::msg::ImuSafetyRule";
}

template<>
inline const char * name<core::msg::ImuSafetyRule>()
{
  return "core/msg/ImuSafetyRule";
}

template<>
struct has_fixed_size<core::msg::ImuSafetyRule>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<core::msg::ImuSafetyRule>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<core::msg::ImuSafetyRule>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CORE__MSG__DETAIL__IMU_SAFETY_RULE__TRAITS_HPP_
