// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from core:msg/DataCollectionMode.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__DATA_COLLECTION_MODE__TRAITS_HPP_
#define CORE__MSG__DETAIL__DATA_COLLECTION_MODE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "core/msg/detail/data_collection_mode__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace core
{

namespace msg
{

inline void to_flow_style_yaml(
  const DataCollectionMode & msg,
  std::ostream & out)
{
  out << "{";
  // member: enabled
  {
    out << "enabled: ";
    rosidl_generator_traits::value_to_yaml(msg.enabled, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DataCollectionMode & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: enabled
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "enabled: ";
    rosidl_generator_traits::value_to_yaml(msg.enabled, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DataCollectionMode & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace core

namespace rosidl_generator_traits
{

[[deprecated("use core::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const core::msg::DataCollectionMode & msg,
  std::ostream & out, size_t indentation = 0)
{
  core::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use core::msg::to_yaml() instead")]]
inline std::string to_yaml(const core::msg::DataCollectionMode & msg)
{
  return core::msg::to_yaml(msg);
}

template<>
inline const char * data_type<core::msg::DataCollectionMode>()
{
  return "core::msg::DataCollectionMode";
}

template<>
inline const char * name<core::msg::DataCollectionMode>()
{
  return "core/msg/DataCollectionMode";
}

template<>
struct has_fixed_size<core::msg::DataCollectionMode>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<core::msg::DataCollectionMode>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<core::msg::DataCollectionMode>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CORE__MSG__DETAIL__DATA_COLLECTION_MODE__TRAITS_HPP_
