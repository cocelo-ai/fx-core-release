// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from core:msg/CommandFilter.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__DETAIL__COMMAND_FILTER__TRAITS_HPP_
#define CORE__MSG__DETAIL__COMMAND_FILTER__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "core/msg/detail/command_filter__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace core
{

namespace msg
{

inline void to_flow_style_yaml(
  const CommandFilter & msg,
  std::ostream & out)
{
  out << "{";
  // member: allow_linear_vel_forward_x
  {
    out << "allow_linear_vel_forward_x: ";
    rosidl_generator_traits::value_to_yaml(msg.allow_linear_vel_forward_x, out);
    out << ", ";
  }

  // member: allow_linear_vel_backward_x
  {
    out << "allow_linear_vel_backward_x: ";
    rosidl_generator_traits::value_to_yaml(msg.allow_linear_vel_backward_x, out);
    out << ", ";
  }

  // member: allow_linear_vel_forward_y
  {
    out << "allow_linear_vel_forward_y: ";
    rosidl_generator_traits::value_to_yaml(msg.allow_linear_vel_forward_y, out);
    out << ", ";
  }

  // member: allow_linear_vel_backward_y
  {
    out << "allow_linear_vel_backward_y: ";
    rosidl_generator_traits::value_to_yaml(msg.allow_linear_vel_backward_y, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const CommandFilter & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: allow_linear_vel_forward_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "allow_linear_vel_forward_x: ";
    rosidl_generator_traits::value_to_yaml(msg.allow_linear_vel_forward_x, out);
    out << "\n";
  }

  // member: allow_linear_vel_backward_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "allow_linear_vel_backward_x: ";
    rosidl_generator_traits::value_to_yaml(msg.allow_linear_vel_backward_x, out);
    out << "\n";
  }

  // member: allow_linear_vel_forward_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "allow_linear_vel_forward_y: ";
    rosidl_generator_traits::value_to_yaml(msg.allow_linear_vel_forward_y, out);
    out << "\n";
  }

  // member: allow_linear_vel_backward_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "allow_linear_vel_backward_y: ";
    rosidl_generator_traits::value_to_yaml(msg.allow_linear_vel_backward_y, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const CommandFilter & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace core

namespace rosidl_generator_traits
{

[[deprecated("use core::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const core::msg::CommandFilter & msg,
  std::ostream & out, size_t indentation = 0)
{
  core::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use core::msg::to_yaml() instead")]]
inline std::string to_yaml(const core::msg::CommandFilter & msg)
{
  return core::msg::to_yaml(msg);
}

template<>
inline const char * data_type<core::msg::CommandFilter>()
{
  return "core::msg::CommandFilter";
}

template<>
inline const char * name<core::msg::CommandFilter>()
{
  return "core/msg/CommandFilter";
}

template<>
struct has_fixed_size<core::msg::CommandFilter>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<core::msg::CommandFilter>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<core::msg::CommandFilter>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CORE__MSG__DETAIL__COMMAND_FILTER__TRAITS_HPP_
