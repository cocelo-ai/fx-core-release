// generated from rosidl_generator_c/resource/idl.h.em
// with input from core:msg/RobotReport.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__ROBOT_REPORT_H_
#define CORE__MSG__ROBOT_REPORT_H_

#include "core/msg/detail/robot_report__struct.h"
#include "core/msg/detail/robot_report__functions.h"
#include "core/msg/detail/robot_report__type_support.h"

#endif  // CORE__MSG__ROBOT_REPORT_H_
