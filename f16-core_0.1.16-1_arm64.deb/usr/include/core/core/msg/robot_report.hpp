// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CORE__MSG__ROBOT_REPORT_HPP_
#define CORE__MSG__ROBOT_REPORT_HPP_

#include "core/msg/detail/robot_report__struct.hpp"
#include "core/msg/detail/robot_report__builder.hpp"
#include "core/msg/detail/robot_report__traits.hpp"
#include "core/msg/detail/robot_report__type_support.hpp"

#endif  // CORE__MSG__ROBOT_REPORT_HPP_
