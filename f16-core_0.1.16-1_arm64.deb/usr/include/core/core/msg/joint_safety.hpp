// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CORE__MSG__JOINT_SAFETY_HPP_
#define CORE__MSG__JOINT_SAFETY_HPP_

#include "core/msg/detail/joint_safety__struct.hpp"
#include "core/msg/detail/joint_safety__builder.hpp"
#include "core/msg/detail/joint_safety__traits.hpp"
#include "core/msg/detail/joint_safety__type_support.hpp"

#endif  // CORE__MSG__JOINT_SAFETY_HPP_
