// generated from rosidl_generator_c/resource/idl.h.em
// with input from core:msg/JointSafety.idl
// generated code does not contain a copyright notice

#ifndef CORE__MSG__JOINT_SAFETY_H_
#define CORE__MSG__JOINT_SAFETY_H_

#include "core/msg/detail/joint_safety__struct.h"
#include "core/msg/detail/joint_safety__functions.h"
#include "core/msg/detail/joint_safety__type_support.h"

#endif  // CORE__MSG__JOINT_SAFETY_H_
