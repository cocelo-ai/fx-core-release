// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CORE__MSG__IMU_SAFETY_RULE_HPP_
#define CORE__MSG__IMU_SAFETY_RULE_HPP_

#include "core/msg/detail/imu_safety_rule__struct.hpp"
#include "core/msg/detail/imu_safety_rule__builder.hpp"
#include "core/msg/detail/imu_safety_rule__traits.hpp"
#include "core/msg/detail/imu_safety_rule__type_support.hpp"

#endif  // CORE__MSG__IMU_SAFETY_RULE_HPP_
