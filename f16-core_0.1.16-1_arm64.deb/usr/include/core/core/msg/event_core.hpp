// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CORE__MSG__EVENT_CORE_HPP_
#define CORE__MSG__EVENT_CORE_HPP_

#include "core/msg/detail/event_core__struct.hpp"
#include "core/msg/detail/event_core__builder.hpp"
#include "core/msg/detail/event_core__traits.hpp"
#include "core/msg/detail/event_core__type_support.hpp"

#endif  // CORE__MSG__EVENT_CORE_HPP_
