// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from core:srv/DynamicParam.idl
// generated code does not contain a copyright notice

#ifndef CORE__SRV__DETAIL__DYNAMIC_PARAM__BUILDER_HPP_
#define CORE__SRV__DETAIL__DYNAMIC_PARAM__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "core/srv/detail/dynamic_param__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace core
{

namespace srv
{

namespace builder
{

class Init_DynamicParam_Request_safety_imu_rules
{
public:
  explicit Init_DynamicParam_Request_safety_imu_rules(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  ::core::srv::DynamicParam_Request safety_imu_rules(::core::srv::DynamicParam_Request::_safety_imu_rules_type arg)
  {
    msg_.safety_imu_rules = std::move(arg);
    return std::move(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_safety_motor_rules
{
public:
  explicit Init_DynamicParam_Request_safety_motor_rules(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_safety_imu_rules safety_motor_rules(::core::srv::DynamicParam_Request::_safety_motor_rules_type arg)
  {
    msg_.safety_motor_rules = std::move(arg);
    return Init_DynamicParam_Request_safety_imu_rules(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_wma_weights
{
public:
  explicit Init_DynamicParam_Request_wma_weights(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_safety_motor_rules wma_weights(::core::srv::DynamicParam_Request::_wma_weights_type arg)
  {
    msg_.wma_weights = std::move(arg);
    return Init_DynamicParam_Request_safety_motor_rules(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_battery_temperature_threshold
{
public:
  explicit Init_DynamicParam_Request_battery_temperature_threshold(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_wma_weights battery_temperature_threshold(::core::srv::DynamicParam_Request::_battery_temperature_threshold_type arg)
  {
    msg_.battery_temperature_threshold = std::move(arg);
    return Init_DynamicParam_Request_wma_weights(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_motor_temperature_threshold
{
public:
  explicit Init_DynamicParam_Request_motor_temperature_threshold(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_battery_temperature_threshold motor_temperature_threshold(::core::srv::DynamicParam_Request::_motor_temperature_threshold_type arg)
  {
    msg_.motor_temperature_threshold = std::move(arg);
    return Init_DynamicParam_Request_battery_temperature_threshold(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_battery_low_soc_threshold
{
public:
  explicit Init_DynamicParam_Request_battery_low_soc_threshold(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_motor_temperature_threshold battery_low_soc_threshold(::core::srv::DynamicParam_Request::_battery_low_soc_threshold_type arg)
  {
    msg_.battery_low_soc_threshold = std::move(arg);
    return Init_DynamicParam_Request_motor_temperature_threshold(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_command_iface_max_motion_command
{
public:
  explicit Init_DynamicParam_Request_command_iface_max_motion_command(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_battery_low_soc_threshold command_iface_max_motion_command(::core::srv::DynamicParam_Request::_command_iface_max_motion_command_type arg)
  {
    msg_.command_iface_max_motion_command = std::move(arg);
    return Init_DynamicParam_Request_battery_low_soc_threshold(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_command_iface_min_motion_command
{
public:
  explicit Init_DynamicParam_Request_command_iface_min_motion_command(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_command_iface_max_motion_command command_iface_min_motion_command(::core::srv::DynamicParam_Request::_command_iface_min_motion_command_type arg)
  {
    msg_.command_iface_min_motion_command = std::move(arg);
    return Init_DynamicParam_Request_command_iface_max_motion_command(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_motion_command_index_orientation_pitch
{
public:
  explicit Init_DynamicParam_Request_motion_command_index_orientation_pitch(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_command_iface_min_motion_command motion_command_index_orientation_pitch(::core::srv::DynamicParam_Request::_motion_command_index_orientation_pitch_type arg)
  {
    msg_.motion_command_index_orientation_pitch = std::move(arg);
    return Init_DynamicParam_Request_command_iface_min_motion_command(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_motion_command_index_orientation_roll
{
public:
  explicit Init_DynamicParam_Request_motion_command_index_orientation_roll(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_motion_command_index_orientation_pitch motion_command_index_orientation_roll(::core::srv::DynamicParam_Request::_motion_command_index_orientation_roll_type arg)
  {
    msg_.motion_command_index_orientation_roll = std::move(arg);
    return Init_DynamicParam_Request_motion_command_index_orientation_pitch(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_motion_command_index_position_z
{
public:
  explicit Init_DynamicParam_Request_motion_command_index_position_z(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_motion_command_index_orientation_roll motion_command_index_position_z(::core::srv::DynamicParam_Request::_motion_command_index_position_z_type arg)
  {
    msg_.motion_command_index_position_z = std::move(arg);
    return Init_DynamicParam_Request_motion_command_index_orientation_roll(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_motion_command_index_angular_vel_z
{
public:
  explicit Init_DynamicParam_Request_motion_command_index_angular_vel_z(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_motion_command_index_position_z motion_command_index_angular_vel_z(::core::srv::DynamicParam_Request::_motion_command_index_angular_vel_z_type arg)
  {
    msg_.motion_command_index_angular_vel_z = std::move(arg);
    return Init_DynamicParam_Request_motion_command_index_position_z(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_motion_command_index_linear_vel_y
{
public:
  explicit Init_DynamicParam_Request_motion_command_index_linear_vel_y(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_motion_command_index_angular_vel_z motion_command_index_linear_vel_y(::core::srv::DynamicParam_Request::_motion_command_index_linear_vel_y_type arg)
  {
    msg_.motion_command_index_linear_vel_y = std::move(arg);
    return Init_DynamicParam_Request_motion_command_index_angular_vel_z(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_motion_command_index_linear_vel_x
{
public:
  explicit Init_DynamicParam_Request_motion_command_index_linear_vel_x(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_motion_command_index_linear_vel_y motion_command_index_linear_vel_x(::core::srv::DynamicParam_Request::_motion_command_index_linear_vel_x_type arg)
  {
    msg_.motion_command_index_linear_vel_x = std::move(arg);
    return Init_DynamicParam_Request_motion_command_index_linear_vel_y(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_use_command_filter
{
public:
  explicit Init_DynamicParam_Request_use_command_filter(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_motion_command_index_linear_vel_x use_command_filter(::core::srv::DynamicParam_Request::_use_command_filter_type arg)
  {
    msg_.use_command_filter = std::move(arg);
    return Init_DynamicParam_Request_motion_command_index_linear_vel_x(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_cmd_packet_timeout_sec
{
public:
  explicit Init_DynamicParam_Request_cmd_packet_timeout_sec(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_use_command_filter cmd_packet_timeout_sec(::core::srv::DynamicParam_Request::_cmd_packet_timeout_sec_type arg)
  {
    msg_.cmd_packet_timeout_sec = std::move(arg);
    return Init_DynamicParam_Request_use_command_filter(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_cmd_priority_hold_sec
{
public:
  explicit Init_DynamicParam_Request_cmd_priority_hold_sec(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_cmd_packet_timeout_sec cmd_priority_hold_sec(::core::srv::DynamicParam_Request::_cmd_priority_hold_sec_type arg)
  {
    msg_.cmd_priority_hold_sec = std::move(arg);
    return Init_DynamicParam_Request_cmd_packet_timeout_sec(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_max_motion_command
{
public:
  explicit Init_DynamicParam_Request_joystick_max_motion_command(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_cmd_priority_hold_sec joystick_max_motion_command(::core::srv::DynamicParam_Request::_joystick_max_motion_command_type arg)
  {
    msg_.joystick_max_motion_command = std::move(arg);
    return Init_DynamicParam_Request_cmd_priority_hold_sec(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_min_motion_command
{
public:
  explicit Init_DynamicParam_Request_joystick_min_motion_command(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_max_motion_command joystick_min_motion_command(::core::srv::DynamicParam_Request::_joystick_min_motion_command_type arg)
  {
    msg_.joystick_min_motion_command = std::move(arg);
    return Init_DynamicParam_Request_joystick_max_motion_command(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_deadzone
{
public:
  explicit Init_DynamicParam_Request_joystick_deadzone(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_min_motion_command joystick_deadzone(::core::srv::DynamicParam_Request::_joystick_deadzone_type arg)
  {
    msg_.joystick_deadzone = std::move(arg);
    return Init_DynamicParam_Request_joystick_min_motion_command(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_smoothness
{
public:
  explicit Init_DynamicParam_Request_joystick_smoothness(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_deadzone joystick_smoothness(::core::srv::DynamicParam_Request::_joystick_smoothness_type arg)
  {
    msg_.joystick_smoothness = std::move(arg);
    return Init_DynamicParam_Request_joystick_deadzone(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_dpad_step_y
{
public:
  explicit Init_DynamicParam_Request_joystick_dpad_step_y(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_smoothness joystick_dpad_step_y(::core::srv::DynamicParam_Request::_joystick_dpad_step_y_type arg)
  {
    msg_.joystick_dpad_step_y = std::move(arg);
    return Init_DynamicParam_Request_joystick_smoothness(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_dpad_step_x
{
public:
  explicit Init_DynamicParam_Request_joystick_dpad_step_x(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_dpad_step_y joystick_dpad_step_x(::core::srv::DynamicParam_Request::_joystick_dpad_step_x_type arg)
  {
    msg_.joystick_dpad_step_x = std::move(arg);
    return Init_DynamicParam_Request_joystick_dpad_step_y(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_rb_dpad_y
{
public:
  explicit Init_DynamicParam_Request_joystick_rb_dpad_y(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_dpad_step_x joystick_rb_dpad_y(::core::srv::DynamicParam_Request::_joystick_rb_dpad_y_type arg)
  {
    msg_.joystick_rb_dpad_y = std::move(arg);
    return Init_DynamicParam_Request_joystick_dpad_step_x(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_rb_dpad_x
{
public:
  explicit Init_DynamicParam_Request_joystick_rb_dpad_x(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_rb_dpad_y joystick_rb_dpad_x(::core::srv::DynamicParam_Request::_joystick_rb_dpad_x_type arg)
  {
    msg_.joystick_rb_dpad_x = std::move(arg);
    return Init_DynamicParam_Request_joystick_rb_dpad_y(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_rb_right_y
{
public:
  explicit Init_DynamicParam_Request_joystick_rb_right_y(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_rb_dpad_x joystick_rb_right_y(::core::srv::DynamicParam_Request::_joystick_rb_right_y_type arg)
  {
    msg_.joystick_rb_right_y = std::move(arg);
    return Init_DynamicParam_Request_joystick_rb_dpad_x(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_rb_right_x
{
public:
  explicit Init_DynamicParam_Request_joystick_rb_right_x(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_rb_right_y joystick_rb_right_x(::core::srv::DynamicParam_Request::_joystick_rb_right_x_type arg)
  {
    msg_.joystick_rb_right_x = std::move(arg);
    return Init_DynamicParam_Request_joystick_rb_right_y(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_rb_left_y
{
public:
  explicit Init_DynamicParam_Request_joystick_rb_left_y(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_rb_right_x joystick_rb_left_y(::core::srv::DynamicParam_Request::_joystick_rb_left_y_type arg)
  {
    msg_.joystick_rb_left_y = std::move(arg);
    return Init_DynamicParam_Request_joystick_rb_right_x(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_rb_left_x
{
public:
  explicit Init_DynamicParam_Request_joystick_rb_left_x(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_rb_left_y joystick_rb_left_x(::core::srv::DynamicParam_Request::_joystick_rb_left_x_type arg)
  {
    msg_.joystick_rb_left_x = std::move(arg);
    return Init_DynamicParam_Request_joystick_rb_left_y(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_left_btn
{
public:
  explicit Init_DynamicParam_Request_joystick_left_btn(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_rb_left_x joystick_left_btn(::core::srv::DynamicParam_Request::_joystick_left_btn_type arg)
  {
    msg_.joystick_left_btn = std::move(arg);
    return Init_DynamicParam_Request_joystick_rb_left_x(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_dpad_y
{
public:
  explicit Init_DynamicParam_Request_joystick_dpad_y(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_left_btn joystick_dpad_y(::core::srv::DynamicParam_Request::_joystick_dpad_y_type arg)
  {
    msg_.joystick_dpad_y = std::move(arg);
    return Init_DynamicParam_Request_joystick_left_btn(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_dpad_x
{
public:
  explicit Init_DynamicParam_Request_joystick_dpad_x(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_dpad_y joystick_dpad_x(::core::srv::DynamicParam_Request::_joystick_dpad_x_type arg)
  {
    msg_.joystick_dpad_x = std::move(arg);
    return Init_DynamicParam_Request_joystick_dpad_y(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_right_y
{
public:
  explicit Init_DynamicParam_Request_joystick_right_y(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_dpad_x joystick_right_y(::core::srv::DynamicParam_Request::_joystick_right_y_type arg)
  {
    msg_.joystick_right_y = std::move(arg);
    return Init_DynamicParam_Request_joystick_dpad_x(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_right_x
{
public:
  explicit Init_DynamicParam_Request_joystick_right_x(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_right_y joystick_right_x(::core::srv::DynamicParam_Request::_joystick_right_x_type arg)
  {
    msg_.joystick_right_x = std::move(arg);
    return Init_DynamicParam_Request_joystick_right_y(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_left_y
{
public:
  explicit Init_DynamicParam_Request_joystick_left_y(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_right_x joystick_left_y(::core::srv::DynamicParam_Request::_joystick_left_y_type arg)
  {
    msg_.joystick_left_y = std::move(arg);
    return Init_DynamicParam_Request_joystick_right_x(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_joystick_left_x
{
public:
  explicit Init_DynamicParam_Request_joystick_left_x(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_left_y joystick_left_x(::core::srv::DynamicParam_Request::_joystick_left_x_type arg)
  {
    msg_.joystick_left_x = std::move(arg);
    return Init_DynamicParam_Request_joystick_left_y(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_robot_max_torque_nm
{
public:
  explicit Init_DynamicParam_Request_robot_max_torque_nm(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_joystick_left_x robot_max_torque_nm(::core::srv::DynamicParam_Request::_robot_max_torque_nm_type arg)
  {
    msg_.robot_max_torque_nm = std::move(arg);
    return Init_DynamicParam_Request_joystick_left_x(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_robot_motor_kd
{
public:
  explicit Init_DynamicParam_Request_robot_motor_kd(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_robot_max_torque_nm robot_motor_kd(::core::srv::DynamicParam_Request::_robot_motor_kd_type arg)
  {
    msg_.robot_motor_kd = std::move(arg);
    return Init_DynamicParam_Request_robot_max_torque_nm(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_robot_motor_kp
{
public:
  explicit Init_DynamicParam_Request_robot_motor_kp(::core::srv::DynamicParam_Request & msg)
  : msg_(msg)
  {}
  Init_DynamicParam_Request_robot_motor_kd robot_motor_kp(::core::srv::DynamicParam_Request::_robot_motor_kp_type arg)
  {
    msg_.robot_motor_kp = std::move(arg);
    return Init_DynamicParam_Request_robot_motor_kd(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

class Init_DynamicParam_Request_robot_motor_ids
{
public:
  Init_DynamicParam_Request_robot_motor_ids()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DynamicParam_Request_robot_motor_kp robot_motor_ids(::core::srv::DynamicParam_Request::_robot_motor_ids_type arg)
  {
    msg_.robot_motor_ids = std::move(arg);
    return Init_DynamicParam_Request_robot_motor_kp(msg_);
  }

private:
  ::core::srv::DynamicParam_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::core::srv::DynamicParam_Request>()
{
  return core::srv::builder::Init_DynamicParam_Request_robot_motor_ids();
}

}  // namespace core


namespace core
{

namespace srv
{

namespace builder
{

class Init_DynamicParam_Response_reason
{
public:
  explicit Init_DynamicParam_Response_reason(::core::srv::DynamicParam_Response & msg)
  : msg_(msg)
  {}
  ::core::srv::DynamicParam_Response reason(::core::srv::DynamicParam_Response::_reason_type arg)
  {
    msg_.reason = std::move(arg);
    return std::move(msg_);
  }

private:
  ::core::srv::DynamicParam_Response msg_;
};

class Init_DynamicParam_Response_success
{
public:
  Init_DynamicParam_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DynamicParam_Response_reason success(::core::srv::DynamicParam_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_DynamicParam_Response_reason(msg_);
  }

private:
  ::core::srv::DynamicParam_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::core::srv::DynamicParam_Response>()
{
  return core::srv::builder::Init_DynamicParam_Response_success();
}

}  // namespace core

#endif  // CORE__SRV__DETAIL__DYNAMIC_PARAM__BUILDER_HPP_
