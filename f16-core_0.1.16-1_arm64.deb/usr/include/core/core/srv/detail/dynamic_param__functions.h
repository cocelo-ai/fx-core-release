// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from core:srv/DynamicParam.idl
// generated code does not contain a copyright notice

#ifndef CORE__SRV__DETAIL__DYNAMIC_PARAM__FUNCTIONS_H_
#define CORE__SRV__DETAIL__DYNAMIC_PARAM__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "core/msg/rosidl_generator_c__visibility_control.h"

#include "core/srv/detail/dynamic_param__struct.h"

/// Initialize srv/DynamicParam message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * core__srv__DynamicParam_Request
 * )) before or use
 * core__srv__DynamicParam_Request__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__srv__DynamicParam_Request__init(core__srv__DynamicParam_Request * msg);

/// Finalize srv/DynamicParam message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__srv__DynamicParam_Request__fini(core__srv__DynamicParam_Request * msg);

/// Create srv/DynamicParam message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * core__srv__DynamicParam_Request__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_core
core__srv__DynamicParam_Request *
core__srv__DynamicParam_Request__create();

/// Destroy srv/DynamicParam message.
/**
 * It calls
 * core__srv__DynamicParam_Request__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__srv__DynamicParam_Request__destroy(core__srv__DynamicParam_Request * msg);

/// Check for srv/DynamicParam message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__srv__DynamicParam_Request__are_equal(const core__srv__DynamicParam_Request * lhs, const core__srv__DynamicParam_Request * rhs);

/// Copy a srv/DynamicParam message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__srv__DynamicParam_Request__copy(
  const core__srv__DynamicParam_Request * input,
  core__srv__DynamicParam_Request * output);

/// Initialize array of srv/DynamicParam messages.
/**
 * It allocates the memory for the number of elements and calls
 * core__srv__DynamicParam_Request__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__srv__DynamicParam_Request__Sequence__init(core__srv__DynamicParam_Request__Sequence * array, size_t size);

/// Finalize array of srv/DynamicParam messages.
/**
 * It calls
 * core__srv__DynamicParam_Request__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__srv__DynamicParam_Request__Sequence__fini(core__srv__DynamicParam_Request__Sequence * array);

/// Create array of srv/DynamicParam messages.
/**
 * It allocates the memory for the array and calls
 * core__srv__DynamicParam_Request__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_core
core__srv__DynamicParam_Request__Sequence *
core__srv__DynamicParam_Request__Sequence__create(size_t size);

/// Destroy array of srv/DynamicParam messages.
/**
 * It calls
 * core__srv__DynamicParam_Request__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__srv__DynamicParam_Request__Sequence__destroy(core__srv__DynamicParam_Request__Sequence * array);

/// Check for srv/DynamicParam message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__srv__DynamicParam_Request__Sequence__are_equal(const core__srv__DynamicParam_Request__Sequence * lhs, const core__srv__DynamicParam_Request__Sequence * rhs);

/// Copy an array of srv/DynamicParam messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__srv__DynamicParam_Request__Sequence__copy(
  const core__srv__DynamicParam_Request__Sequence * input,
  core__srv__DynamicParam_Request__Sequence * output);

/// Initialize srv/DynamicParam message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * core__srv__DynamicParam_Response
 * )) before or use
 * core__srv__DynamicParam_Response__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__srv__DynamicParam_Response__init(core__srv__DynamicParam_Response * msg);

/// Finalize srv/DynamicParam message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__srv__DynamicParam_Response__fini(core__srv__DynamicParam_Response * msg);

/// Create srv/DynamicParam message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * core__srv__DynamicParam_Response__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_core
core__srv__DynamicParam_Response *
core__srv__DynamicParam_Response__create();

/// Destroy srv/DynamicParam message.
/**
 * It calls
 * core__srv__DynamicParam_Response__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__srv__DynamicParam_Response__destroy(core__srv__DynamicParam_Response * msg);

/// Check for srv/DynamicParam message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__srv__DynamicParam_Response__are_equal(const core__srv__DynamicParam_Response * lhs, const core__srv__DynamicParam_Response * rhs);

/// Copy a srv/DynamicParam message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__srv__DynamicParam_Response__copy(
  const core__srv__DynamicParam_Response * input,
  core__srv__DynamicParam_Response * output);

/// Initialize array of srv/DynamicParam messages.
/**
 * It allocates the memory for the number of elements and calls
 * core__srv__DynamicParam_Response__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__srv__DynamicParam_Response__Sequence__init(core__srv__DynamicParam_Response__Sequence * array, size_t size);

/// Finalize array of srv/DynamicParam messages.
/**
 * It calls
 * core__srv__DynamicParam_Response__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__srv__DynamicParam_Response__Sequence__fini(core__srv__DynamicParam_Response__Sequence * array);

/// Create array of srv/DynamicParam messages.
/**
 * It allocates the memory for the array and calls
 * core__srv__DynamicParam_Response__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_core
core__srv__DynamicParam_Response__Sequence *
core__srv__DynamicParam_Response__Sequence__create(size_t size);

/// Destroy array of srv/DynamicParam messages.
/**
 * It calls
 * core__srv__DynamicParam_Response__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
void
core__srv__DynamicParam_Response__Sequence__destroy(core__srv__DynamicParam_Response__Sequence * array);

/// Check for srv/DynamicParam message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__srv__DynamicParam_Response__Sequence__are_equal(const core__srv__DynamicParam_Response__Sequence * lhs, const core__srv__DynamicParam_Response__Sequence * rhs);

/// Copy an array of srv/DynamicParam messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_core
bool
core__srv__DynamicParam_Response__Sequence__copy(
  const core__srv__DynamicParam_Response__Sequence * input,
  core__srv__DynamicParam_Response__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // CORE__SRV__DETAIL__DYNAMIC_PARAM__FUNCTIONS_H_
