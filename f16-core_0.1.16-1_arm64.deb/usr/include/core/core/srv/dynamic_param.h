// generated from rosidl_generator_c/resource/idl.h.em
// with input from core:srv/DynamicParam.idl
// generated code does not contain a copyright notice

#ifndef CORE__SRV__DYNAMIC_PARAM_H_
#define CORE__SRV__DYNAMIC_PARAM_H_

#include "core/srv/detail/dynamic_param__struct.h"
#include "core/srv/detail/dynamic_param__functions.h"
#include "core/srv/detail/dynamic_param__type_support.h"

#endif  // CORE__SRV__DYNAMIC_PARAM_H_
