# Copyright 2014 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

function(assert_file_exists filename error_message)
  if(NOT IS_ABSOLUTE "${filename}")
    set(filename "${CMAKE_CURRENT_LIST_DIR}/${filename}")
  endif()
  if(NOT EXISTS "${filename}")
    message(FATAL_ERROR "${error_message}")
  endif()
endfunction()
