# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(core_IDL_FILES "msg/CommandCore.idl;msg/CommandFilter.idl;msg/CommandUser.idl;msg/DataCollectionMode.idl;msg/EventCore.idl;msg/EventUser.idl;msg/ImuSafetyRule.idl;msg/JointSafety.idl;msg/MotorSafetyRule.idl;msg/RobotReport.idl;srv/DynamicParam.idl")
set(core_INTERFACE_FILES "msg/CommandCore.msg;msg/CommandFilter.msg;msg/CommandUser.msg;msg/DataCollectionMode.msg;msg/EventCore.msg;msg/EventUser.msg;msg/ImuSafetyRule.msg;msg/JointSafety.msg;msg/MotorSafetyRule.msg;msg/RobotReport.msg;srv/DynamicParam.srv;srv/DynamicParam_Request.msg;srv/DynamicParam_Response.msg")
