#!/usr/bin/env bash
set -Eeuo pipefail

# =============================================================================
# F8 CORE INSTALLED LAUNCHER — STEP MAP
# =============================================================================
# STEP 01. 런처 기본 정보
#   - 서비스명과 설치 경로를 고정하고, 이 파일이 설치본 런처임을 명확히 한다.
#
# STEP 02. 공통 로그 / 에러 처리
#   - 모든 로그 형식을 통일하고, 예상치 못한 shell 오류를 fatal 로그로 변환한다.
#
# STEP 03. 기본 설정 로드
#   - /etc/default/f8_core를 읽고, 누락된 값은 설치 레이아웃 기본값으로 채운다.
#
# STEP 04. ROS RMW / Fast DDS 선택
#   - 사용할 ROS 2 middleware 구현체를 결정하고, Fast DDS transport 기본값을 보정한다.
#
# STEP 05. Cyclone DDS config export / network state logging
#   - Cyclone DDS XML을 CYCLONEDDS_URI로 export하고 WAN/autonomous 상태를 로그로 남긴다.
#
# STEP 06. WAN Gateway Readiness Gate
#   - WAN 인터페이스의 default gateway가 ping에 응답할 때까지 대기한다.
#
# STEP 07. 런타임 환경 요약
#   - 버전, 설정 경로, ROS prefix, LD_LIBRARY_PATH 등 진단 정보를 로그로 남긴다.
#
# STEP 08. 필수 파일 / 디렉터리 검사 유틸
#   - 실행 전 필요한 파일, marker, 실행 바이너리를 공통 방식으로 검증한다.
#
# STEP 09. 설정 YAML / ONNX 모델 검사
#   - core 실행에 필요한 YAML 설정과 ONNX policy 파일 존재 여부를 확인한다.
#
# STEP 10. Embedded ROS 라이브러리 경로 구성
#   - 패키지에 포함된 ROS/runtime 라이브러리가 host ROS보다 먼저 로드되도록 한다.
#
# STEP 11. ROS 실행 환경 Export
#   - 본체 바이너리가 읽을 ROS, CORE, HOME 관련 환경변수를 export한다.
#
# STEP 12. Embedded ROS Runtime 검증
#   - rclcpp, rcl, rmw, typesupport, RMW 구현체 라이브러리와 ament marker를 검사한다.
#
# STEP 13. ldd 기반 공유 라이브러리 검사
#   - 실행 파일과 주요 .so 파일의 누락된 runtime dependency를 사전에 잡는다.
#
# STEP 14. Main Launch Flow
#   - 전체 준비/검증 단계를 순서대로 묶고, 마지막에 본체 바이너리로 exec 전환한다.
# =============================================================================


# =============================================================================
# STEP 01. 런처 기본 정보
# -----------------------------------------------------------------------------
# 설치된 f8_core 서비스만을 대상으로 하는 런처이다.
# 시스템 /opt/ros를 source하지 않고, 패키지 내부의 embedded ROS runtime을 기준으로 실행한다.
# =============================================================================

# -----------------------------------------------------------------------------
# 설치본 전용 런처
# -----------------------------------------------------------------------------
#
# 이 파일은 설치된 f8_core 서비스를 실행한다.
# - /usr/share/f8_core/ros 의 번들된 ROS 런타임을 사용한다.
# - /opt/ros 를 source 하지 않는다.
# - 설치된 설정/데이터/런타임 파일을 검사한 뒤 본체 바이너리를 exec 한다.

SERVICE_NAME="f8_core"
DEFAULT_FILE="/etc/default/f8_core"
BASHRC_FILE="/home/cocelo/.bashrc"
PACKAGE_VERSION_FILE="/usr/share/f8_core/VERSION"
BUILD_INFO_FILE="/usr/share/f8_core/BUILD_INFO"

# =============================================================================
# STEP 02. 공통 로그 / 에러 처리
# -----------------------------------------------------------------------------
# log(), fail(), on_error()는 런처 전역에서 사용하는 공통 유틸이다.
# systemd journal에서 원인 추적이 쉽도록 로그 prefix와 fatal 처리 방식을 통일한다.
# =============================================================================

# Print an installed-runtime log line.
log() {
  printf '[%s launch %s] %s\n' "${SERVICE_NAME}" "$(date '+%Y-%m-%d %H:%M:%S')" "$*"
}

# Exit the launcher with a fatal message.
fail() {
  log "ERROR: $*"
  exit 1
}

# Convert trapped shell errors into a consistent fatal message.
on_error() {
  local line="$1"
  local code="$2"
  trap - ERR
  fail "Command failed near line ${line} with exit code ${code}."
}

# =============================================================================
# STEP 02-1. LD_LIBRARY_PATH 조작 유틸
# -----------------------------------------------------------------------------
# 존재하는 라이브러리 디렉터리만 LD_LIBRARY_PATH 앞쪽에 추가한다.
# 앞에 추가해야 embedded/runtime 라이브러리가 host 라이브러리보다 먼저 검색된다.
# =============================================================================

# Prepend one library directory to LD_LIBRARY_PATH when it exists.
prepend_ld_library_path() {
  local dir="$1"
  [[ -d "${dir}" ]] || return 0
  export LD_LIBRARY_PATH="${dir}:${LD_LIBRARY_PATH:-}"
}

# =============================================================================
# STEP 03. 기본 설정 로드
# -----------------------------------------------------------------------------
# /etc/default/f8_core가 있으면 먼저 source하고,
# 설정되지 않은 값들은 설치본의 기본 경로와 기본 ROS 설정으로 채운다.
# =============================================================================

# Load packaged defaults, then pin the runtime asset directories used by this package.
source_defaults() {
  if [[ -f "${DEFAULT_FILE}" ]]; then
    # shellcheck source=/dev/null
    source "${DEFAULT_FILE}"
  fi

  # ${VAR:=default} 문법은 VAR가 비어 있거나 unset일 때만 기본값을 대입한다.
  # /etc/default에서 이미 지정한 값은 여기서 덮어쓰지 않는다.
  : "${ROS_VERSION:=2}"
  : "${ROS_DISTRO:=humble}"
  : "${RMW_IMPLEMENTATION:=rmw_fastrtps_cpp}"

  # Runtime asset directories are part of the installed package contract, not
  # operator-tunable service environment.
  CORE_CONFIG_ROOT="/etc/f8_core"
  CORE_CONFIG_DIR="${CORE_CONFIG_ROOT}/yaml"
  CORE_ONNX_DIR="${CORE_CONFIG_ROOT}/onnx"
  : "${CORE_DATA_DIR:=/usr/share/f8_core}"
  : "${CORE_BINARY:=/usr/lib/f8_core/f8_core_lib}"
  : "${CORE_ROS_PREFIX:=/usr/share/f8_core/ros}"
  : "${CORE_HOST_LIB_DIR:=/usr/lib/f8_core/runtime-deps}"
  : "${CORE_RUNTIME_HOME:=/var/lib/f8_core}"
  CORE_WAN_INTERFACE=""
  CORE_AUTONOMOUS_INTERFACE=""
  : "${CORE_CYCLONEDDS_CONFIG:=/run/f8_core/cyclonedds.xml}"
  : "${CORE_BPI_GATEWAY_PING_TIMEOUT_SEC:=1}"
  : "${CORE_BPI_GATEWAY_PING_INTERVAL_SEC:=1}"
  : "${FASTDDS_BUILTIN_TRANSPORTS:=}"

  if [[ -n "${ROS_DOMAIN_ID:-}" ]]; then
    # Domain IDs are application communication config; middleware.yaml is the only
    # source of truth and C++ exports ROS_DOMAIN_ID before rclcpp::init().
    log "WARNING: external_ros_domain_id=${ROS_DOMAIN_ID}; ignoring environment value because ${CORE_CONFIG_DIR}/middleware.yaml owns ros2.domain_id"
    unset ROS_DOMAIN_ID
  fi

  if [[ -n "${DDS_DOMAIN_ID:-}" ]]; then
    # Keep raw DDS domain selection with the rest of middleware.yaml to avoid drift
    # between systemd environment and application validation.
    log "WARNING: external_dds_domain_id=${DDS_DOMAIN_ID}; ignoring environment value because ${CORE_CONFIG_DIR}/middleware.yaml owns dds.domain_id"
    unset DDS_DOMAIN_ID
  fi

  # Keep root service runtime state identical for boot-start and manual start.
  HOME="${CORE_RUNTIME_HOME}"
  ROS_HOME="${CORE_RUNTIME_HOME}/.ros"
}

# =============================================================================
# STEP 04. ROS RMW / Fast DDS 선택
# -----------------------------------------------------------------------------
# ROS 2 middleware 구현체를 환경변수로 확정한다.
# 기본은 Fast DDS(rmw_fastrtps_cpp)이며, root 서비스 모드에서는 UDPv4 transport를 보정한다.
# =============================================================================

# Default installed ROS graph traffic to Fast DDS.
resolve_rmw_implementation() {
  export RMW_IMPLEMENTATION
  log "requested_rmw_implementation=${RMW_IMPLEMENTATION}"
}

# Apply the Fast DDS transport safeguard only when Fast DDS may be selected.
configure_fastdds_transport() {
  if [[ -n "${RMW_IMPLEMENTATION}" && "${RMW_IMPLEMENTATION}" != "rmw_fastrtps_cpp" ]]; then
    return 0
  fi

  if [[ -n "${FASTDDS_BUILTIN_TRANSPORTS:-}" ]]; then
    return 0
  fi

  if [[ "${EUID}" -eq 0 ]]; then
    # Root service mode defaults Fast DDS to UDPv4 transport.
    FASTDDS_BUILTIN_TRANSPORTS="UDPv4"
  fi
}

# =============================================================================
# STEP 05. Cyclone DDS config generation / network state logging
# -----------------------------------------------------------------------------
# Cyclone DDS는 WAN, autonomous, loopback을 명시한 XML을 사용한다.
# 런처는 /home/cocelo/.bashrc에서 role interface를 읽어 /run XML을 생성하고,
# link/address/route 상태를 수정하지 않는다.
# =============================================================================

# Read runtime role interfaces from the SBC setup output in /home/cocelo/.bashrc.
read_cocelo_network_interfaces_from_bashrc() {
  local output=""
  local wan_if=""
  local autonomous_if=""

  [[ -f "${BASHRC_FILE}" ]] || fail "missing runtime network source: ${BASHRC_FILE}"
  command -v bash >/dev/null 2>&1 || fail "bash command not found; cannot read ${BASHRC_FILE}"

  output="$(bash --noprofile --rcfile "${BASHRC_FILE}" -ic '
    printf "__CORE_WAN_INTERFACE__=%s\n" "${CORE_WAN_INTERFACE:-${COCELO_WAN_IF:-}}"
    printf "__CORE_AUTONOMOUS_INTERFACE__=%s\n" "${CORE_AUTONOMOUS_INTERFACE:-${COCELO_AUTONOMOUS_IF:-}}"
  ' 2>/dev/null || true)"

  wan_if="$(printf '%s\n' "${output}" | sed -n 's/^__CORE_WAN_INTERFACE__=//p' | tail -n 1)"
  autonomous_if="$(printf '%s\n' "${output}" | sed -n 's/^__CORE_AUTONOMOUS_INTERFACE__=//p' | tail -n 1)"

  CORE_WAN_INTERFACE="${wan_if}"
  CORE_AUTONOMOUS_INTERFACE="${autonomous_if}"
  log "network_interface_source=${BASHRC_FILE}"
}

# Validate one Linux interface name resolved from /home/cocelo/.bashrc.
validate_ifname_value() {
  local name="$1"
  local value="$2"

  [[ -n "${value}" ]] || fail "${name} is required from ${BASHRC_FILE}"
  [[ "${value}" != "lo" ]] || fail "${name} must not be lo"
  [[ "${value}" =~ ^[A-Za-z0-9_.:-]{1,15}$ ]] \
    || fail "${name} is invalid: ${value}"
}

# Validate the runtime network values without touching the network.
validate_network_defaults() {
  validate_ifname_value "CORE_WAN_INTERFACE" "${CORE_WAN_INTERFACE}"
  validate_ifname_value "CORE_AUTONOMOUS_INTERFACE" "${CORE_AUTONOMOUS_INTERFACE}"
  [[ "${CORE_WAN_INTERFACE}" != "${CORE_AUTONOMOUS_INTERFACE}" ]] \
    || fail "CORE_WAN_INTERFACE and CORE_AUTONOMOUS_INTERFACE must be different"

  # Timeout and retry interval are safety knobs, not readiness decisions. Bad
  # values fall back to the package default so a local edit cannot break boot.
  if ! [[ "${CORE_BPI_GATEWAY_PING_TIMEOUT_SEC}" =~ ^[1-9][0-9]*$ ]]; then
    log "WARNING: invalid_bpi_gateway_ping_timeout_sec=${CORE_BPI_GATEWAY_PING_TIMEOUT_SEC}; using 1"
    CORE_BPI_GATEWAY_PING_TIMEOUT_SEC=1
  fi

  if ! [[ "${CORE_BPI_GATEWAY_PING_INTERVAL_SEC}" =~ ^[1-9][0-9]*$ ]]; then
    log "WARNING: invalid_bpi_gateway_ping_interval_sec=${CORE_BPI_GATEWAY_PING_INTERVAL_SEC}; using 1"
    CORE_BPI_GATEWAY_PING_INTERVAL_SEC=1
  fi
}

# Write the Cyclone DDS XML from the runtime-resolved role interfaces.
write_runtime_cyclonedds_config() {
  local config_dir=""
  local tmp_file=""

  [[ -n "${CORE_CYCLONEDDS_CONFIG}" ]] || fail "CORE_CYCLONEDDS_CONFIG is required in ${DEFAULT_FILE}"
  config_dir="$(dirname "${CORE_CYCLONEDDS_CONFIG}")"
  mkdir -p "${config_dir}"
  tmp_file="${CORE_CYCLONEDDS_CONFIG}.tmp.$$"

  cat > "${tmp_file}" <<EOF_CYCLONEDDS
<?xml version="1.0" encoding="UTF-8" ?>
<CycloneDDS xmlns="https://cdds.io/config">
  <Domain Id="any">
    <General>
      <Interfaces>
        <NetworkInterface name="${CORE_WAN_INTERFACE}" multicast="true" presence_required="false" />
        <NetworkInterface name="${CORE_AUTONOMOUS_INTERFACE}" multicast="true" presence_required="false" />
        <NetworkInterface name="lo" multicast="true" />
      </Interfaces>
      <AllowMulticast>true</AllowMulticast>
      <RedundantNetworking>true</RedundantNetworking>
      <MulticastRecvNetworkInterfaceAddresses>all</MulticastRecvNetworkInterfaceAddresses>
      <EnableMulticastLoopback>true</EnableMulticastLoopback>
    </General>
  </Domain>
</CycloneDDS>
EOF_CYCLONEDDS

  chmod 0644 "${tmp_file}"
  mv -f "${tmp_file}" "${CORE_CYCLONEDDS_CONFIG}"
  log "wrote_runtime_cyclonedds_config=${CORE_CYCLONEDDS_CONFIG}"
}

# Export the runtime-generated Cyclone DDS XML for raw Cyclone DDS and any Cyclone RMW use.
configure_cyclonedds_environment() {
  write_runtime_cyclonedds_config

  [[ -f "${CORE_CYCLONEDDS_CONFIG}" ]] || fail "missing Cyclone DDS XML config: ${CORE_CYCLONEDDS_CONFIG}"
  [[ -s "${CORE_CYCLONEDDS_CONFIG}" ]] || fail "empty Cyclone DDS XML config: ${CORE_CYCLONEDDS_CONFIG}"

  if [[ -n "${CYCLONEDDS_URI:-}" && "${CYCLONEDDS_URI}" != "file://${CORE_CYCLONEDDS_CONFIG}" ]]; then
    log "WARNING: external_cyclonedds_uri=${CYCLONEDDS_URI}; overriding with file://${CORE_CYCLONEDDS_CONFIG}"
  fi

  export CORE_CYCLONEDDS_CONFIG
  export CYCLONEDDS_URI="file://${CORE_CYCLONEDDS_CONFIG}"
  log "cyclonedds_uri=${CYCLONEDDS_URI}"
}

# Log one interface state. Missing/down/no-IPv4 is diagnostic only here.
log_one_interface_state() {
  local role="$1"
  local ifname="$2"
  local link_line=""
  local ipv4_addrs=""

  if ! command -v ip >/dev/null 2>&1; then
    log "WARNING: ip_command=missing; cannot inspect ${role}_interface=${ifname}"
    return 0
  fi

  if ! ip link show dev "${ifname}" >/dev/null 2>&1; then
    log "WARNING: ${role}_interface=missing iface=${ifname}"
    return 0
  fi

  link_line="$(ip -br link show dev "${ifname}" 2>/dev/null || true)"
  log "${role}_interface_link=${link_line}"

  ipv4_addrs="$(ip -o -4 addr show dev "${ifname}" 2>/dev/null | awk '{print $4}' | paste -sd, - || true)"
  if [[ -n "${ipv4_addrs}" ]]; then
    log "${role}_interface_ipv4=${ipv4_addrs}"
  else
    log "WARNING: ${role}_interface_ipv4=missing iface=${ifname}; setup script owns address configuration"
  fi
}

# Report WAN/autonomous state without waiting for the autonomous peer.
log_network_interface_state() {
  log_one_interface_state "wan" "${CORE_WAN_INTERFACE}"
  log_one_interface_state "autonomous" "${CORE_AUTONOMOUS_INTERFACE}"
}

# =============================================================================
# STEP 06. WAN Gateway Readiness Gate
# -----------------------------------------------------------------------------
# core binary를 바로 실행하지 않고, WAN 인터페이스의 gateway가
# 실제 ping에 응답할 때까지 대기한다. 네트워크가 준비되기 전 core 실행을 막는 안전장치다.
# =============================================================================

# Read the BPI-side default gateway configured for the package-selected interface.
configured_bpi_gateway() {
  local ifname="${CORE_WAN_INTERFACE}"

  # This route lookup is intentionally scoped to the configured WAN interface.
  # global default route가 아니라, 설정된 WAN 인터페이스의 default route만 본다.
  # awk는 `via <gateway>` 형태에서 gateway IP만 추출한다.
  ip -4 route show default dev "$ifname" 2>/dev/null |
    awk '
      {
        for (i = 1; i <= NF; i++) {
          if ($i == "via" && (i + 1) <= NF) {
            print $(i + 1)
            exit
          }
        }
      }
    '
}

# Return success only when the configured BPI-side gateway replies to one ping.
bpi_gateway_ping_ready() {
  local ifname="${CORE_WAN_INTERFACE}"
  local gateway=""

  # gateway가 아직 없을 수 있으므로 실패를 fatal로 보지 않고 readiness 실패로만 처리한다.
  gateway="$(configured_bpi_gateway || true)"

  [[ -n "$gateway" ]] || return 1

  # A successful ping through the selected interface proves the interface, IPv4
  # address, default route, and BPI-side gateway response are all ready enough
  # to start the core process.
  if ! command -v ping >/dev/null 2>&1; then
    fail "ping command not found; cannot verify BPI gateway readiness"
  fi

  # -I로 반드시 package-selected interface를 통해 ping한다.
  ping -4 -c 1 -W "${CORE_BPI_GATEWAY_PING_TIMEOUT_SEC}" -I "$ifname" "$gateway" >/dev/null 2>&1
}

# Keep the core binary stopped until the BPI-side gateway is reachable.
wait_for_bpi_gateway_ready() {
  local gateway=""

  if ! command -v ip >/dev/null 2>&1; then
    fail "ip command not found; cannot discover BPI gateway"
  fi

  log "bpi_gateway_wait=enabled iface=${CORE_WAN_INTERFACE} timeout_sec=${CORE_BPI_GATEWAY_PING_TIMEOUT_SEC} interval_sec=${CORE_BPI_GATEWAY_PING_INTERVAL_SEC}"

  while true; do
    gateway="$(configured_bpi_gateway || true)"

    if [[ -z "$gateway" ]]; then
      # DHCP/static route setup may not have produced the interface-specific
      # default route yet. Keep the launcher alive and retry.
      log "bpi_gateway_waiting=missing_default_gateway iface=${CORE_WAN_INTERFACE}"
    else
      if bpi_gateway_ping_ready; then
        log "bpi_gateway_ready=yes iface=${CORE_WAN_INTERFACE} gateway=${gateway}"
        return 0
      fi

      # The route exists, but the BPI-side gateway has not answered yet. This is
      # the only readiness gate; ROS/DDS discovery and external clients can lag.
      log "bpi_gateway_waiting=ping_no_reply iface=${CORE_WAN_INTERFACE} gateway=${gateway}"
    fi

    sleep "${CORE_BPI_GATEWAY_PING_INTERVAL_SEC}"
  done
}

# =============================================================================
# STEP 07. 런타임 환경 요약
# -----------------------------------------------------------------------------
# 실행 직전의 주요 환경을 한 번에 로그로 남긴다.
# 장애 분석 시 어떤 config, binary, ROS prefix, library path로 떴는지 확인하는 용도다.
# =============================================================================

# Emit a concise summary of the packaged runtime environment.
log_runtime_summary() {
  local version="unknown"
  [[ -f "${PACKAGE_VERSION_FILE}" ]] && version="$(cat "${PACKAGE_VERSION_FILE}")"

  log "version=${version}"
  log "env_source=${DEFAULT_FILE}"
  log "config_source=${CORE_CONFIG_DIR}/middleware.yaml"
  log "domain_id_source=${CORE_CONFIG_DIR}/middleware.yaml"
  log "binary=${CORE_BINARY}"
  log "core_config_root=${CORE_CONFIG_ROOT}"
  log "core_config_dir=${CORE_CONFIG_DIR}"
  log "onnx_dir=${CORE_ONNX_DIR}"
  log "data_dir=${CORE_DATA_DIR}"
  log "ros_prefix=${CORE_ROS_PREFIX}"
  log "host_lib_dir=${CORE_HOST_LIB_DIR}"
  log "runtime_home=${CORE_RUNTIME_HOME}"
  log "home=${HOME}"
  log "ros_home=${ROS_HOME}"
  log "wan_interface=${CORE_WAN_INTERFACE}"
  log "autonomous_interface=${CORE_AUTONOMOUS_INTERFACE}"
  log "cyclonedds_config=${CORE_CYCLONEDDS_CONFIG}"
  log "cyclonedds_uri=${CYCLONEDDS_URI:-}"
  log "bpi_gateway_ping_timeout_sec=${CORE_BPI_GATEWAY_PING_TIMEOUT_SEC}"
  log "bpi_gateway_ping_interval_sec=${CORE_BPI_GATEWAY_PING_INTERVAL_SEC}"
  log "ros_distro=${ROS_DISTRO}"
  log "requested_rmw_implementation=${RMW_IMPLEMENTATION:-default}"
  log "fastdds_builtin_transports=${FASTDDS_BUILTIN_TRANSPORTS:-default}"
  log "ament_prefix_path=${AMENT_PREFIX_PATH:-}"
  log "ld_library_path=${LD_LIBRARY_PATH:-}"

  if [[ -f "${BUILD_INFO_FILE}" ]]; then
    log "build-info begin"
    sed 's/^/[f8_core build-info] /' "${BUILD_INFO_FILE}"
    log "build-info end"
  fi
}

# =============================================================================
# STEP 08. 필수 파일 / 디렉터리 검사 유틸
# -----------------------------------------------------------------------------
# 반복되는 존재성 검사를 함수화한다.
# 일반 파일은 비어 있으면 실패시키고, ament marker처럼 0-byte가 정상인 파일은 별도 처리한다.
# =============================================================================

# Require one file path to exist before launch continues.
require_file() {
  local path="$1"
  local label="$2"
  [[ -e "${path}" ]] || fail "missing ${label}: ${path}"
  [[ -s "${path}" || -d "${path}" ]] || fail "empty ${label}: ${path}"
  log "OK ${label}: ${path}"
}

# Require one path to exist even when it may be a zero-byte marker file.
require_exists() {
  local path="$1"
  local label="$2"
  [[ -e "${path}" ]] || fail "missing ${label}: ${path}"
  log "OK ${label}: ${path}"
}

# Require one executable path before launch continues.
require_executable() {
  local path="$1"
  [[ -x "${path}" ]] || fail "missing or non-executable binary: ${path}"
  log "OK executable: ${path}"
}

# =============================================================================
# STEP 09. 설정 YAML / ONNX 모델 검사
# -----------------------------------------------------------------------------
# core 실행에 필요한 설정 파일과 policy 모델 파일을 사전에 검증한다.
# 누락된 상태로 바이너리를 띄워 내부 오류가 나는 대신, 런처 단계에서 명확히 실패시킨다.
# =============================================================================

# Verify the packaged YAML configuration files are present.
check_config_files() {
  local required_yaml=(command_iface.yaml joystick.yaml middleware.yaml rl.yaml robot.yaml safety.yaml)
  local f=""

  [[ -d "${CORE_CONFIG_DIR}" ]] || fail "missing YAML config directory: ${CORE_CONFIG_DIR}"
  for f in "${required_yaml[@]}"; do
    require_file "${CORE_CONFIG_DIR}/${f}" "YAML ${f}"
  done
}

# Verify the operator-editable runtime ONNX policy files are present.
check_onnx_files() {
  local onnx_dir="${CORE_ONNX_DIR}"
  local onnx_files=()

  [[ -d "${onnx_dir}" ]] || fail "missing ONNX directory: ${onnx_dir}"
  # nullglob를 켜야 *.onnx가 하나도 없을 때 패턴 문자열이 배열에 남지 않는다.
  shopt -s nullglob
  onnx_files=("${onnx_dir}"/*.onnx)
  shopt -u nullglob
  [[ "${#onnx_files[@]}" -gt 0 ]] || fail "no ONNX files found in ${onnx_dir}"
  log "OK ONNX directory: ${#onnx_files[@]} .onnx file(s)"
}

# =============================================================================
# STEP 10. Embedded ROS 라이브러리 경로 구성
# -----------------------------------------------------------------------------
# packaged ROS/runtime 라이브러리 디렉터리를 LD_LIBRARY_PATH 앞쪽에 추가한다.
# 이렇게 해야 host에 설치된 ROS와 섞이지 않고 설치본에 포함된 라이브러리를 우선 사용한다.
# =============================================================================

# Prefer the embedded runtime libraries over host ROS libraries at launch time.
prepend_embedded_ros_library_paths() {
  local ros_lib_root="${CORE_ROS_PREFIX}/lib"
  local child=""
  local had_nullglob="false"

  [[ -d "${ros_lib_root}" ]] || return 0

  # 호출 전 nullglob 상태를 기억했다가 함수 끝에서 복원한다.
  if shopt -q nullglob; then
    had_nullglob="true"
  else
    shopt -s nullglob
  fi

  prepend_ld_library_path "/usr/lib/f8_core"
  prepend_ld_library_path "/usr/lib/f8_core/onnxruntime"
  prepend_ld_library_path "${CORE_HOST_LIB_DIR}"
  prepend_ld_library_path "${ros_lib_root}"

  # ros/lib 바로 아래뿐 아니라, .so를 담은 하위 디렉터리도 검색 경로에 포함한다.
  for child in "${ros_lib_root}"/*; do
    [[ -d "${child}" ]] || continue
    if compgen -G "${child}/*.so*" >/dev/null; then
      prepend_ld_library_path "${child}"
    fi
  done

  if [[ "${had_nullglob}" != "true" ]]; then
    shopt -u nullglob
  fi
}

# =============================================================================
# STEP 11. ROS 실행 환경 Export
# -----------------------------------------------------------------------------
# 본체 바이너리가 시작되기 전에 ROS/CORE/HOME 관련 변수를 환경변수로 내보낸다.
# mkdir로 ROS log 경로까지 보장한 뒤, ament/cmake/colcon prefix를 embedded ROS 우선으로 설정한다.
# =============================================================================

# Set up the packaged ROS environment before the binary reads CORE_CONFIG_DIR.
setup_ros_environment() {
  resolve_rmw_implementation
  configure_fastdds_transport

  export ROS_VERSION
  export ROS_DISTRO
  export CORE_CONFIG_ROOT
  export CORE_CONFIG_DIR
  export CORE_ONNX_DIR
  export CORE_DATA_DIR
  export CORE_BINARY
  export CORE_ROS_PREFIX
  export CORE_HOST_LIB_DIR
  export CORE_WAN_INTERFACE
  export CORE_AUTONOMOUS_INTERFACE
  export CORE_CYCLONEDDS_CONFIG
  export CYCLONEDDS_URI
  if [[ -n "${FASTDDS_BUILTIN_TRANSPORTS:-}" ]]; then
    export FASTDDS_BUILTIN_TRANSPORTS
  fi
  export HOME
  export ROS_HOME

  # root 서비스에서도 /root/.ros가 아니라 서비스 전용 runtime home을 사용하게 만든다.
  mkdir -p "${HOME}" "${ROS_HOME}" "${ROS_HOME}/log"

  prepend_embedded_ros_library_paths

  # Prefer the packaged ROS runtime and keep /usr visible to ament lookups.
  export AMENT_PREFIX_PATH="${CORE_ROS_PREFIX}:/usr"
  export CMAKE_PREFIX_PATH="${CORE_ROS_PREFIX}:/usr"
  export COLCON_PREFIX_PATH="${CORE_ROS_PREFIX}:/usr"
}

# =============================================================================
# STEP 12. Embedded ROS Runtime 검증
# -----------------------------------------------------------------------------
# 패키지 내부 ROS prefix에 필요한 ament marker와 .so 파일이 실제로 있는지 확인한다.
# Fast DDS와 CycloneDDS RMW, rcl/rclcpp, rosidl typesupport까지 실행 전 점검한다.
# =============================================================================

# Verify the package carries both ROS RMW paths and the required typesupport files.
check_embedded_ros_runtime() {
  require_file "${CORE_ROS_PREFIX}" "embedded ROS prefix"
  # ament index resource markers may be zero-byte files.
  require_exists "${CORE_ROS_PREFIX}/share/ament_index/resource_index/packages/rclcpp" "embedded ROS package index (rclcpp)"
  require_exists "${CORE_ROS_PREFIX}/share/ament_index/resource_index/packages/nav_msgs" "embedded ROS package index (nav_msgs)"
  require_exists "${CORE_ROS_PREFIX}/share/ament_index/resource_index/packages/rcl" "embedded ROS package index (rcl)"
  require_exists "${CORE_ROS_PREFIX}/share/ament_index/resource_index/packages/rmw" "embedded ROS package index (rmw)"
  require_file "${CORE_ROS_PREFIX}/lib/librclcpp.so" "embedded ROS library (librclcpp.so)"
  require_file "${CORE_ROS_PREFIX}/lib/librcl.so" "embedded ROS library (librcl.so)"
  require_file "${CORE_ROS_PREFIX}/lib/librmw.so" "embedded ROS library (librmw.so)"
  require_exists "${CORE_ROS_PREFIX}/share/ament_index/resource_index/packages/rmw_fastrtps_cpp" "embedded ROS package index (rmw_fastrtps_cpp)"
  require_file "${CORE_ROS_PREFIX}/lib/librmw_fastrtps_cpp.so" "embedded ROS library (librmw_fastrtps_cpp.so)"
  require_exists "${CORE_ROS_PREFIX}/share/ament_index/resource_index/packages/rmw_cyclonedds_cpp" "embedded ROS package index (rmw_cyclonedds_cpp)"
  require_file "${CORE_ROS_PREFIX}/lib/librmw_cyclonedds_cpp.so" "embedded ROS library (librmw_cyclonedds_cpp.so)"
  require_exists "${CORE_ROS_PREFIX}/share/ament_index/resource_index/packages/rmw_implementation" "embedded ROS package index (rmw_implementation)"
  require_file "${CORE_ROS_PREFIX}/lib/librmw_implementation.so" "embedded ROS library (librmw_implementation.so)"
  require_exists "${CORE_ROS_PREFIX}/share/ament_index/resource_index/packages/rosidl_typesupport_cpp" "embedded ROS package index (rosidl_typesupport_cpp)"
  require_file "${CORE_ROS_PREFIX}/lib/librosidl_typesupport_cpp.so" "embedded ROS library (librosidl_typesupport_cpp.so)"
  require_file "${CORE_ROS_PREFIX}/lib/libnav_msgs__rosidl_typesupport_cpp.so" "embedded ROS library (libnav_msgs__rosidl_typesupport_cpp.so)"

  if [[ -n "${RMW_IMPLEMENTATION}" ]]; then
    require_exists "${CORE_ROS_PREFIX}/share/ament_index/resource_index/packages/${RMW_IMPLEMENTATION}" "embedded ROS package index (${RMW_IMPLEMENTATION})"
    require_file "${CORE_ROS_PREFIX}/lib/lib${RMW_IMPLEMENTATION}.so" "embedded ROS library (lib${RMW_IMPLEMENTATION}.so)"
  fi
}

# =============================================================================
# STEP 13. ldd 기반 공유 라이브러리 검사
# -----------------------------------------------------------------------------
# 바이너리와 주요 ROS .so 파일에 대해 `ldd` 결과를 확인한다.
# `not found`가 보이면 실제 실행 전에 dependency 누락을 명확히 로그로 남기고 종료한다.
# =============================================================================

# Fail fast when ldd reports missing shared libraries for a runtime artifact.
check_ldd_file() {
  local path="$1"
  local label="$2"

  if ! command -v ldd >/dev/null 2>&1; then
    log "WARNING: ldd not found; skipping shared-library check"
    return 0
  fi

  # ldd 출력에 "not found"가 하나라도 있으면 runtime dependency가 깨진 상태다.
  if ldd "${path}" 2>/dev/null | grep -q 'not found'; then
    log "ERROR: missing shared libraries detected by ldd for ${label}"
    ldd "${path}" || true
    exit 127
  fi

  log "OK ldd: no missing shared libraries for ${label}"
}

# =============================================================================
# STEP 14. Main Launch Flow
# -----------------------------------------------------------------------------
# 모든 준비 단계를 정해진 순서로 실행한다.
# 마지막에는 shell이 남지 않도록 exec로 본체 바이너리 프로세스로 교체한다.
# =============================================================================

# Wire together defaults, runtime validation, and the final daemon launch.
main() {
  # ERR trap은 예상하지 못한 shell command 실패를 줄 번호와 exit code가 있는 fatal 로그로 바꾼다.
  trap 'on_error ${LINENO} $?' ERR

  source_defaults
  read_cocelo_network_interfaces_from_bashrc
  validate_network_defaults
  configure_cyclonedds_environment
  log_network_interface_state
  wait_for_bpi_gateway_ready
  setup_ros_environment
  log_runtime_summary

  require_executable "${CORE_BINARY}"
  require_file "${CORE_DATA_DIR}" "data directory"
  check_config_files
  check_onnx_files
  check_embedded_ros_runtime
  check_ldd_file "${CORE_BINARY}" "core binary"
  check_ldd_file "${CORE_ROS_PREFIX}/lib/librcl.so" "embedded librcl.so"
  check_ldd_file "${CORE_ROS_PREFIX}/lib/librclcpp.so" "embedded librclcpp.so"
  check_ldd_file "${CORE_ROS_PREFIX}/lib/librmw.so" "embedded librmw.so"
  check_ldd_file "${CORE_ROS_PREFIX}/lib/librmw_fastrtps_cpp.so" "embedded Fast DDS RMW library"
  check_ldd_file "${CORE_ROS_PREFIX}/lib/librmw_cyclonedds_cpp.so" "embedded CycloneDDS RMW library"
  check_ldd_file "${CORE_ROS_PREFIX}/lib/librmw_implementation.so" "embedded rmw_implementation library"
  check_ldd_file "${CORE_ROS_PREFIX}/lib/librosidl_typesupport_cpp.so" "embedded rosidl_typesupport_cpp library"
  check_ldd_file "${CORE_ROS_PREFIX}/lib/libnav_msgs__rosidl_typesupport_cpp.so" "embedded nav_msgs typesupport library"
  if [[ -n "${RMW_IMPLEMENTATION}" ]]; then
    check_ldd_file "${CORE_ROS_PREFIX}/lib/lib${RMW_IMPLEMENTATION}.so" "embedded lib${RMW_IMPLEMENTATION}.so"
  fi

  # 상대 경로를 사용하는 runtime artifact가 있어도 data directory 기준으로 동작하게 한다.
  cd "${CORE_DATA_DIR}"

  # Allow time synchronization and other startup services to settle briefly.
  log "core_start_grace_sleep_sec=15"
  sleep 15

  log "starting ${CORE_BINARY} $*"
  # exec는 launcher shell을 남기지 않고 현재 프로세스를 core binary로 교체한다.
  exec "${CORE_BINARY}" "$@"
}

main "$@"

