// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from core:srv/DynamicParam.idl
// generated code does not contain a copyright notice

#ifndef CORE__SRV__DETAIL__DYNAMIC_PARAM__STRUCT_H_
#define CORE__SRV__DETAIL__DYNAMIC_PARAM__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'robot_motor_ids'
// Member 'robot_motor_kp'
// Member 'robot_motor_kd'
// Member 'robot_max_torque_nm'
// Member 'wma_weights'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'safety_motor_rules'
#include "core/msg/detail/motor_safety_rule__struct.h"
// Member 'safety_imu_rules'
#include "core/msg/detail/imu_safety_rule__struct.h"

/// Struct defined in srv/DynamicParam in the package core.
typedef struct core__srv__DynamicParam_Request
{
  /// Robot gains and torque limits paired by motor id.
  rosidl_runtime_c__uint8__Sequence robot_motor_ids;
  rosidl_runtime_c__float__Sequence robot_motor_kp;
  rosidl_runtime_c__float__Sequence robot_motor_kd;
  rosidl_runtime_c__float__Sequence robot_max_torque_nm;
  /// Joystick motion-slot mapping and runtime shaping values.
  int32_t joystick_left_x[2];
  int32_t joystick_left_y[2];
  int32_t joystick_right_x[2];
  int32_t joystick_right_y[2];
  int32_t joystick_dpad_x;
  int32_t joystick_dpad_y;
  int32_t joystick_left_btn;
  int32_t joystick_right_btn;
  float joystick_dpad_step_x;
  float joystick_dpad_step_y;
  float joystick_smoothness;
  float joystick_deadzone;
  float joystick_min_motion_command[8];
  float joystick_max_motion_command[8];
  /// Command interface runtime arbitration and motion limits.
  double cmd_priority_hold_sec;
  double cmd_packet_timeout_sec;
  bool use_command_filter;
  int32_t motion_command_index_linear_vel_x;
  int32_t motion_command_index_linear_vel_y;
  int32_t motion_command_index_angular_vel_z;
  int32_t motion_command_index_position_z;
  int32_t motion_command_index_orientation_roll;
  int32_t motion_command_index_orientation_pitch;
  float command_iface_min_motion_command[8];
  float command_iface_max_motion_command[8];
  /// Safety policy. The service always carries the full rule snapshot.
  float battery_low_soc_threshold;
  float motor_temperature_threshold;
  float battery_temperature_threshold;
  rosidl_runtime_c__float__Sequence wma_weights;
  core__msg__MotorSafetyRule__Sequence safety_motor_rules;
  core__msg__ImuSafetyRule__Sequence safety_imu_rules;
} core__srv__DynamicParam_Request;

// Struct for a sequence of core__srv__DynamicParam_Request.
typedef struct core__srv__DynamicParam_Request__Sequence
{
  core__srv__DynamicParam_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} core__srv__DynamicParam_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'reason'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/DynamicParam in the package core.
typedef struct core__srv__DynamicParam_Response
{
  bool success;
  rosidl_runtime_c__String reason;
} core__srv__DynamicParam_Response;

// Struct for a sequence of core__srv__DynamicParam_Response.
typedef struct core__srv__DynamicParam_Response__Sequence
{
  core__srv__DynamicParam_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} core__srv__DynamicParam_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CORE__SRV__DETAIL__DYNAMIC_PARAM__STRUCT_H_
