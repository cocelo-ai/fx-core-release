// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from core:srv/DynamicParam.idl
// generated code does not contain a copyright notice

#ifndef CORE__SRV__DETAIL__DYNAMIC_PARAM__TRAITS_HPP_
#define CORE__SRV__DETAIL__DYNAMIC_PARAM__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "core/srv/detail/dynamic_param__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'safety_motor_rules'
#include "core/msg/detail/motor_safety_rule__traits.hpp"
// Member 'safety_imu_rules'
#include "core/msg/detail/imu_safety_rule__traits.hpp"

namespace core
{

namespace srv
{

inline void to_flow_style_yaml(
  const DynamicParam_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: robot_motor_ids
  {
    if (msg.robot_motor_ids.size() == 0) {
      out << "robot_motor_ids: []";
    } else {
      out << "robot_motor_ids: [";
      size_t pending_items = msg.robot_motor_ids.size();
      for (auto item : msg.robot_motor_ids) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: robot_motor_kp
  {
    if (msg.robot_motor_kp.size() == 0) {
      out << "robot_motor_kp: []";
    } else {
      out << "robot_motor_kp: [";
      size_t pending_items = msg.robot_motor_kp.size();
      for (auto item : msg.robot_motor_kp) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: robot_motor_kd
  {
    if (msg.robot_motor_kd.size() == 0) {
      out << "robot_motor_kd: []";
    } else {
      out << "robot_motor_kd: [";
      size_t pending_items = msg.robot_motor_kd.size();
      for (auto item : msg.robot_motor_kd) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: robot_max_torque_nm
  {
    if (msg.robot_max_torque_nm.size() == 0) {
      out << "robot_max_torque_nm: []";
    } else {
      out << "robot_max_torque_nm: [";
      size_t pending_items = msg.robot_max_torque_nm.size();
      for (auto item : msg.robot_max_torque_nm) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: joystick_left_x
  {
    if (msg.joystick_left_x.size() == 0) {
      out << "joystick_left_x: []";
    } else {
      out << "joystick_left_x: [";
      size_t pending_items = msg.joystick_left_x.size();
      for (auto item : msg.joystick_left_x) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: joystick_left_y
  {
    if (msg.joystick_left_y.size() == 0) {
      out << "joystick_left_y: []";
    } else {
      out << "joystick_left_y: [";
      size_t pending_items = msg.joystick_left_y.size();
      for (auto item : msg.joystick_left_y) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: joystick_right_x
  {
    if (msg.joystick_right_x.size() == 0) {
      out << "joystick_right_x: []";
    } else {
      out << "joystick_right_x: [";
      size_t pending_items = msg.joystick_right_x.size();
      for (auto item : msg.joystick_right_x) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: joystick_right_y
  {
    if (msg.joystick_right_y.size() == 0) {
      out << "joystick_right_y: []";
    } else {
      out << "joystick_right_y: [";
      size_t pending_items = msg.joystick_right_y.size();
      for (auto item : msg.joystick_right_y) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: joystick_dpad_x
  {
    out << "joystick_dpad_x: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_dpad_x, out);
    out << ", ";
  }

  // member: joystick_dpad_y
  {
    out << "joystick_dpad_y: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_dpad_y, out);
    out << ", ";
  }

  // member: joystick_left_btn
  {
    out << "joystick_left_btn: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_left_btn, out);
    out << ", ";
  }

  // member: joystick_right_btn
  {
    out << "joystick_right_btn: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_right_btn, out);
    out << ", ";
  }

  // member: joystick_dpad_step_x
  {
    out << "joystick_dpad_step_x: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_dpad_step_x, out);
    out << ", ";
  }

  // member: joystick_dpad_step_y
  {
    out << "joystick_dpad_step_y: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_dpad_step_y, out);
    out << ", ";
  }

  // member: joystick_smoothness
  {
    out << "joystick_smoothness: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_smoothness, out);
    out << ", ";
  }

  // member: joystick_deadzone
  {
    out << "joystick_deadzone: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_deadzone, out);
    out << ", ";
  }

  // member: joystick_min_motion_command
  {
    if (msg.joystick_min_motion_command.size() == 0) {
      out << "joystick_min_motion_command: []";
    } else {
      out << "joystick_min_motion_command: [";
      size_t pending_items = msg.joystick_min_motion_command.size();
      for (auto item : msg.joystick_min_motion_command) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: joystick_max_motion_command
  {
    if (msg.joystick_max_motion_command.size() == 0) {
      out << "joystick_max_motion_command: []";
    } else {
      out << "joystick_max_motion_command: [";
      size_t pending_items = msg.joystick_max_motion_command.size();
      for (auto item : msg.joystick_max_motion_command) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: cmd_priority_hold_sec
  {
    out << "cmd_priority_hold_sec: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_priority_hold_sec, out);
    out << ", ";
  }

  // member: cmd_packet_timeout_sec
  {
    out << "cmd_packet_timeout_sec: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_packet_timeout_sec, out);
    out << ", ";
  }

  // member: use_command_filter
  {
    out << "use_command_filter: ";
    rosidl_generator_traits::value_to_yaml(msg.use_command_filter, out);
    out << ", ";
  }

  // member: motion_command_index_linear_vel_x
  {
    out << "motion_command_index_linear_vel_x: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_command_index_linear_vel_x, out);
    out << ", ";
  }

  // member: motion_command_index_linear_vel_y
  {
    out << "motion_command_index_linear_vel_y: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_command_index_linear_vel_y, out);
    out << ", ";
  }

  // member: motion_command_index_angular_vel_z
  {
    out << "motion_command_index_angular_vel_z: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_command_index_angular_vel_z, out);
    out << ", ";
  }

  // member: motion_command_index_position_z
  {
    out << "motion_command_index_position_z: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_command_index_position_z, out);
    out << ", ";
  }

  // member: motion_command_index_orientation_roll
  {
    out << "motion_command_index_orientation_roll: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_command_index_orientation_roll, out);
    out << ", ";
  }

  // member: motion_command_index_orientation_pitch
  {
    out << "motion_command_index_orientation_pitch: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_command_index_orientation_pitch, out);
    out << ", ";
  }

  // member: command_iface_min_motion_command
  {
    if (msg.command_iface_min_motion_command.size() == 0) {
      out << "command_iface_min_motion_command: []";
    } else {
      out << "command_iface_min_motion_command: [";
      size_t pending_items = msg.command_iface_min_motion_command.size();
      for (auto item : msg.command_iface_min_motion_command) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: command_iface_max_motion_command
  {
    if (msg.command_iface_max_motion_command.size() == 0) {
      out << "command_iface_max_motion_command: []";
    } else {
      out << "command_iface_max_motion_command: [";
      size_t pending_items = msg.command_iface_max_motion_command.size();
      for (auto item : msg.command_iface_max_motion_command) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: battery_low_soc_threshold
  {
    out << "battery_low_soc_threshold: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_low_soc_threshold, out);
    out << ", ";
  }

  // member: motor_temperature_threshold
  {
    out << "motor_temperature_threshold: ";
    rosidl_generator_traits::value_to_yaml(msg.motor_temperature_threshold, out);
    out << ", ";
  }

  // member: battery_temperature_threshold
  {
    out << "battery_temperature_threshold: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_temperature_threshold, out);
    out << ", ";
  }

  // member: wma_weights
  {
    if (msg.wma_weights.size() == 0) {
      out << "wma_weights: []";
    } else {
      out << "wma_weights: [";
      size_t pending_items = msg.wma_weights.size();
      for (auto item : msg.wma_weights) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: safety_motor_rules
  {
    if (msg.safety_motor_rules.size() == 0) {
      out << "safety_motor_rules: []";
    } else {
      out << "safety_motor_rules: [";
      size_t pending_items = msg.safety_motor_rules.size();
      for (auto item : msg.safety_motor_rules) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: safety_imu_rules
  {
    if (msg.safety_imu_rules.size() == 0) {
      out << "safety_imu_rules: []";
    } else {
      out << "safety_imu_rules: [";
      size_t pending_items = msg.safety_imu_rules.size();
      for (auto item : msg.safety_imu_rules) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DynamicParam_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: robot_motor_ids
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.robot_motor_ids.size() == 0) {
      out << "robot_motor_ids: []\n";
    } else {
      out << "robot_motor_ids:\n";
      for (auto item : msg.robot_motor_ids) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: robot_motor_kp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.robot_motor_kp.size() == 0) {
      out << "robot_motor_kp: []\n";
    } else {
      out << "robot_motor_kp:\n";
      for (auto item : msg.robot_motor_kp) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: robot_motor_kd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.robot_motor_kd.size() == 0) {
      out << "robot_motor_kd: []\n";
    } else {
      out << "robot_motor_kd:\n";
      for (auto item : msg.robot_motor_kd) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: robot_max_torque_nm
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.robot_max_torque_nm.size() == 0) {
      out << "robot_max_torque_nm: []\n";
    } else {
      out << "robot_max_torque_nm:\n";
      for (auto item : msg.robot_max_torque_nm) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: joystick_left_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.joystick_left_x.size() == 0) {
      out << "joystick_left_x: []\n";
    } else {
      out << "joystick_left_x:\n";
      for (auto item : msg.joystick_left_x) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: joystick_left_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.joystick_left_y.size() == 0) {
      out << "joystick_left_y: []\n";
    } else {
      out << "joystick_left_y:\n";
      for (auto item : msg.joystick_left_y) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: joystick_right_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.joystick_right_x.size() == 0) {
      out << "joystick_right_x: []\n";
    } else {
      out << "joystick_right_x:\n";
      for (auto item : msg.joystick_right_x) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: joystick_right_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.joystick_right_y.size() == 0) {
      out << "joystick_right_y: []\n";
    } else {
      out << "joystick_right_y:\n";
      for (auto item : msg.joystick_right_y) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: joystick_dpad_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "joystick_dpad_x: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_dpad_x, out);
    out << "\n";
  }

  // member: joystick_dpad_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "joystick_dpad_y: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_dpad_y, out);
    out << "\n";
  }

  // member: joystick_left_btn
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "joystick_left_btn: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_left_btn, out);
    out << "\n";
  }

  // member: joystick_right_btn
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "joystick_right_btn: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_right_btn, out);
    out << "\n";
  }

  // member: joystick_dpad_step_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "joystick_dpad_step_x: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_dpad_step_x, out);
    out << "\n";
  }

  // member: joystick_dpad_step_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "joystick_dpad_step_y: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_dpad_step_y, out);
    out << "\n";
  }

  // member: joystick_smoothness
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "joystick_smoothness: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_smoothness, out);
    out << "\n";
  }

  // member: joystick_deadzone
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "joystick_deadzone: ";
    rosidl_generator_traits::value_to_yaml(msg.joystick_deadzone, out);
    out << "\n";
  }

  // member: joystick_min_motion_command
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.joystick_min_motion_command.size() == 0) {
      out << "joystick_min_motion_command: []\n";
    } else {
      out << "joystick_min_motion_command:\n";
      for (auto item : msg.joystick_min_motion_command) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: joystick_max_motion_command
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.joystick_max_motion_command.size() == 0) {
      out << "joystick_max_motion_command: []\n";
    } else {
      out << "joystick_max_motion_command:\n";
      for (auto item : msg.joystick_max_motion_command) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: cmd_priority_hold_sec
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_priority_hold_sec: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_priority_hold_sec, out);
    out << "\n";
  }

  // member: cmd_packet_timeout_sec
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_packet_timeout_sec: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_packet_timeout_sec, out);
    out << "\n";
  }

  // member: use_command_filter
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "use_command_filter: ";
    rosidl_generator_traits::value_to_yaml(msg.use_command_filter, out);
    out << "\n";
  }

  // member: motion_command_index_linear_vel_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motion_command_index_linear_vel_x: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_command_index_linear_vel_x, out);
    out << "\n";
  }

  // member: motion_command_index_linear_vel_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motion_command_index_linear_vel_y: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_command_index_linear_vel_y, out);
    out << "\n";
  }

  // member: motion_command_index_angular_vel_z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motion_command_index_angular_vel_z: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_command_index_angular_vel_z, out);
    out << "\n";
  }

  // member: motion_command_index_position_z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motion_command_index_position_z: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_command_index_position_z, out);
    out << "\n";
  }

  // member: motion_command_index_orientation_roll
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motion_command_index_orientation_roll: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_command_index_orientation_roll, out);
    out << "\n";
  }

  // member: motion_command_index_orientation_pitch
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motion_command_index_orientation_pitch: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_command_index_orientation_pitch, out);
    out << "\n";
  }

  // member: command_iface_min_motion_command
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.command_iface_min_motion_command.size() == 0) {
      out << "command_iface_min_motion_command: []\n";
    } else {
      out << "command_iface_min_motion_command:\n";
      for (auto item : msg.command_iface_min_motion_command) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: command_iface_max_motion_command
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.command_iface_max_motion_command.size() == 0) {
      out << "command_iface_max_motion_command: []\n";
    } else {
      out << "command_iface_max_motion_command:\n";
      for (auto item : msg.command_iface_max_motion_command) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: battery_low_soc_threshold
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_low_soc_threshold: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_low_soc_threshold, out);
    out << "\n";
  }

  // member: motor_temperature_threshold
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motor_temperature_threshold: ";
    rosidl_generator_traits::value_to_yaml(msg.motor_temperature_threshold, out);
    out << "\n";
  }

  // member: battery_temperature_threshold
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_temperature_threshold: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_temperature_threshold, out);
    out << "\n";
  }

  // member: wma_weights
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.wma_weights.size() == 0) {
      out << "wma_weights: []\n";
    } else {
      out << "wma_weights:\n";
      for (auto item : msg.wma_weights) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: safety_motor_rules
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.safety_motor_rules.size() == 0) {
      out << "safety_motor_rules: []\n";
    } else {
      out << "safety_motor_rules:\n";
      for (auto item : msg.safety_motor_rules) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: safety_imu_rules
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.safety_imu_rules.size() == 0) {
      out << "safety_imu_rules: []\n";
    } else {
      out << "safety_imu_rules:\n";
      for (auto item : msg.safety_imu_rules) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DynamicParam_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace core

namespace rosidl_generator_traits
{

[[deprecated("use core::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const core::srv::DynamicParam_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  core::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use core::srv::to_yaml() instead")]]
inline std::string to_yaml(const core::srv::DynamicParam_Request & msg)
{
  return core::srv::to_yaml(msg);
}

template<>
inline const char * data_type<core::srv::DynamicParam_Request>()
{
  return "core::srv::DynamicParam_Request";
}

template<>
inline const char * name<core::srv::DynamicParam_Request>()
{
  return "core/srv/DynamicParam_Request";
}

template<>
struct has_fixed_size<core::srv::DynamicParam_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<core::srv::DynamicParam_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<core::srv::DynamicParam_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace core
{

namespace srv
{

inline void to_flow_style_yaml(
  const DynamicParam_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << ", ";
  }

  // member: reason
  {
    out << "reason: ";
    rosidl_generator_traits::value_to_yaml(msg.reason, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DynamicParam_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }

  // member: reason
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reason: ";
    rosidl_generator_traits::value_to_yaml(msg.reason, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DynamicParam_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace core

namespace rosidl_generator_traits
{

[[deprecated("use core::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const core::srv::DynamicParam_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  core::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use core::srv::to_yaml() instead")]]
inline std::string to_yaml(const core::srv::DynamicParam_Response & msg)
{
  return core::srv::to_yaml(msg);
}

template<>
inline const char * data_type<core::srv::DynamicParam_Response>()
{
  return "core::srv::DynamicParam_Response";
}

template<>
inline const char * name<core::srv::DynamicParam_Response>()
{
  return "core/srv/DynamicParam_Response";
}

template<>
struct has_fixed_size<core::srv::DynamicParam_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<core::srv::DynamicParam_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<core::srv::DynamicParam_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<core::srv::DynamicParam>()
{
  return "core::srv::DynamicParam";
}

template<>
inline const char * name<core::srv::DynamicParam>()
{
  return "core/srv/DynamicParam";
}

template<>
struct has_fixed_size<core::srv::DynamicParam>
  : std::integral_constant<
    bool,
    has_fixed_size<core::srv::DynamicParam_Request>::value &&
    has_fixed_size<core::srv::DynamicParam_Response>::value
  >
{
};

template<>
struct has_bounded_size<core::srv::DynamicParam>
  : std::integral_constant<
    bool,
    has_bounded_size<core::srv::DynamicParam_Request>::value &&
    has_bounded_size<core::srv::DynamicParam_Response>::value
  >
{
};

template<>
struct is_service<core::srv::DynamicParam>
  : std::true_type
{
};

template<>
struct is_service_request<core::srv::DynamicParam_Request>
  : std::true_type
{
};

template<>
struct is_service_response<core::srv::DynamicParam_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // CORE__SRV__DETAIL__DYNAMIC_PARAM__TRAITS_HPP_
