// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from core:srv/DynamicParam.idl
// generated code does not contain a copyright notice
#include "core/srv/detail/dynamic_param__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"

// Include directives for member types
// Member `robot_motor_ids`
// Member `robot_motor_kp`
// Member `robot_motor_kd`
// Member `robot_max_torque_nm`
// Member `wma_weights`
#include "rosidl_runtime_c/primitives_sequence_functions.h"
// Member `safety_motor_rules`
#include "core/msg/detail/motor_safety_rule__functions.h"
// Member `safety_imu_rules`
#include "core/msg/detail/imu_safety_rule__functions.h"

bool
core__srv__DynamicParam_Request__init(core__srv__DynamicParam_Request * msg)
{
  if (!msg) {
    return false;
  }
  // robot_motor_ids
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->robot_motor_ids, 0)) {
    core__srv__DynamicParam_Request__fini(msg);
    return false;
  }
  // robot_motor_kp
  if (!rosidl_runtime_c__float__Sequence__init(&msg->robot_motor_kp, 0)) {
    core__srv__DynamicParam_Request__fini(msg);
    return false;
  }
  // robot_motor_kd
  if (!rosidl_runtime_c__float__Sequence__init(&msg->robot_motor_kd, 0)) {
    core__srv__DynamicParam_Request__fini(msg);
    return false;
  }
  // robot_max_torque_nm
  if (!rosidl_runtime_c__float__Sequence__init(&msg->robot_max_torque_nm, 0)) {
    core__srv__DynamicParam_Request__fini(msg);
    return false;
  }
  // joystick_left_x
  // joystick_left_y
  // joystick_right_x
  // joystick_right_y
  // joystick_dpad_x
  // joystick_dpad_y
  // joystick_left_btn
  // joystick_right_btn
  // joystick_dpad_step_x
  // joystick_dpad_step_y
  // joystick_smoothness
  // joystick_deadzone
  // joystick_min_motion_command
  // joystick_max_motion_command
  // cmd_priority_hold_sec
  // cmd_packet_timeout_sec
  // use_command_filter
  // motion_command_index_linear_vel_x
  // motion_command_index_linear_vel_y
  // motion_command_index_angular_vel_z
  // motion_command_index_position_z
  // motion_command_index_orientation_roll
  // motion_command_index_orientation_pitch
  // command_iface_min_motion_command
  // command_iface_max_motion_command
  // battery_low_soc_threshold
  // motor_temperature_threshold
  // battery_temperature_threshold
  // wma_weights
  if (!rosidl_runtime_c__float__Sequence__init(&msg->wma_weights, 0)) {
    core__srv__DynamicParam_Request__fini(msg);
    return false;
  }
  // safety_motor_rules
  if (!core__msg__MotorSafetyRule__Sequence__init(&msg->safety_motor_rules, 0)) {
    core__srv__DynamicParam_Request__fini(msg);
    return false;
  }
  // safety_imu_rules
  if (!core__msg__ImuSafetyRule__Sequence__init(&msg->safety_imu_rules, 0)) {
    core__srv__DynamicParam_Request__fini(msg);
    return false;
  }
  return true;
}

void
core__srv__DynamicParam_Request__fini(core__srv__DynamicParam_Request * msg)
{
  if (!msg) {
    return;
  }
  // robot_motor_ids
  rosidl_runtime_c__uint8__Sequence__fini(&msg->robot_motor_ids);
  // robot_motor_kp
  rosidl_runtime_c__float__Sequence__fini(&msg->robot_motor_kp);
  // robot_motor_kd
  rosidl_runtime_c__float__Sequence__fini(&msg->robot_motor_kd);
  // robot_max_torque_nm
  rosidl_runtime_c__float__Sequence__fini(&msg->robot_max_torque_nm);
  // joystick_left_x
  // joystick_left_y
  // joystick_right_x
  // joystick_right_y
  // joystick_dpad_x
  // joystick_dpad_y
  // joystick_left_btn
  // joystick_right_btn
  // joystick_dpad_step_x
  // joystick_dpad_step_y
  // joystick_smoothness
  // joystick_deadzone
  // joystick_min_motion_command
  // joystick_max_motion_command
  // cmd_priority_hold_sec
  // cmd_packet_timeout_sec
  // use_command_filter
  // motion_command_index_linear_vel_x
  // motion_command_index_linear_vel_y
  // motion_command_index_angular_vel_z
  // motion_command_index_position_z
  // motion_command_index_orientation_roll
  // motion_command_index_orientation_pitch
  // command_iface_min_motion_command
  // command_iface_max_motion_command
  // battery_low_soc_threshold
  // motor_temperature_threshold
  // battery_temperature_threshold
  // wma_weights
  rosidl_runtime_c__float__Sequence__fini(&msg->wma_weights);
  // safety_motor_rules
  core__msg__MotorSafetyRule__Sequence__fini(&msg->safety_motor_rules);
  // safety_imu_rules
  core__msg__ImuSafetyRule__Sequence__fini(&msg->safety_imu_rules);
}

bool
core__srv__DynamicParam_Request__are_equal(const core__srv__DynamicParam_Request * lhs, const core__srv__DynamicParam_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // robot_motor_ids
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->robot_motor_ids), &(rhs->robot_motor_ids)))
  {
    return false;
  }
  // robot_motor_kp
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->robot_motor_kp), &(rhs->robot_motor_kp)))
  {
    return false;
  }
  // robot_motor_kd
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->robot_motor_kd), &(rhs->robot_motor_kd)))
  {
    return false;
  }
  // robot_max_torque_nm
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->robot_max_torque_nm), &(rhs->robot_max_torque_nm)))
  {
    return false;
  }
  // joystick_left_x
  for (size_t i = 0; i < 2; ++i) {
    if (lhs->joystick_left_x[i] != rhs->joystick_left_x[i]) {
      return false;
    }
  }
  // joystick_left_y
  for (size_t i = 0; i < 2; ++i) {
    if (lhs->joystick_left_y[i] != rhs->joystick_left_y[i]) {
      return false;
    }
  }
  // joystick_right_x
  for (size_t i = 0; i < 2; ++i) {
    if (lhs->joystick_right_x[i] != rhs->joystick_right_x[i]) {
      return false;
    }
  }
  // joystick_right_y
  for (size_t i = 0; i < 2; ++i) {
    if (lhs->joystick_right_y[i] != rhs->joystick_right_y[i]) {
      return false;
    }
  }
  // joystick_dpad_x
  if (lhs->joystick_dpad_x != rhs->joystick_dpad_x) {
    return false;
  }
  // joystick_dpad_y
  if (lhs->joystick_dpad_y != rhs->joystick_dpad_y) {
    return false;
  }
  // joystick_left_btn
  if (lhs->joystick_left_btn != rhs->joystick_left_btn) {
    return false;
  }
  // joystick_right_btn
  if (lhs->joystick_right_btn != rhs->joystick_right_btn) {
    return false;
  }
  // joystick_dpad_step_x
  if (lhs->joystick_dpad_step_x != rhs->joystick_dpad_step_x) {
    return false;
  }
  // joystick_dpad_step_y
  if (lhs->joystick_dpad_step_y != rhs->joystick_dpad_step_y) {
    return false;
  }
  // joystick_smoothness
  if (lhs->joystick_smoothness != rhs->joystick_smoothness) {
    return false;
  }
  // joystick_deadzone
  if (lhs->joystick_deadzone != rhs->joystick_deadzone) {
    return false;
  }
  // joystick_min_motion_command
  for (size_t i = 0; i < 8; ++i) {
    if (lhs->joystick_min_motion_command[i] != rhs->joystick_min_motion_command[i]) {
      return false;
    }
  }
  // joystick_max_motion_command
  for (size_t i = 0; i < 8; ++i) {
    if (lhs->joystick_max_motion_command[i] != rhs->joystick_max_motion_command[i]) {
      return false;
    }
  }
  // cmd_priority_hold_sec
  if (lhs->cmd_priority_hold_sec != rhs->cmd_priority_hold_sec) {
    return false;
  }
  // cmd_packet_timeout_sec
  if (lhs->cmd_packet_timeout_sec != rhs->cmd_packet_timeout_sec) {
    return false;
  }
  // use_command_filter
  if (lhs->use_command_filter != rhs->use_command_filter) {
    return false;
  }
  // motion_command_index_linear_vel_x
  if (lhs->motion_command_index_linear_vel_x != rhs->motion_command_index_linear_vel_x) {
    return false;
  }
  // motion_command_index_linear_vel_y
  if (lhs->motion_command_index_linear_vel_y != rhs->motion_command_index_linear_vel_y) {
    return false;
  }
  // motion_command_index_angular_vel_z
  if (lhs->motion_command_index_angular_vel_z != rhs->motion_command_index_angular_vel_z) {
    return false;
  }
  // motion_command_index_position_z
  if (lhs->motion_command_index_position_z != rhs->motion_command_index_position_z) {
    return false;
  }
  // motion_command_index_orientation_roll
  if (lhs->motion_command_index_orientation_roll != rhs->motion_command_index_orientation_roll) {
    return false;
  }
  // motion_command_index_orientation_pitch
  if (lhs->motion_command_index_orientation_pitch != rhs->motion_command_index_orientation_pitch) {
    return false;
  }
  // command_iface_min_motion_command
  for (size_t i = 0; i < 8; ++i) {
    if (lhs->command_iface_min_motion_command[i] != rhs->command_iface_min_motion_command[i]) {
      return false;
    }
  }
  // command_iface_max_motion_command
  for (size_t i = 0; i < 8; ++i) {
    if (lhs->command_iface_max_motion_command[i] != rhs->command_iface_max_motion_command[i]) {
      return false;
    }
  }
  // battery_low_soc_threshold
  if (lhs->battery_low_soc_threshold != rhs->battery_low_soc_threshold) {
    return false;
  }
  // motor_temperature_threshold
  if (lhs->motor_temperature_threshold != rhs->motor_temperature_threshold) {
    return false;
  }
  // battery_temperature_threshold
  if (lhs->battery_temperature_threshold != rhs->battery_temperature_threshold) {
    return false;
  }
  // wma_weights
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->wma_weights), &(rhs->wma_weights)))
  {
    return false;
  }
  // safety_motor_rules
  if (!core__msg__MotorSafetyRule__Sequence__are_equal(
      &(lhs->safety_motor_rules), &(rhs->safety_motor_rules)))
  {
    return false;
  }
  // safety_imu_rules
  if (!core__msg__ImuSafetyRule__Sequence__are_equal(
      &(lhs->safety_imu_rules), &(rhs->safety_imu_rules)))
  {
    return false;
  }
  return true;
}

bool
core__srv__DynamicParam_Request__copy(
  const core__srv__DynamicParam_Request * input,
  core__srv__DynamicParam_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // robot_motor_ids
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->robot_motor_ids), &(output->robot_motor_ids)))
  {
    return false;
  }
  // robot_motor_kp
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->robot_motor_kp), &(output->robot_motor_kp)))
  {
    return false;
  }
  // robot_motor_kd
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->robot_motor_kd), &(output->robot_motor_kd)))
  {
    return false;
  }
  // robot_max_torque_nm
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->robot_max_torque_nm), &(output->robot_max_torque_nm)))
  {
    return false;
  }
  // joystick_left_x
  for (size_t i = 0; i < 2; ++i) {
    output->joystick_left_x[i] = input->joystick_left_x[i];
  }
  // joystick_left_y
  for (size_t i = 0; i < 2; ++i) {
    output->joystick_left_y[i] = input->joystick_left_y[i];
  }
  // joystick_right_x
  for (size_t i = 0; i < 2; ++i) {
    output->joystick_right_x[i] = input->joystick_right_x[i];
  }
  // joystick_right_y
  for (size_t i = 0; i < 2; ++i) {
    output->joystick_right_y[i] = input->joystick_right_y[i];
  }
  // joystick_dpad_x
  output->joystick_dpad_x = input->joystick_dpad_x;
  // joystick_dpad_y
  output->joystick_dpad_y = input->joystick_dpad_y;
  // joystick_left_btn
  output->joystick_left_btn = input->joystick_left_btn;
  // joystick_right_btn
  output->joystick_right_btn = input->joystick_right_btn;
  // joystick_dpad_step_x
  output->joystick_dpad_step_x = input->joystick_dpad_step_x;
  // joystick_dpad_step_y
  output->joystick_dpad_step_y = input->joystick_dpad_step_y;
  // joystick_smoothness
  output->joystick_smoothness = input->joystick_smoothness;
  // joystick_deadzone
  output->joystick_deadzone = input->joystick_deadzone;
  // joystick_min_motion_command
  for (size_t i = 0; i < 8; ++i) {
    output->joystick_min_motion_command[i] = input->joystick_min_motion_command[i];
  }
  // joystick_max_motion_command
  for (size_t i = 0; i < 8; ++i) {
    output->joystick_max_motion_command[i] = input->joystick_max_motion_command[i];
  }
  // cmd_priority_hold_sec
  output->cmd_priority_hold_sec = input->cmd_priority_hold_sec;
  // cmd_packet_timeout_sec
  output->cmd_packet_timeout_sec = input->cmd_packet_timeout_sec;
  // use_command_filter
  output->use_command_filter = input->use_command_filter;
  // motion_command_index_linear_vel_x
  output->motion_command_index_linear_vel_x = input->motion_command_index_linear_vel_x;
  // motion_command_index_linear_vel_y
  output->motion_command_index_linear_vel_y = input->motion_command_index_linear_vel_y;
  // motion_command_index_angular_vel_z
  output->motion_command_index_angular_vel_z = input->motion_command_index_angular_vel_z;
  // motion_command_index_position_z
  output->motion_command_index_position_z = input->motion_command_index_position_z;
  // motion_command_index_orientation_roll
  output->motion_command_index_orientation_roll = input->motion_command_index_orientation_roll;
  // motion_command_index_orientation_pitch
  output->motion_command_index_orientation_pitch = input->motion_command_index_orientation_pitch;
  // command_iface_min_motion_command
  for (size_t i = 0; i < 8; ++i) {
    output->command_iface_min_motion_command[i] = input->command_iface_min_motion_command[i];
  }
  // command_iface_max_motion_command
  for (size_t i = 0; i < 8; ++i) {
    output->command_iface_max_motion_command[i] = input->command_iface_max_motion_command[i];
  }
  // battery_low_soc_threshold
  output->battery_low_soc_threshold = input->battery_low_soc_threshold;
  // motor_temperature_threshold
  output->motor_temperature_threshold = input->motor_temperature_threshold;
  // battery_temperature_threshold
  output->battery_temperature_threshold = input->battery_temperature_threshold;
  // wma_weights
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->wma_weights), &(output->wma_weights)))
  {
    return false;
  }
  // safety_motor_rules
  if (!core__msg__MotorSafetyRule__Sequence__copy(
      &(input->safety_motor_rules), &(output->safety_motor_rules)))
  {
    return false;
  }
  // safety_imu_rules
  if (!core__msg__ImuSafetyRule__Sequence__copy(
      &(input->safety_imu_rules), &(output->safety_imu_rules)))
  {
    return false;
  }
  return true;
}

core__srv__DynamicParam_Request *
core__srv__DynamicParam_Request__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__srv__DynamicParam_Request * msg = (core__srv__DynamicParam_Request *)allocator.allocate(sizeof(core__srv__DynamicParam_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(core__srv__DynamicParam_Request));
  bool success = core__srv__DynamicParam_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
core__srv__DynamicParam_Request__destroy(core__srv__DynamicParam_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    core__srv__DynamicParam_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
core__srv__DynamicParam_Request__Sequence__init(core__srv__DynamicParam_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__srv__DynamicParam_Request * data = NULL;

  if (size) {
    data = (core__srv__DynamicParam_Request *)allocator.zero_allocate(size, sizeof(core__srv__DynamicParam_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = core__srv__DynamicParam_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        core__srv__DynamicParam_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
core__srv__DynamicParam_Request__Sequence__fini(core__srv__DynamicParam_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      core__srv__DynamicParam_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

core__srv__DynamicParam_Request__Sequence *
core__srv__DynamicParam_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__srv__DynamicParam_Request__Sequence * array = (core__srv__DynamicParam_Request__Sequence *)allocator.allocate(sizeof(core__srv__DynamicParam_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = core__srv__DynamicParam_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
core__srv__DynamicParam_Request__Sequence__destroy(core__srv__DynamicParam_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    core__srv__DynamicParam_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
core__srv__DynamicParam_Request__Sequence__are_equal(const core__srv__DynamicParam_Request__Sequence * lhs, const core__srv__DynamicParam_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!core__srv__DynamicParam_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
core__srv__DynamicParam_Request__Sequence__copy(
  const core__srv__DynamicParam_Request__Sequence * input,
  core__srv__DynamicParam_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(core__srv__DynamicParam_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    core__srv__DynamicParam_Request * data =
      (core__srv__DynamicParam_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!core__srv__DynamicParam_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          core__srv__DynamicParam_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!core__srv__DynamicParam_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `reason`
#include "rosidl_runtime_c/string_functions.h"

bool
core__srv__DynamicParam_Response__init(core__srv__DynamicParam_Response * msg)
{
  if (!msg) {
    return false;
  }
  // success
  // reason
  if (!rosidl_runtime_c__String__init(&msg->reason)) {
    core__srv__DynamicParam_Response__fini(msg);
    return false;
  }
  return true;
}

void
core__srv__DynamicParam_Response__fini(core__srv__DynamicParam_Response * msg)
{
  if (!msg) {
    return;
  }
  // success
  // reason
  rosidl_runtime_c__String__fini(&msg->reason);
}

bool
core__srv__DynamicParam_Response__are_equal(const core__srv__DynamicParam_Response * lhs, const core__srv__DynamicParam_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // success
  if (lhs->success != rhs->success) {
    return false;
  }
  // reason
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->reason), &(rhs->reason)))
  {
    return false;
  }
  return true;
}

bool
core__srv__DynamicParam_Response__copy(
  const core__srv__DynamicParam_Response * input,
  core__srv__DynamicParam_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // success
  output->success = input->success;
  // reason
  if (!rosidl_runtime_c__String__copy(
      &(input->reason), &(output->reason)))
  {
    return false;
  }
  return true;
}

core__srv__DynamicParam_Response *
core__srv__DynamicParam_Response__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__srv__DynamicParam_Response * msg = (core__srv__DynamicParam_Response *)allocator.allocate(sizeof(core__srv__DynamicParam_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(core__srv__DynamicParam_Response));
  bool success = core__srv__DynamicParam_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
core__srv__DynamicParam_Response__destroy(core__srv__DynamicParam_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    core__srv__DynamicParam_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
core__srv__DynamicParam_Response__Sequence__init(core__srv__DynamicParam_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__srv__DynamicParam_Response * data = NULL;

  if (size) {
    data = (core__srv__DynamicParam_Response *)allocator.zero_allocate(size, sizeof(core__srv__DynamicParam_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = core__srv__DynamicParam_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        core__srv__DynamicParam_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
core__srv__DynamicParam_Response__Sequence__fini(core__srv__DynamicParam_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      core__srv__DynamicParam_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

core__srv__DynamicParam_Response__Sequence *
core__srv__DynamicParam_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  core__srv__DynamicParam_Response__Sequence * array = (core__srv__DynamicParam_Response__Sequence *)allocator.allocate(sizeof(core__srv__DynamicParam_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = core__srv__DynamicParam_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
core__srv__DynamicParam_Response__Sequence__destroy(core__srv__DynamicParam_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    core__srv__DynamicParam_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
core__srv__DynamicParam_Response__Sequence__are_equal(const core__srv__DynamicParam_Response__Sequence * lhs, const core__srv__DynamicParam_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!core__srv__DynamicParam_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
core__srv__DynamicParam_Response__Sequence__copy(
  const core__srv__DynamicParam_Response__Sequence * input,
  core__srv__DynamicParam_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(core__srv__DynamicParam_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    core__srv__DynamicParam_Response * data =
      (core__srv__DynamicParam_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!core__srv__DynamicParam_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          core__srv__DynamicParam_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!core__srv__DynamicParam_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
